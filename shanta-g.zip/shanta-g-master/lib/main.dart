import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_localization/flutter_localization.dart';
import 'package:nested/nested.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '/data/constant/storage/cart_storage.dart';
import '/data/constant/storage/local_storage_services.dart';
import '/data/constant/storage/secure_storage.dart';
import '/firebase_options.dart';
import '/logic/cubits/admin/products/products_cubit.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/logic/cubits/cubits.dart';
import '/logic/cubits/date_time/date_time_cubit.dart';
import '/logic/cubits/filters/filters_cubit.dart';
import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';
import '/logic/cubits/retailer/dealers/retailer_dealers_cubit.dart';
import '/logic/cubits/switches/switches_cubit.dart';
import '/view/splashscreen/view/splash_screen.dart';
import 'data/constant/constant.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  CachedNetworkImage.logLevel = CacheManagerLogLevel.debug;
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await LocalStorage.init();
  runApp(const App());
}

mixin AppLocale {
  static const String title = 'title';

  static const Map<String, dynamic> AR = {
    title: 'الترجمة',
  };
}

class App extends StatefulWidget {
  const App({super.key});

  @override
  State<App> createState() => _AppState();
}

class _AppState extends State<App> {
  final FlutterLocalization _localization = FlutterLocalization.instance;

  // String token = '';

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      token = await SecureStorage.getToken() ?? '';
      CartStorage.prefs = await SharedPreferences.getInstance();
      _initCashedImage();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: providers(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        supportedLocales: const [
          Locale("ar"),
        ],
        localizationsDelegates: _localization.localizationsDelegates,
        locale: const Locale("ar"),
        title: 'Shanta-G',
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
          useMaterial3: true,
        ),
        home: const SplashScreen(),
      ),
    );
  }

  List<SingleChildWidget> providers() => [
        BlocProvider(create: (context) => AuthCubit()),
        BlocProvider(create: (context) => ToggleCubit()),
        BlocProvider(create: (context) => HomeCubit()),
        BlocProvider(create: (context) => ClientProductsCubit()),
        BlocProvider(create: (context) => ClientOrdersCubit()),
        BlocProvider(create: (context) => RetailerProductsCubit()),
        BlocProvider(create: (context) => RetailerOrdersCubit()),
        BlocProvider(create: (context) => WholesalerProductsCubit()),
        BlocProvider(create: (context) => WholesalerOrdersCubit()),
        BlocProvider(create: (context) => ShantaProductsCubit()),
        BlocProvider(create: (context) => ShantaOrdersCubit()),
        BlocProvider(create: (context) => AdminOrdersCubit()),
        BlocProvider(create: (context) => AdminClientsCubit()),
        BlocProvider(create: (context) => AdminRetailersCubit()),
        BlocProvider(create: (context) => AdminShantaCubit()),
        BlocProvider(create: (context) => AdminWholesalersCubit()),
        BlocProvider(create: (context) => CategoriesCubit()),
        BlocProvider(create: (context) => VisibilityCubit()),
        BlocProvider(create: (context) => DealerAccessCubit()),
        BlocProvider(create: (context) => ReportCubit()),
        BlocProvider(create: (context) => ProfileCubit()),
        BlocProvider(create: (context) => ProductsCubit()),
        BlocProvider(create: (context) => DateTimeCubit()),
        BlocProvider(create: (context) => ClientCartCubit()),
        BlocProvider(create: (context) => RetailerCartCubit()),
        BlocProvider(create: (context) => SwitchesCubit()),
        BlocProvider(create: (context) => FiltersCubit()),
        BlocProvider(create: (context) => RetailerDealersCubit()),
      ];

  Future _initCashedImage() async {
    String storageLocation = (await getApplicationDocumentsDirectory()).path;
    // await FastCachedImageConfig.init(
    //   subDir: storageLocation,
    //   clearCacheAfter: const Duration(days: 15),
    // );
  }
}
