import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shantagi/data/notifications/fcm_token_handler.dart';
import '../../../data/notifications/messaging_handler.dart';
import '/view/global_elements/toast.dart';

import '/data/constant/app_images.dart';
import '/data/constant/constant.dart';
import '/data/constant/storage/local_storage_services.dart';
import '/data/constant/storage/secure_storage.dart';
import '/view/auth/login/login.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    fToast.init(context);
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    )..repeat(reverse: true);
    _animation = Tween<double>(begin: 1.2, end: 1.3).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );
    countDownTime();
    WidgetsBinding.instance.addPostFrameCallback((callback) async{
      await getToken();
      initializeFirebase();
    });
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ScaleTransition(
          scale: _animation,
          child: SizedBox(
            height: MediaQuery.sizeOf(context).height * 0.5,
            width: MediaQuery.sizeOf(context).width * 0.5,
            child: SvgPicture.asset(
              AppImages.logo,
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }

  countDownTime() async {
    return Timer(
      const Duration(seconds: 3),
      () async {
        await _navigate();
      },
    );
  }

  Future<void> _navigate() async {
    String uID = await SecureStorage.getToken() ?? '';
    print('uID ::: ::: $uID');
    if (uID != "") {
      token = uID;
      String type = await LocalStorage.getType() ?? '';
      print('type ::: ::: $type');
      getTokenOnRefresh();
      Navigator.maybePop(context);
      Navigator.maybePop(context);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => types[type]),
        // (route) => true,
      );
      // Navigator.popAndPushNamed(context, '/${types[type]}');
    } else {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (_) => const LoginScreen()));
      // Navigator.popAndPushNamed(context, '/login');
    }
  }
}
