import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget itemSpec(title, value, {bool? isBold, bool? space}) => Padding(
  padding: const EdgeInsets.all(10),
  child: Row(
        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _text(title, true),
          space != null ? const Spacer() : const SizedBox.shrink(),
          _text(value, null),
        ],
      ),
);

Widget _text(data, bool? isBold) => Padding(
  padding: const EdgeInsets.symmetric(horizontal: 5),
  child: Text(
    data,
    overflow: TextOverflow.ellipsis,
    style: isBold != null ? _titleStyle() : _style(),
  ),
);

TextStyle _style() => const TextStyle(

      color: AppColors.primary,
      fontSize: 18,
    );

TextStyle _titleStyle() => const TextStyle(
      fontWeight: FontWeight.bold,
      color: AppColors.primary,
      fontSize: 18,
    );


