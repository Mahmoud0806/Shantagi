import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/cubits.dart';
import '/models/order/order_item.dart';
import 'item_spec.dart';
import 'item_title.dart';

class AdminItemInfo extends StatelessWidget {
  final int index;
  final bool isClient;

  const AdminItemInfo({
    super.key,
    required this.index,
    required this.isClient,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: BlocBuilder<AdminOrdersCubit, AdminOrdersState>(
        builder: (context, state) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _children(context, state, index),
          );
        },
      ),
    );
  }

  List<Widget> _children(
      BuildContext context, AdminOrdersState state, int index) {
    return [
      adminItemTitle(context, state.order.orderItems[index].product.name),
      AdminItemSpec(
          title: 'القياس:', value: state.order.orderItems[index].size),
      AdminItemSpec(
          title: 'العدد المطلوب:',
          value: '${state.order.orderItems[index].requiredAmount}'),
      isClient
          ? _acceptableAmount(state.order.orderItems[index], index)
          : const SizedBox.shrink(),
      state.order.orderItems[index].notes != ''
          ? AdminItemSpec(
              title: 'ملاحظات:', value: state.order.orderItems[index].notes)
          : const SizedBox.shrink(),
      // : const SizedBox.shrink(),
    ];
  }

  RenderObjectWidget _acceptableAmount(OrderItem item, int index) {
    return (item.size != '')
        ? Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: [
                const Text(
                  'المتوفر:',
                  style: TextStyle(
                    fontSize: 16,
                    fontFamily: 'Sukar',
                  ),
                ),
                (item.acceptableAmount > 0)
                    ? Text(
                        '${item.acceptableAmount}',
                        style: const TextStyle(
                          fontSize: 14,
                          fontFamily: 'Sukar',
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.all(10),
                        child: SizedBox(
                          width: 30,
                          height: 20,
                          child:
                              BlocBuilder<AdminOrdersCubit, AdminOrdersState>(
                            builder: (context, state) {
                              return TextFormField(
                                textAlign: TextAlign.center,
                                keyboardType: TextInputType.number,
                                maxLength: 2,
                                controller: state.itemsFields[index],
                                cursorColor: AppColors.primary,
                                style:
                                    const TextStyle(color: AppColors.primary),
                                decoration: InputDecoration(
                                  counterText: '',
                                  contentPadding: EdgeInsets.zero,
                                  focusedBorder: _focusBorder(),
                                  enabledBorder: _outlineInputBorder(),
                                  disabledBorder: _outlineInputBorder(),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
              ],
            ),
          )
        : const SizedBox.shrink();
  }

  OutlineInputBorder _focusBorder() => const OutlineInputBorder(
        borderSide: BorderSide(
          color: AppColors.primary,
          width: 1.5,
        ),
        borderRadius: BorderRadius.all(Radius.circular(3)),
      );

  OutlineInputBorder _outlineInputBorder() => const OutlineInputBorder(
        borderSide: BorderSide(color: Colors.black),
        borderRadius: BorderRadius.all(
          Radius.circular(3),
        ),
      );
}
