import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '/models/order/order_item.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/orders/orders_cubit.dart';
import '/view/admin/home/screens/orders/details/details_screen.dart';
import '/view/admin/home/screens/orders/elements/item_spec.dart';
import '/view/admin/home/screens/orders/elements/item_status.dart';

Widget adminOrderItem(BuildContext context, int index,
    {bool isClient = false}) {
  return InkWell(
    child: Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
          side: const BorderSide(
            color: AppColors.primaryText,
          ),
          borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: BlocBuilder<AdminOrdersCubit, AdminOrdersState>(
          builder: (context, state) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                itemSpec(
                    DateFormat('yyyy/MM/dd').format(DateTime.parse(state.orders[index].createdAt)),
                    state.orders[index].number,
                    space: true),
                itemSpec(
                  isClient ? 'الزبون:' : 'تاجر المفرق:',
                   state.orders[index].user.name,
                  isBold: true,
                ),
                itemStatus(
                  context,
                  state.orders[index].status,
                  state.orders[index].id,
                  isClient: isClient,
                ),
              ],
            );
          },
        ),
      ),
    ),
    onTap: () {
      var cubit = BlocProvider.of<AdminOrdersCubit>(context);
      cubit.fillAmountsFields(cubit.state.orders[index].orderItems.length);
      cubit.setActiveOrder(index);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const AdminOrderDetails(isClient: true)),
      );
      // Navigator.pushNamed(context, '/orderDetails',
      //     arguments: controller.orders[index]);
    },
  );
}
