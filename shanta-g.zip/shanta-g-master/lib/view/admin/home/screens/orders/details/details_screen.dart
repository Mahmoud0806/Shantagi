import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/orders/elements/submit_order_btn.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/orders/orders_cubit.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import 'item_info.dart';

class AdminOrderDetails extends StatefulWidget {
  final bool isClient;

  const AdminOrderDetails({super.key, required this.isClient});

  @override
  State<AdminOrderDetails> createState() => _AdminOrderDetailsState();
}

class _AdminOrderDetailsState extends State<AdminOrderDetails> {
  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<AdminOrdersCubit>(context);
    return Scaffold(
      appBar: customAppBar('تفاصيل الطلبية', context),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                shrinkWrap: true,
                itemBuilder: (context, int index) => _orderItem(context, index),
                itemCount: cubit.state.order.orderItems.length,
              ),
            ),
            widget.isClient && cubit.state.order.status == 'new'
                ? adminSubmitOrder(context)
                : const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }

  Widget _orderItem(BuildContext context, int index) {
    return BlocBuilder<AdminOrdersCubit, AdminOrdersState>(
      builder: (context, state) {
        return SizedBox(
          child: Card(
            color: AppColors.secondarySec.withOpacity(0.09),
            surfaceTintColor: Colors.transparent,
            shadowColor: Colors.transparent,
            child: Padding(
              padding: const EdgeInsets.all(15.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _itemImage(context, state, index),
                  AdminItemInfo(
                    index: index,
                    isClient: widget.isClient,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _itemImage(BuildContext context, AdminOrdersState state, int index) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: SizedBox(
        height: 120,
        width: 120,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(5),
          child: state.order.orderItems[index].product.images.isNotEmpty
              ? Image.network(
                  // 'src',
                  state.order.orderItems[index].product.images.isNotEmpty
                      ? state.order.orderItems[index].product.images.first
                          .attachment
                      : '',
                  fit: BoxFit.cover,
                )
              : const SizedBox(),
        ),
      ),
    );
  }
}
