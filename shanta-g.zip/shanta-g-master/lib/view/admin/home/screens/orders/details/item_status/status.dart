import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/orders/orders_cubit.dart';
import '/models/order/order.dart';

import 'confirm_new_status.dart';

// 81194
class ItemStatus extends StatefulWidget {
  final Order order;
  final int itemIndex;

  ItemStatus({required this.itemIndex, required this.order, super.key});

  @override
  State<ItemStatus> createState() => _ItemStatusState();
}

class _ItemStatusState extends State<ItemStatus> {
// int orderIndex = 0;
  @override
  void initState() {
    // TODO: implement initState
    var ordersCubit = BlocProvider.of<AdminOrdersCubit>(context);
    // print('init  ..... item sta::: ::: ;;;;; ${ordersCubit.orders.length}');
    //     print('init ...... item sta::: ::: ${ordersCubit.orders.first.orderItems![0].status}');
    // print(widget.orderId);
    // print('.. ... ... ${ordersCubit.selectedOrderItemsStatus.length}');
    // for (int i = 0; i < ordersCubit.orders.length; i++) {
    //   if (ordersCubit.orders[i].id == widget.orderId) {
    //     setState(() {
    //       // orderIndex = i;
    //       ordersCubit.selectedOrderItemStatus =
    //           ordersCubit.orders[i].orderItems![widget.itemIndex].status ??
    //               'pending';
    //     });
    //   }
    // }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var ordersCubit = BlocProvider.of<AdminOrdersCubit>(context);
    return SizedBox(
      width: 95,
      child: BlocBuilder<AdminOrdersCubit, AdminOrdersState>(
        builder: (context, state) {
          return state.status == AdminOrdersStatus.loading &&
                  widget.itemIndex == 'ordersCubit.selectedOrderItemIndex'
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : DropdownButton(
                  dropdownColor: Colors.white,
                  menuMaxHeight: 300,
                  value: widget.order.orderItems[widget.itemIndex].status,
                  isExpanded: true,
                  onChanged: (String? newValue) {
                    ordersCubit.selectedItemIndex = widget.itemIndex;
                    showDialog(
                        context: context,
                        builder: (context) {
                          return confirmNewStatus(context, widget.itemIndex,
                              widget.order.id, newValue);
                        });

                    // setState(() {
                    // ordersCubit.selectedOrderItemStatus = newValue;
                    // });
                  },
                  items: ordersCubit.orderItemStatus,
                );
        },
      ),
    );
  }
}
