import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/orders/orders_cubit.dart';
import '/view/global_elements/widgets/styles.dart';

// class  extends StatefulWidget {
//   const ({super.key});
//
//   @override
//   State<> createState() => _State();
// }
//
// class _State extends State<> {
//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }

AlertDialog confirmNewStatus(
    BuildContext context, int itemIndex, int index, String? status) {
  var ordersCubit = BlocProvider.of<AdminOrdersCubit>(context);
  return AlertDialog(
    title: Text(
      'هل أنت متأكد من تغيير حالة الطلب إلى ${ordersCubit.status[status ?? '']}؟',
      style: const TextStyle(fontFamily: 'Sukar'),
    ),
    content: Form(
      // key: formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            mainAxisSize: MainAxisSize.min,
            children: [
              InkWell(
                onTap: () {
                  // action to send to backend
                  ordersCubit.changeItemStatus(
                      ordersCubit.state.orders[index].orderItems[itemIndex].id,
                      status ?? '');
                  Navigator.pop(context);
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColors.primary,
                  ),
                  child: Text(
                    'نعم',
                    style: Styles.buttonText.copyWith(
                      color: AppColors.background,
                      fontSize: 18,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 35),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: Colors.red,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 0.0, horizontal: 15.0),
                    child: Text(
                      'لا',
                      style: Styles.buttonText.copyWith(
                        color: AppColors.background,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}
