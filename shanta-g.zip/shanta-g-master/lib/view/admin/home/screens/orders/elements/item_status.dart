import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/orders_status.dart';
import '/data/constant/urls/admin.dart';
import '/logic/cubits/admin/orders/orders_cubit.dart';

Widget itemStatus(BuildContext context, String status, int id,
        {bool? isClient}) =>
    Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: <Widget>[
        _icon(status),
        _status(status),
        // const Expanded(child: SizedBox.shrink()),
        switchStatus(context, status, id, isClient: isClient),
      ],
    );

Widget switchStatus(BuildContext context, String status, int id,
    {bool? isClient}) {
  var cubit = BlocProvider.of<AdminOrdersCubit>(context);
  return status != 'done' &&  status != 'cancelled'
      ? IconButton(
          onPressed: () {
            String newStatus = setNewStatus(status, ordersStatus);
            print('new status');
            cubit.changeStatus(id, newStatus, isClient: isClient).then((value) {
              cubit.getAll(
                  isClient != null
                      ? AdminURLs.clientOrders
                      : AdminURLs.retailerOrders,
                  isClient: isClient);
            });
            // controller.changeOrderState(
            //     controller.orders[index].id ?? -1000);
          },
          icon: const Icon(Icons.compare_arrows),
        )
      : const SizedBox.shrink();
}

Text _status(String status) {
  return Text(
    status == 'done'
        ? 'منفذ'
        : status == 'ready'
            ? 'جاهز'
            : status == 'answered'
                ? 'تم الرد'
                : status == 'cancelled'
                    ? 'ملغى'
                    : 'قيد الإنتظار',
    style: TextStyle(
      fontSize: 16,
      color: status == 'done'
          ? Colors.black
          : status == 'ready'
              ? Colors.yellow
              : status == 'answered'
                  ? Colors.green
                  : status == 'cancelled'
                      ? Colors.red
                      : Colors.grey,
    ),
  );
}

Icon _icon(String status) {
  return Icon(
    Icons.circle,
    size: 15,
    color: status == 'done'
        ? Colors.black
        : status == 'ready'
            ? Colors.yellow
            : status == 'answered'
                ? Colors.green
                : status == 'cancelled'
                    ? Colors.red
                    : Colors.grey,
  );
}
