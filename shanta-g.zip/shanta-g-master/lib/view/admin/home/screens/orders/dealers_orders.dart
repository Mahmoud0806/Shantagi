import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/data/constant/urls/admin.dart';
import '/logic/cubits/admin/orders/orders_cubit.dart';
import '/view/admin/home/screens/orders/elements/retailer_order_item.dart';
import '/view/global_elements/search_bar.dart';
import 'elements/no_orders.dart';

class AdminDealersOrdersPage extends StatefulWidget {
  const AdminDealersOrdersPage({super.key});

  @override
  State<AdminDealersOrdersPage> createState() => _AdminDealersOrdersPageState();
}

class _AdminDealersOrdersPageState extends State<AdminDealersOrdersPage> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await BlocProvider.of<AdminOrdersCubit>(context)
          .getAll(AdminURLs.retailerOrders);
      _scrollController.addListener(_loadMoreData);
    });
    super.initState();
  }

  final _scrollController = ScrollController();

  void _loadMoreData() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent) {
      var cubit = BlocProvider.of<AdminOrdersCubit>(context);
      cubit.getAll(AdminURLs.retailerOrders, saveOld: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    var controller = TextEditingController();
    var cubit = BlocProvider.of<AdminOrdersCubit>(context);
    return RefreshIndicator(
      onRefresh: () => cubit.getAll(AdminURLs.retailerOrders),
      color: AppColors.primary,
      child: Column(
        children: [
          searchBar('إبحث', controller, (s) {
            print('controller :: ;:: ;; : ${controller.text}');
            cubit.getAll(AdminURLs.retailerOrders,
                params: '?order_number=${controller.text}');
          }),
          BlocBuilder<AdminOrdersCubit, AdminOrdersState>(
            builder: (context, state) =>
                state.status == AdminOrdersStatus.loading &&
                state.retailerOrders.isEmpty
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : (state.retailerOrders.isNotEmpty)
                        ? Expanded(
                            child: ListView.separated(
                              controller: _scrollController,
                              itemBuilder: (context, index) {
                                // print(controller.orders[index].status);
                                return adminRetailerOrderItem(context, index,
                                    isClient: false);
                              },
                              separatorBuilder: (context, index) {
                                return const SizedBox(
                                  height: 10,
                                );
                              },
                              itemCount: state.retailerOrders.length,
                              // itemCount: controller.orders.length,
                            ),
                          )
                        : noOrdersYet(context),
          ),
        ],
      ),
    );
  }
}
