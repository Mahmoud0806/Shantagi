import 'package:flutter/material.dart';

Widget noOrdersYet(BuildContext context) => Expanded(
  child: const Center(
    child: Text('لا يوجد طلبات'),
  ),
);
