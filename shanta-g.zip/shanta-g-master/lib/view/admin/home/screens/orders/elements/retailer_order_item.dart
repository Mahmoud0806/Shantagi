import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

import '../details/details_screen.dart';
import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/orders/orders_cubit.dart';
import '/view/admin/home/screens/orders/elements/item_spec.dart';
import '/view/admin/home/screens/orders/elements/item_status.dart';

Widget adminRetailerOrderItem(BuildContext context, int index,
    {bool isClient = false}) {
  return InkWell(
    child: Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
          side: const BorderSide(
            color: AppColors.primaryText,
          ),
          borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(15.0),
        child: BlocBuilder<AdminOrdersCubit, AdminOrdersState>(
          builder: (context, state) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                itemSpec(
                    state.retailerOrders[index].createdAt == ''
                        ? ''
                        : DateFormat('yyyy/MM/dd').format(
                            DateTime.tryParse(
                                    state.retailerOrders[index].createdAt) ??
                                DateTime(2000),
                          ),
                    isClient
                        ? state.retailerOrders[index].number
                        : state.retailerOrders[index].number,
                    space: true),
                itemSpec(
                  isClient ? 'الزبون:' : 'تاجر المفرق:',
                  isClient
                      ? state.retailerOrders[index].user.name
                      : state.retailerOrders[index].user.name,
                  isBold: true,
                ),
                itemStatus(
                  context,
                  isClient
                      ? state.retailerOrders[index].status
                      : state.retailerOrders[index].status,
                  state.retailerOrders[index].id,
                  isClient: isClient,
                ),
              ],
            );
          },
        ),
      ),
    ),
    onTap: () {
      var cubit = BlocProvider.of<AdminOrdersCubit>(context);
      cubit.setRetailerActiveOrder(index);
      cubit.fillAmountsFields(cubit.state.order.orderItems.length);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const AdminOrderDetails(isClient: false,)),
      );
      // Navigator.pushNamed(context, '/orderDetails',
      //     arguments: controller.orders[index]);
    },
  );
}
