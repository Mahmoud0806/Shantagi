import 'package:flutter/material.dart';

import '/models/user.dart';
import 'user_item/user_item.dart';

Widget usersWidget(List<User> users, edit, delete) => SizedBox(
      child: ListView.builder(
        itemBuilder: (context, index) => userItem(
          users[index],
          edit,
          delete,
        ),
      ),
    );
