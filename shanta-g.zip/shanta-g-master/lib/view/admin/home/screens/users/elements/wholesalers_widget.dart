import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';
import 'user_item/elements/controllers.dart';
import 'user_item/elements/update/update_dialog.dart';
import 'user_item/user_item.dart';

Widget wholesalersWidget(BuildContext context) {
  var cubit = BlocProvider.of<AdminWholesalersCubit>(context);
  var formKey = GlobalKey<FormState>();
  return RefreshIndicator(
    onRefresh: cubit.getAll,
    child: SizedBox(
      child: BlocBuilder<AdminWholesalersCubit, AdminWholesalersState>(
        builder: (context, state) {
          return ListView.builder(
            itemCount: state.wholesalers.length,
            itemBuilder: (context, index) => userItem(
              state.wholesalers[index],
              () {
                showDialog(
                    context: context,
                    builder: (con) {
                      return updateDialog(context, formKey,
                          type: 'wholesaler', index: index, () {
                        _updateData(cubit, state, index, context);
                      });
                    });
              },
              () {
                cubit.delete(state.wholesalers[index].id);
              },
            ),
          );
        },
      ),
    ),
  );
}

void _updateData(AdminWholesalersCubit cubit, AdminWholesalersState state,
    int index, BuildContext context) {
  cubit
      .update(
    state.wholesalers[index].copyWith(
      name: userControllers['name']!.text.isNotEmpty
          ? userControllers['name']!.text
          : null,
      email: userControllers['email']!.text.isNotEmpty
          ? userControllers['email']!.text
          : null,
      phone: userControllers['phone']!.text.isNotEmpty
          ? userControllers['phone']!.text
          : null,
      address: userControllers['address']!.text.isNotEmpty
          ? userControllers['address']!.text
          : null,
    ),
  )
      .then((value) {
    clearControllers();
    Navigator.maybePop(context);
  });
}
