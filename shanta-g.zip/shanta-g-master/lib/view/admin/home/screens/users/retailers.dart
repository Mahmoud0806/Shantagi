import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/users/retailer/admin_retailers_cubit.dart';
import '/view/admin/home/screens/users/elements/retailers_widget.dart';

class AdminRetailersPage extends StatefulWidget {
  const AdminRetailersPage({super.key});

  @override
  State<AdminRetailersPage> createState() => _AdminRetailersPageState();
}

class _AdminRetailersPageState extends State<AdminRetailersPage> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await BlocProvider.of<AdminRetailersCubit>(context).getAll();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return retailersWidget(context);
  }
}
