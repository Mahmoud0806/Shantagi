import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/users/clients/admin_clients_cubit.dart';

import '/view/admin/home/screens/users/elements/clients_widget.dart';

class AdminClientsPage extends StatefulWidget {
  const AdminClientsPage({super.key});

  @override
  State<AdminClientsPage> createState() => _AdminClientsPageState();
}

class _AdminClientsPageState extends State<AdminClientsPage> {

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await BlocProvider.of<AdminClientsCubit>(context).getAll();
    });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return clientsWidget(context);
  }
}
