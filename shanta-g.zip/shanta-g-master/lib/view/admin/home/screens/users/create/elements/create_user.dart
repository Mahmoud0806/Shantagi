import 'package:flutter/material.dart';

import '../../elements/user_item/elements/controllers.dart';
import '../../elements/user_item/elements/field_item/fields.dart';
import '/data/constant/app_colors.dart';
import '/view/admin/home/screens/users/create/elements/create_btn.dart';
import 'date_time/date.dart';

class CreateUserWidget extends StatelessWidget {
  final String userType;
  final VoidCallback onPressed;

  const CreateUserWidget(
      {super.key, required this.onPressed, required this.userType});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 30),
      child: SingleChildScrollView(
        child: Column(
          children: [
            _fields(),
            userType == 'Client' ? const Date() : const SizedBox.shrink(),
            createBtn(context, onPressed)
          ],
        ),
      ),
    );
  }

  Widget _fields() {
    return fields(
      userControllers['name']!,
      userControllers['email']!,
      userControllers['phone']!,
      userControllers['address']!,
      password: userControllers['password'],
      titleColor: AppColors.background,
    );
  }
}
