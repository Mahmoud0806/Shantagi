import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

class CustomField extends StatelessWidget {
  final bool? autofocus;
  final Function(String value)? onChanged;
  final Function(String value)? onSubmit;
  final TextEditingController? controller;
  final String? hintText;
  final TextStyle? hintStyle;
  final InputBorder? border;
  final InputBorder? focusedBorder;
  final Widget? suffixIcon;
  final Widget? prefixIcon;
  final String? Function(String? value)? validate;

  const CustomField({
    Key? key,
    this.autofocus,
    this.hintText,
    this.hintStyle,
    this.border,
    this.focusedBorder,
    this.controller,
    this.suffixIcon,
    this.onChanged,
    this.onSubmit,
    this.prefixIcon,
    this.validate,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: TextFormField(
        validator: validate,
        autofocus: autofocus ?? false,
        onChanged: onChanged,
        controller: controller,
        onFieldSubmitted: onSubmit,
        cursorColor: AppColors.primary,
        decoration: InputDecoration(
          // errorStyle: TextStyle(color: Colors.blue),
          filled: true,
          fillColor: Colors.white,
          hintText: hintText,
          hintStyle: const TextStyle(
            fontSize: 16,
          ),
          border: const OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(5)),
            borderSide: BorderSide(width: 2),
          ),
          suffixIcon: suffixIcon,
          focusedBorder: const OutlineInputBorder(
            borderSide: BorderSide(width: 2, color: AppColors.primary),
          ),
          prefixIconColor: MaterialStateColor.resolveWith((states) =>
              states.contains(MaterialState.focused)
                  ? AppColors.primary
                  : Colors.grey),
          suffixIconColor: MaterialStateColor.resolveWith((states) =>
              states.contains(MaterialState.focused)
                  ? AppColors.primary
                  : Colors.grey),
        ),
      ),
    );
  }
}
