import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/users/clients/admin_clients_cubit.dart';
import 'user_item/elements/controllers.dart';
import 'user_item/elements/update/update_dialog.dart';
import 'user_item/user_item.dart';

Widget clientsWidget(BuildContext context) {
  var cubit = BlocProvider.of<AdminClientsCubit>(context);
  var formKey = GlobalKey<FormState>();
  return RefreshIndicator(
    onRefresh: cubit.getAll,
    child: SizedBox(
      child: BlocBuilder<AdminClientsCubit, AdminClientsState>(
        builder: (context, state) {
          return ListView.builder(
            itemCount: state.clients.length,
            itemBuilder: (context, index) => userItem(
              state.clients[index],
              () {
                showDialog(
                    context: context,
                    builder: (con) {
                      return updateDialog(context, formKey, () {
                        _updateData(cubit, state, index, context);
                      });
                    });
              },
              () {
                cubit.delete(state.clients[index].id);
              },
            ),
          );
        },
      ),
    ),
  );
}

void _updateData(AdminClientsCubit cubit, AdminClientsState state, int index,
    BuildContext context) {
  cubit
      .update(
    state.clients[index].copyWith(
      name: userControllers['name']!.text.isNotEmpty
          ? userControllers['name']!.text
          : null,
      email: userControllers['email']!.text.isNotEmpty
          ? userControllers['email']!.text
          : null,
      phone: userControllers['phone']!.text.isNotEmpty
          ? userControllers['phone']!.text
          : null,
      address: userControllers['address']!.text.isNotEmpty
          ? userControllers['address']!.text
          : null,
    ),
  )
      .then((value) {
    clearControllers();
    Navigator.maybePop(context);
    // cubit.getAll();
  });
}
