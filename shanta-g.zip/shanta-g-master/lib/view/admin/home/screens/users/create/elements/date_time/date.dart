import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import '/logic/cubits/date_time/date_time_cubit.dart';


import 'picker_button.dart';
import 'pickers/date_picker.dart';

class Date extends StatelessWidget {
  const Date({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 18.0),
      child: _dateWidget(),
    );
  }

  Widget _dateWidget() => SizedBox(
        child: BlocBuilder<DateTimeCubit, DateTimeState>(
          builder: (context, state) {
            DateTimeCubit dateTimeCubit =
                BlocProvider.of<DateTimeCubit>(context);
            String date = setDate(state);
            return PickerButton(date, () async {
              var selectedDate = await pickDate(context);
              dateTimeCubit.setDate(selectedDate);
              // state.copyWith(date: selectedDate);
            });
          },
        ),
      );

  String setDate(DateTimeState state) {
    return state.date.isBefore(
      DateTime.now().subtract(
        const Duration(days: 1),
      ),
    )
        ? 'Select Date'
        : DateFormat('yyyy/MM/dd').format(state.date);
  }
}
