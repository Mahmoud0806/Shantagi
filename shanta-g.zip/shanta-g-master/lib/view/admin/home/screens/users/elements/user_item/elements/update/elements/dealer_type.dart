import 'package:flutter/material.dart';

Widget changeDealerType(BuildContext context, value, VoidCallback onChanged) {
  return Column(
    children: [
      const Text('نوع التاجر'),
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          const Text('تاجر جملة'),
          Switch(
            value: value,
            onChanged: (newValue) {
              onChanged();
            },
          ),
          const Text('تاجر شنطة'),
        ],
      ),
    ],
  );
}
