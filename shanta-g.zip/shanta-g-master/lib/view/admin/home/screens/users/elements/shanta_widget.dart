import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/users/shanta/admin_shanta_cubit.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/update/update_dialog.dart';
import 'user_item/elements/controllers.dart';
import 'user_item/user_item.dart';

Widget shantasWidget(BuildContext context, formKey) {
  var cubit = BlocProvider.of<AdminShantaCubit>(context);
  return RefreshIndicator(
    onRefresh: cubit.getAll,
    child: SizedBox(
      child: BlocBuilder<AdminShantaCubit, AdminShantaState>(
        builder: (context, state) {
          return ListView.builder(
            itemCount: state.shantas.length,
            itemBuilder: (context, index) => userItem(
              state.shantas[index],
              () {
                showDialog(
                    context: context,
                    builder: (ctx) {
                      return updateDialog(context, formKey,
                          type: 'shanta', index: index, () {
                        _updateData(cubit, state, index, context);
                      });
                    });
              },
              () {
                cubit.delete(state.shantas[index].id);
              },
            ),
          );
        },
      ),
    ),
  );
}

void _updateData(AdminShantaCubit cubit, AdminShantaState state, int index,
    BuildContext context) {
  cubit
      .update(
    state.shantas[index].copyWith(
      name: userControllers['name']!.text.isNotEmpty
          ? userControllers['name']!.text
          : null,
      email: userControllers['email']!.text.isNotEmpty
          ? userControllers['email']!.text
          : null,
      phone: userControllers['phone']!.text.isNotEmpty
          ? userControllers['phone']!.text
          : null,
      address: userControllers['address']!.text.isNotEmpty
          ? userControllers['address']!.text
          : null,
    ),
  )
      .then((value) {
    clearControllers();
    Navigator.maybePop(context);
  });
}

// VoidCallback _updateData(cubit, state, index) => cubit
//     .update(
//       state.shantas[index].copyWith(
//         name: controllers['name']!.text,
//         email: controllers['email']!.text,
//         phone: controllers['phone']!.text,
//         address: controllers['address']!.text,
//       ),
//     )
//     .then((value) {});
