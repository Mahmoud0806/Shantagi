import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/global_elements/toast.dart';
import '/logic/cubits/admin/users/shanta/admin_shanta_cubit.dart';
import '/logic/cubits/admin/users/shanta/admin_shanta_cubit.dart';
import '/models/user.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/controllers.dart';
import '/data/constant/app_colors.dart';
import '/view/admin/home/screens/users/create/elements/create_user.dart';

class CreateShanta extends StatelessWidget {
  const CreateShanta({super.key});

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<AdminShantaCubit>(context);
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.primary,
        appBar: customAppBar('',context, showBack: true, background: AppColors.primary, foreground: AppColors.background),
        body: BlocConsumer<AdminShantaCubit, AdminShantaState>(
          listener: (context, state) {
            if(state.status == ShantaStatus.created){
              showToast(
                  text: 'تم إضافة التاجر',
                  state: ToastStates.success,
                  gravity: ToastGravity.TOP);
              Navigator.pop(context);
            }
            else if(state.status == ShantaStatus.error){
              showToast(
                  text: state.error,
                  state: ToastStates.error,
                  gravity: ToastGravity.TOP);
            }
          },
          builder: (context, state) {
            return CreateUserWidget(
              onPressed: () {
                cubit.create(User.initial().copyWith(
                  name: userControllers['name']!.text,
                  email: userControllers['email']!.text,
                  password: userControllers['password']!.text,
                  phone: userControllers['phone']!.text,
                  address: userControllers['address']!.text,
                )).then((value) {
                  // cubit.getAll();

                });
              },
              userType: 'Shanta',
            );
          },
        ),
      ),
    );
  }
}
