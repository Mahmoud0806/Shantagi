import 'package:flutter/material.dart';

import 'accept_date_tme_button.dart';
import 'date.dart';


class DateTimePickersWidget extends StatelessWidget {
  const DateTimePickersWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _dateTimePickerWidget(context);
  }

  Widget _dateTimePickerWidget(BuildContext context) => Expanded(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: _children(),
        ),
      );

  List<Widget> _children() => const [
        Column(
          children: [
            Date(),
            // StartTime(),
            // EndTime(),
          ],
        ),
        AcceptDateTimeButton(),
      ];
}
