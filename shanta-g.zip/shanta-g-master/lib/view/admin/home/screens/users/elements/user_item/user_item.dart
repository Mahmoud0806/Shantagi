import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

import '/models/user.dart';
import 'elements/info/user_info.dart';
import 'elements/item_btn.dart';

Widget userItem(User user, edit, delete) => Container(
      margin: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.circular(15),
        border: Border.all(width: 1, color: AppColors.primary),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: _children(user, edit, delete),
      ),
    );

List<Widget> _children(User user, edit, delete) => [
      userInfo(user),
      const Spacer(),
      itemBtn(edit, delete),
    ];
