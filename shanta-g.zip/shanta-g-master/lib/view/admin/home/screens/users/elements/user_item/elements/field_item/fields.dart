import 'package:flutter/material.dart';

import 'field.dart';
import 'field_title.dart';

Widget fields(
        TextEditingController nameController,
        TextEditingController emailController,
        TextEditingController phoneController,
        TextEditingController addressController,
        {TextEditingController? password, Color? titleColor}) =>
    Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        fieldTitle('الاسم', color: titleColor),
        CustomField(
          controller: nameController,
        ),
        fieldTitle('البريد الالكتروني', color: titleColor),
        CustomField(
          controller: emailController,
        ),
        fieldTitle('كلمة المرور', color: titleColor),
        CustomField(
          controller: password,
        ),

        fieldTitle('رقم الهاتف', color: titleColor),
        CustomField(
          controller: phoneController,
        ),
        fieldTitle('العنوان', color: titleColor),
        CustomField(
          controller: addressController,
        ),
      ],
    );
