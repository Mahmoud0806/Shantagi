
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/date_time/date_time_cubit.dart';



class AcceptDateTimeButton extends StatelessWidget {
  const AcceptDateTimeButton({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 58.0),
        child: _button(context),
      ),
    );
  }

  ElevatedButton _button(BuildContext context) => ElevatedButton(
        onPressed: () {
          DateTimeCubit dateCubit = BlocProvider.of<DateTimeCubit>(context);
          // if () {
          //
          // } else {
          //   // customSnackBar(
          //   //   'time Is Not Valid: \n${dateCubit.state.errorMessage}',
          //   //   true,
          //   //   context,
          //   // );
          // }
        },
        style: _buttonStyle(context),
        child: _buttonTitle(),
      );

  ButtonStyle _buttonStyle(BuildContext context) {
    return ElevatedButton.styleFrom(
      shape: _buttonShape(),
      fixedSize: Size(MediaQuery.of(context).size.width * 0.8, MediaQuery.of(context).size.height * 0.05),
    );
  }

  OutlinedBorder _buttonShape() => RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      );

  Widget _buttonTitle() => SizedBox(
        child: Text(
          'Continue to Services',
          style: _titleStyle(),
        ),
      );

  TextStyle _titleStyle() => const TextStyle(
        fontSize: 16,
        color: Colors.white,
      );
}
