import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';
import 'dealer_type.dart';

Widget wholesalerType(BuildContext context, int index) {
  var cubit = BlocProvider.of<AdminWholesalersCubit>(context);
  return BlocConsumer<AdminWholesalersCubit, AdminWholesalersState>(
    listener: (context, state) {

    },
    builder: (context, state) {
      return state.status == WholesalerStatus.loading
          ? const Center(child: CircularProgressIndicator())
          : changeDealerType(context, false, () {
              cubit.changeType(state.wholesalers[index].id).then((value) {
                cubit.getAll();
              });
              Navigator.maybePop(context);
            });
    },
  );
}
