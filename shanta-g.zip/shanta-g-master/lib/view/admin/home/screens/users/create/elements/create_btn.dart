import 'package:flutter/material.dart';

Widget createBtn(BuildContext context, onPressed) => Padding(
  padding: const EdgeInsets.all(30),
  child: Row(
    mainAxisAlignment: MainAxisAlignment.end,
    children: [
      ElevatedButton(
            onPressed: onPressed,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              surfaceTintColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
                side: const BorderSide(color: Colors.white, width: 2),
              ),
              fixedSize: Size(
                MediaQuery.sizeOf(context).width * 0.4,
                MediaQuery.sizeOf(context).height * 0.06,
              ),
            ),
            child: _btnTitle(),
          ),
    ],
  ),
);

Widget _btnTitle() {
  return const Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Icon(
        Icons.check_circle,
        color: Colors.white,
      ),
      Text(
        'حفظ',
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    ],
  );
}
