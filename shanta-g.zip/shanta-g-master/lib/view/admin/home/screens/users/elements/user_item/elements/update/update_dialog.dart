import 'package:flutter/material.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/update/elements/shanta_type.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/update/elements/wholesaler_type.dart';

import '../controllers.dart';
import '../field_item/fields.dart';
import '/data/constant/app_colors.dart';
import '/view/global_elements/widgets/styles.dart';

Widget updateDialog(BuildContext context, Key formKey, onTap,
    {type, int? index}) {
  return AlertDialog(
    title: Text(
      'ادخل المعلومات الجديدة',
      style: Styles.label0.copyWith(
        color: AppColors.primaryText,
      ),
    ),
    content: Form(
      key: formKey,
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            if (type != null)
              type == 'wholesaler'
                  ? wholesalerType(context, index!)
                  : shantaType(context, index!),
            fields(
              userControllers['name']!,
              userControllers['email']!,
              userControllers['phone']!,
              userControllers['address']!,
            ),
            const SizedBox(
              height: 10,
            ),
            _editBtn(onTap),
          ],
        ),
      ),
    ),
  );
}

ElevatedButton _editBtn(onTap) => ElevatedButton(
      onPressed: onTap,
      style: ElevatedButton.styleFrom(
        padding: EdgeInsets.zero,
        backgroundColor: AppColors.primary,
        fixedSize: const Size(50, 30),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
      child: _btnTitle(),
    );

Text _btnTitle() => Text(
      'تعديل',
      style: Styles.buttonText.copyWith(
        color: AppColors.background,
        fontSize: 18,
      ),
    );
