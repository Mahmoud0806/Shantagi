import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';
import 'custom_btn.dart';

Widget itemBtn(VoidCallback edit, VoidCallback delete) => SizedBox(
      child: Row(
        children: _children(edit, delete),
      ),
    );

List<Widget> _children(VoidCallback edit, VoidCallback delete) => [
      customBtn(Icons.edit_outlined, AppColors.secondarySec, edit),
      customBtn(Icons.delete_outline, AppColors.error, delete),
    ];
