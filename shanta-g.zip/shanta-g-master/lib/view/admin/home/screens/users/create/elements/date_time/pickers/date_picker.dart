import 'package:flutter/material.dart';

Future<DateTime?> pickDate(BuildContext context) async {
  DateTime firstDate = DateTime.now();
  DateTime lastDate = DateTime(firstDate.year + 1);
  final selectedDate = await showDatePicker(
    context: context,
    initialDate: firstDate,
    firstDate: firstDate,
    lastDate: lastDate,
  );
  return selectedDate;
}
