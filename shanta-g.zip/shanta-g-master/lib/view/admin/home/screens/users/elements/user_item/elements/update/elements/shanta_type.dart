import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/users/shanta/admin_shanta_cubit.dart';

import 'dealer_type.dart';

Widget shantaType(BuildContext context, int index) {
  var cubit = BlocProvider.of<AdminShantaCubit>(context);
  return BlocConsumer<AdminShantaCubit, AdminShantaState>(
    listener: (context, state) {
      if (state.status == ShantaStatus.success) {
        Navigator.pop(context);
      }
    },
    builder: (context, state) {
      return state.status == ShantaStatus.loading
          ? const Center(child: CircularProgressIndicator())
          : changeDealerType(context, true, () {
              cubit.changeType(state.shantas[index].id).then((value) {
                cubit.getAll();
              }).then((value) {
                Navigator.maybePop(context);
              });
            });
    },
  );
}
