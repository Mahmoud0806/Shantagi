import 'package:flutter/material.dart';

Map<String, TextEditingController> userControllers = {
  'name': TextEditingController(),
  'email': TextEditingController(),
  'address': TextEditingController(),
  'phone': TextEditingController(),
  'password': TextEditingController(),
};


clearControllers() {
  userControllers['name']!.clear();
  userControllers['email']!.clear();
  userControllers['address']!.clear();
  userControllers['phone']!.clear();
  userControllers['password']!.clear();
}
