// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';
//
// Widget dealerType() {
//   var cubit = BlocProvider.of<AdminWholesalersCubit>(context);
//   return Column(
//       children: [
//         const Text('نوع التاجر'),
//         Row(
//           mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//           children: [
//             const Text('تاجر جملة'),
//             BlocConsumer<AdminWholesalersCubit, AdminWholesalersState>(
//               listener: (context, state) {
//                 if ('state.status' == 'WholesalerTypeStatus.loaded') {}
//               },
//               builder: (context, state) {
//                 return 'state.status' == 'WholesalerTypeStatus.loading'
//                     ? const Center(
//                         child: CircularProgressIndicator(),
//                       )
//                     : Switch(
//                         value: 'state.type' == '',
//                         onChanged: (newValue) {
//                           AdminWholesalersCubit
//                               .changeType(controller
//                                   .wholesalers[index].id!);
//                         },
//                       );
//               },
//             ),
//             const Text('تاجر شنطة'),
//           ],
//         ),
//       ],
//     );
// }
