import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/users/retailer/admin_retailers_cubit.dart';
import 'user_item/elements/controllers.dart';
import 'user_item/elements/update/update_dialog.dart';
import 'user_item/user_item.dart';

Widget retailersWidget(BuildContext context) {
  var cubit = BlocProvider.of<AdminRetailersCubit>(context);
  var formKey = GlobalKey<FormState>();
  return RefreshIndicator(
    onRefresh: cubit.getAll,
    child: SizedBox(
      child: BlocBuilder<AdminRetailersCubit, AdminRetailersState>(
        builder: (context, state) {
          return ListView.builder(
            itemCount: state.retailers.length,
            itemBuilder: (context, index) => userItem(
              state.retailers[index],
              () {
                showDialog(
                    context: context,
                    builder: (con) {
                      return updateDialog(context, formKey, () {
                        _updateData(cubit, state, index, context);
                      });
                    });
              },
              () {
                cubit.delete(state.retailers[index].id);
              },
            ),
          );
        },
      ),
    ),
  );
}

void _updateData(AdminRetailersCubit cubit, AdminRetailersState state,
    int index, BuildContext context) {
  cubit
      .update(
    state.retailers[index].copyWith(
      name: userControllers['name']!.text.isNotEmpty
          ? userControllers['name']!.text
          : null,
      email: userControllers['email']!.text.isNotEmpty
          ? userControllers['email']!.text
          : null,
      phone: userControllers['phone']!.text.isNotEmpty
          ? userControllers['phone']!.text
          : null,
      address: userControllers['address']!.text.isNotEmpty
          ? userControllers['address']!.text
          : null,
    ),
  )
      .then((value) {
    clearControllers();
    Navigator.maybePop(context);
  });
}
