import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/global_elements/app_bar/app_bar.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/users/clients/admin_clients_cubit.dart';
import '/logic/cubits/date_time/date_time_cubit.dart';
import '/models/user.dart';
import '/view/admin/home/screens/users/create/elements/create_user.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/controllers.dart';

class CreateClient extends StatelessWidget {
  const CreateClient({super.key});

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<AdminClientsCubit>(context);
    var dateCubit = BlocProvider.of<DateTimeCubit>(context);
    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: customAppBar('',context, showBack: true, background: AppColors.primary, foreground: AppColors.background),
      body: BlocConsumer<AdminClientsCubit, AdminClientsState>(
        listener: (context, state) {},
        builder: (context, state) {
          return CreateUserWidget(
            onPressed: () {
              cubit
                  .create(
                User.initial().copyWith(
                  name: userControllers['name']!.text,
                  email: userControllers['email']!.text,
                  password: userControllers['password']!.text,
                  phone: userControllers['phone']!.text,
                  address: userControllers['address']!.text,
                  expireDate: dateCubit.state.date.toString(),
                ),
              )
                  .then((value) {
                if (state.status == ClientsStatus.success ||
                    state.status == ClientsStatus.added) {
                  Navigator.pop(context);
                }
              });
            },
            userType: 'Client',
          );
        },
      ),
    );
  }
}
