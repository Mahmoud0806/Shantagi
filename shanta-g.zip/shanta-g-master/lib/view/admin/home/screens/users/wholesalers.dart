import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';

import '/view/admin/home/screens/users/elements/wholesalers_widget.dart';

class AdminWholesalersPage extends StatefulWidget {
  const AdminWholesalersPage({super.key});

  @override
  State<AdminWholesalersPage> createState() => _AdminWholesalersPageState();
}

class _AdminWholesalersPageState extends State<AdminWholesalersPage> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await BlocProvider.of<AdminWholesalersCubit>(context).getAll();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return wholesalersWidget(context);
  }
}
