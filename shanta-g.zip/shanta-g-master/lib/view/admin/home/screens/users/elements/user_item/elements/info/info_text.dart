import 'package:flutter/material.dart';

Widget infoText(String data,bool isTitle, {double? width}) => SizedBox(
      width: width,
      child: Text(
        data,
        maxLines: 1,
        style: isTitle ? _titleStyle() : _valueStyle(),
      ),
    );

TextStyle _titleStyle() => const TextStyle(
      fontWeight: FontWeight.bold,
      overflow: TextOverflow.ellipsis,
      fontSize: 16,
    );

TextStyle _valueStyle() => const TextStyle(
      fontSize: 14,
    );
