import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/users/shanta/admin_shanta_cubit.dart';

import 'elements/shanta_widget.dart';

class AdminShantaPage extends StatefulWidget {
  const AdminShantaPage({super.key});

  @override
  State<AdminShantaPage> createState() => _AdminShantaPageState();
}

class _AdminShantaPageState extends State<AdminShantaPage> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await BlocProvider.of<AdminShantaCubit>(context).getAll();
    });
    super.initState();
  }
  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      child: shantasWidget(context, formKey),
    );
  }
}
