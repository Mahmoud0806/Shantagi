import 'package:flutter/material.dart';

Widget customBtn(IconData icon, Color color, VoidCallback onPressed) =>
    IconButton(
      onPressed: onPressed,
      icon: _btnIcon(icon, color),
    );

_btnIcon(IconData icon, Color color) => Icon(
      icon,
      color: color,
      size: 24,
    );
