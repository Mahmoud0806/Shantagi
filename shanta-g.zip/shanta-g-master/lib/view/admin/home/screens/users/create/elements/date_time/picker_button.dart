import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

class PickerButton extends StatelessWidget {
  final String title;
  final VoidCallback onPressed;

  const PickerButton(this.title, this.onPressed, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return _buttonWidget(context);
  }

  Widget _buttonWidget(BuildContext context) => SizedBox(
        child: _button(context),
      );

  ElevatedButton _button(BuildContext context) => ElevatedButton(
        onPressed: onPressed,
        style: _buttonStyle(context),
        child: _buttonTitle(context),
      );

  ButtonStyle _buttonStyle(BuildContext context) => ElevatedButton.styleFrom(
        fixedSize: Size(
          MediaQuery.sizeOf(context).width * .8,
          MediaQuery.sizeOf(context).height * .03,
        ),
        shape: _buttonShape(),
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
      );

  OutlinedBorder _buttonShape() => RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: const BorderSide(
          width: 1,
          color: AppColors.background,
        ),
      );

  Row _buttonTitle(BuildContext context) => Row(
        children: [
          const Spacer(),
          Text(
            title,
            style: _buttonTitleStyle(context),
          ),
          const Spacer(),
          const Icon(
            Icons.date_range,
            color: Colors.white,
            size: 25,
          ),
        ],
      );

  TextStyle _buttonTitleStyle(BuildContext context) => TextStyle(
        fontSize: 18,
        color: Theme.of(context).scaffoldBackgroundColor,
        fontWeight: FontWeight.bold,
      );
}
