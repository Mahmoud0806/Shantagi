import 'package:flutter/material.dart';
import '/view/global_elements/widgets/styles.dart';

Widget fieldTitle(String title, {Color? color}) => Padding(
  padding: const EdgeInsets.all(8.0),
  child: Text(title, style: Styles.label1.copyWith(
    color: color
  ),),
);
