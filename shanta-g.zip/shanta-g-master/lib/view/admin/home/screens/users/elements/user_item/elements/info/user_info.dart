import 'package:flutter/material.dart';

import '/models/user.dart';
import 'user_info_item.dart';

Widget userInfo(User user) => SizedBox(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: _children(user),
      ),
    );

List<Widget> _children(User user) => [
      userInfoItem('الاسم: ', user.name),
      userInfoItem('البريد: ', user.email),
      userInfoItem('رقم الموبايل: ', user.phone),
      userInfoItem('العنوان: ', user.address),
    ];
