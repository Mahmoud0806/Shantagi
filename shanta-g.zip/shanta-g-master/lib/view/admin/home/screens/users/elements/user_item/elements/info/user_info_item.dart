import 'package:flutter/material.dart';
import 'info_text.dart';

Widget userInfoItem(title, value) => Padding(
  padding: const EdgeInsets.all(8.0),
  child: SizedBox(
        child: Row(
          children: _children(title, value),
        ),
      ),
);

List<Widget> _children(title, value) => [
      infoText(title, true),
      infoText(value, false, width: 130),
    ];
