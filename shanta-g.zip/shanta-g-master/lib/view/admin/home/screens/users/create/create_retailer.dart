import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/data/constant/app_colors.dart';
import '/view/global_elements/app_bar/app_bar.dart';

import '/logic/cubits/admin/users/retailer/admin_retailers_cubit.dart';
import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';
import '/models/user.dart';
import '/view/admin/home/screens/users/create/elements/create_user.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/controllers.dart';

class CreateRetailer extends StatelessWidget {
  const CreateRetailer({super.key});

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<AdminRetailersCubit>(context);
    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: customAppBar('',context, showBack: true, background: AppColors.primary, foreground: AppColors.background),
      body: BlocConsumer<AdminRetailersCubit, AdminRetailersState>(
        listener: (context, state) {},
        builder: (context, state) {
          return CreateUserWidget(
            onPressed: () {
              cubit
                  .create(
                User.initial().copyWith(
                  name: userControllers['name']!.text,
                  email: userControllers['email']!.text,
                  password: userControllers['password']!.text,
                  phone: userControllers['phone']!.text,
                  address: userControllers['address']!.text,
                ),
              )
                  .then((value) {
                if (state.status == RetailersStatus.success ||
                    state.status == RetailersStatus.added) {
                  Navigator.pop(context);
                }
              });
            },
            userType: 'Retailer',
          );
        },
      ),
    );
  }
}
