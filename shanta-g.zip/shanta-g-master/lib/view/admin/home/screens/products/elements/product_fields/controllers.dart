import 'package:flutter/material.dart';

Map<String, TextEditingController> productControllers = {
  'name': TextEditingController(),
  'email': TextEditingController(),
  'address': TextEditingController(),
  'phone': TextEditingController(),
  'password': TextEditingController(),
};


clearControllers() {
  productControllers['name']!.clear();
  productControllers['category']!.clear();
  productControllers['description']!.clear();
  productControllers['weight']!.clear();
  productControllers['karat']!.clear();
}
