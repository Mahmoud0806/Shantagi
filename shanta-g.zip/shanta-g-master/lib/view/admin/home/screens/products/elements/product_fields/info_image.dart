import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/products/products_cubit.dart';
import 'no_image_selected.dart';

Widget infoImage(BuildContext context) => Padding(
      padding: const EdgeInsets.all(8),
      child: SizedBox(
        height: MediaQuery.sizeOf(context).height * .3,
        width: MediaQuery.sizeOf(context).width * .8,
        // child: Image.file(
        child: BlocBuilder<ProductsCubit, ProductsState>(
          builder: (context, state) {
            return state.product.images.isEmpty
            || state.product.images.first.attachment == ''
                ? noImageSelected(context)
                : Image.file(
                    File(state.product.images.first.attachment),
                    fit: BoxFit.fill,
                  );
          },
        ),
      ),
    );
