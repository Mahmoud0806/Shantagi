import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/products/products_cubit.dart';

import '/data/constant/app_colors.dart';

Widget noImageSelected(BuildContext context) => Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text(
            'لا توجد صورة مختارة',
            style: TextStyle(color: AppColors.secondarySec),
          ),
          TextButton(
            onPressed: () {
                var cubit = BlocProvider.of<ProductsCubit>(context);
                cubit.getImage();
            },
            child: const Text(
              'إختر صورة',
              style: TextStyle(color: AppColors.background),
            ),
          ),
        ],
      ),
    );
