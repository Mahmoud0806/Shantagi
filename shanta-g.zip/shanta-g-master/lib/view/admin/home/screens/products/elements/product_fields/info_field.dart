import 'package:flutter/material.dart';

import '/view/global_elements/fields/custom_text_field.dart';

Widget infoField(BuildContext context, title, controller) => Column(
  crossAxisAlignment: CrossAxisAlignment.start,
      children: _children(controller, title),
    );

List<Widget> _children(controller, title) => [
      _title(title),
      _field(controller, title),
    ];

Padding _title(title) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 5),
      child: Text(
        title,
        style: _titleStyle(),
      ),
    );
}

TextStyle _titleStyle() {
  return const TextStyle(
        fontSize: 18,
        color: Colors.white,
      );
}

Padding _field(controller, title) {
  return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 35),
      child: customTextField(
        controller: controller,
        label: title,
      ),
    );
}
