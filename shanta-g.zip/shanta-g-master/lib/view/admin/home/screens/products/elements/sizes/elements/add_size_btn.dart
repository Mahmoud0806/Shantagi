import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/products/products_cubit.dart';
import '/data/constant/app_colors.dart';

TextButton addSizeBtn(BuildContext context, key) {
  var cubit = BlocProvider.of<ProductsCubit>(context);
  return TextButton(
    onPressed: () {
      if (key.currentState != null && key.currentState!.validate()) {
        // controller.addSize();
        cubit.addSize(cubit.sizeController.text);
        cubit.sizeController.clear();
        print(cubit.state.sizes.toString());
        FocusManager.instance.primaryFocus?.unfocus();
      }
    },
    child: _btnTitle(),
  );
}

Text _btnTitle() => Text(
      'إضافة القياس',
      style: _titleStyle(),
    );

TextStyle _titleStyle() => const TextStyle(
      fontSize: 18,
      color: AppColors.primary,
    );
