import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/products/products_cubit.dart';

Widget createBtn(BuildContext context, onPressed) => Padding(
      padding: const EdgeInsets.all(30),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          BlocBuilder<ProductsCubit, ProductsState>(
            builder: (context, state) {
              return state.status == ProductsStatus.loading
                  ? const Center(
                      child: CircularProgressIndicator(),
                    )
                  : ElevatedButton(
                      onPressed: onPressed,
                      style: _btnStyle(context),
                      child: _btnTitle(),
                    );
            },
          ),
        ],
      ),
    );

ButtonStyle _btnStyle(BuildContext context) {
  return ElevatedButton.styleFrom(
    backgroundColor: Colors.transparent,
    surfaceTintColor: Colors.transparent,
    shadowColor: Colors.transparent,
    shape: _shape(),
    fixedSize: Size(
      MediaQuery.sizeOf(context).width * .8,
      MediaQuery.sizeOf(context).height * .06,
    ),
  );
}

RoundedRectangleBorder _shape() {
  return RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(10),
    side: const BorderSide(color: Colors.white, width: 2),
  );
}

Widget _btnTitle() {
  return const Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      Icon(
        Icons.check_circle,
        color: Colors.white,
      ),
      Text(
        'حفظ',
        style: TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: Colors.white,
        ),
      ),
    ],
  );
}
