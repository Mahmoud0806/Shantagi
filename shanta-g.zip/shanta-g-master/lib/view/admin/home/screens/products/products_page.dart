import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:path_provider/path_provider.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/products/products_cubit.dart';
import '/logic/cubits/cubits.dart';
import '/logic/cubits/filters/filters_cubit.dart';
import '/view/admin/home/screens/products/elements/product_item.dart';
import '/view/global_elements/filters.dart';
import '../../../../global_elements/search_bar.dart';

class AdminProductsPage extends StatefulWidget {
  const AdminProductsPage({super.key});

  @override
  State<AdminProductsPage> createState() => _AdminProductsPageState();
}

class _AdminProductsPageState extends State<AdminProductsPage> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await BlocProvider.of<ProductsCubit>(context).getAll();
      var catCubit = BlocProvider.of<CategoriesCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      var wholeCubit = BlocProvider.of<AdminWholesalersCubit>(context);
      var shantaCubit = BlocProvider.of<AdminShantaCubit>(context);
      await catCubit.getAll();
      await wholeCubit.getAll();
      await shantaCubit.getAll();
      _scrollController.addListener(_loadMoreData);
      filterCubit.fillDealers(
          [...wholeCubit.state.wholesalers, ...shantaCubit.state.shantas]);
      filterCubit.fillCats(catCubit.state.categories);
    });
    super.initState();
  }

  final _scrollController = ScrollController();

  void _loadMoreData() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent) {
      var cubit = BlocProvider.of<ProductsCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      cubit.getAll(
          params: filterCubit.setSelectedParams(),
          saveOld: true,
          savePage: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    var controller = TextEditingController();
    var cubit = BlocProvider.of<ProductsCubit>(context);
    return SizedBox(
      child: RefreshIndicator(
        onRefresh: cubit.getAll,
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Expanded(
                  child: searchBar('إبحث', controller, (s) {
                    cubit.getAll(params: '?name=${controller.text}');
                  }),
                ),
                _filter(context),
              ],
            ),
            _products(),
          ],
        ),
      ),
    );
  }

  BlocBuilder<ProductsCubit, ProductsState> _products() =>
      BlocBuilder<ProductsCubit, ProductsState>(
        builder: (context, state) {
          return Expanded(
            child: GridView.builder(
              controller: _scrollController,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
              ),
              itemCount: state.products.length + 1,
              itemBuilder: (context, index) => index == state.products.length
                  ? (state.status == ProductsStatus.loading
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : const SizedBox.shrink())
                  : ProductItem(url: 'URL', index: index),
            ),
          );
        },
      );

  Widget _filter(BuildContext context) => IconButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (BuildContext context) => dialog(
              context,
              showDealers: true,
            ),
          );
        },
        icon: const Icon(
          Icons.filter_alt_outlined,
          color: AppColors.secondarySec,
          size: 25,
        ),
      );
}
