import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/products/products_cubit.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/global_elements/products/details/product_details.dart';
import '../../../../../data/constant/app_colors.dart';

class AdminProductDetails extends StatelessWidget {
  final int index;

  const AdminProductDetails({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('', context,
          showBack: true, foreground: AppColors.primary),
      body: BlocBuilder<ProductsCubit, ProductsState>(
        builder: (context, state) {
          return productDetails(
            context,
            state.products[index],
          );
        },
      ),
    );
  }
}
