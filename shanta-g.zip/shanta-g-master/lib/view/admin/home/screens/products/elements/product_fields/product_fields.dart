import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/products/elements/product_fields/controllers.dart';

import '/logic/cubits/admin/products/products_cubit.dart';
import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/view/admin/home/screens/products/elements/categoy_info.dart';
import '/view/admin/home/screens/products/elements/select_dealer.dart';
import '../sizes/product_size.dart';
import 'create_btn.dart';
import 'info_field.dart';
import 'info_image.dart';

Widget productsFields(BuildContext context, Key key) {
  return SingleChildScrollView(
    child: Column(
      children: _children(context, key),
    ),
  );
}

List<Widget> _children(BuildContext context, Key key) {
  var cubit = BlocProvider.of<ProductsCubit>(context);
  return [
    const SizedBox(height: 50),
    infoField(context, 'اسم المنتج', cubit.nameController),
    // infoField(context, 'التصنيف', TextEditingController()),
    selectCategory(context),
    selectDealer(context),
    infoField(context, 'وصف المنتج', cubit.descController),
    infoField(context, 'الوزن التقريبي للمنتج', cubit.weightController),
    infoField(context, 'عيار المنتج', cubit.karatController),
    infoImage(context),
    addProductSizes(context, key),
    BlocBuilder<ProductsCubit, ProductsState>(
      builder: (context, state) {
        return createBtn(
          context,
              () {
            // var cubit = BlocProvider.of<ProductsCubit>(context);
            var wholesalerCubit = BlocProvider.of<AdminWholesalersCubit>(
                context);
            var categoryCubit = BlocProvider.of<CategoriesCubit>(context);
            print(state.sizes);
            cubit.createProduct(
              cubit.state.product.copyWith(
                name: cubit.nameController.text,
                description: cubit.descController.text,
                weight: double.tryParse(cubit.weightController.text),
                karat: cubit.karatController.text,
                category: categoryCubit.state.catItem.value,
                sizes: state.sizes,
                user: cubit.state.product.user.copyWith(
                  id: int.tryParse(
                      wholesalerCubit.state.wholesalerItem.value ?? '-1000') ??
                      -1000,
                ),
              ),
              cubit.selectedImage,
            ).then((value) {
              if (cubit.state.status == ProductsStatus.loaded) {
                // cubit.clearControllers();
                Navigator.maybePop(context);
              }
            });
          },
        );
      },
    ),
  ];
}
