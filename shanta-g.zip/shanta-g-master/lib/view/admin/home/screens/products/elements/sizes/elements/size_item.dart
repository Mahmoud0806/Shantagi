import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/products/products_cubit.dart';

Widget sizeItem(String data, int index, BuildContext context) {
  var cubit = BlocProvider.of<ProductsCubit>(context);
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(data),
      InkWell(
        onTap: () {
          cubit.removeSize(index);
          // controller.listDynamic.removeAt(index);
        },
        child: const Icon(
          Icons.delete_outline,
          color: Colors.red,
          size: 17,
        ),
      )
    ],
  );
}
