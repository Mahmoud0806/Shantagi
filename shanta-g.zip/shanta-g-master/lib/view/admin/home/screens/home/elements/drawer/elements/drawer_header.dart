import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget drawerHeader() => DrawerHeader(
      decoration: const BoxDecoration(
        color: AppColors.secondary,
      ),
      child: Row(
        children: [
          const Hero(
            tag: 'hero',
            child: Icon(Icons.person),
            // child: SvgPicture.asset(AppImages.person),
          ),
          const SizedBox(width: 20),
          Text(
            'Admin',
            style: _textStyle(),
          ),
        ],
      ),
    );

TextStyle _textStyle() {
  return const TextStyle(
    color: AppColors.primary,
    fontSize: 22,
    fontWeight: FontWeight.bold,
  );
}
