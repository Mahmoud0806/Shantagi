import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/users/create/create_retailer.dart';

import '/data/constant/app_images.dart';
import '/logic/cubits/admin/users/retailer/admin_retailers_cubit.dart';
import '/view/users/retailer/home/retailer_home.dart';
import '../drawer_tile.dart';

Widget addRetailerTile(BuildContext context) => DrawerTile(
      title: 'إضافة تاجر مفرق',
      function: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => BlocProvider(
                create: (context) => AdminRetailersCubit(),
                // create: (context) => AdminAddTraderController(),
                child: const CreateRetailer()
                // child: const AddTraderScreen(
                //   traderType: 'retailer',
                // ),
                ),
          ),
        );
        // controller.goToAddRetailer(context);
      },
      image: AppImages.group,
    );
