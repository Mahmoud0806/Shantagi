import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/permissions/visibility/visibility_cubit.dart';

Widget shantaVisibility(BuildContext context) {
  var showDealersCubit = BlocProvider.of<VisibilityCubit>(context);
  return Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: Row(
        children: [
          const SizedBox(width: 20),
          BlocConsumer<VisibilityCubit, VisibilityState>(
            listener: (context, state) {
              if(state.status == VisibilityStatus.changed){

              showDealersCubit.getVisibility();
              }
            },
            builder: (context, state) {
              var showDealersCubit = BlocProvider.of<VisibilityCubit>(context);
              return state.status != VisibilityStatus.loading
                  ? _checkbox(state, showDealersCubit)
                  : _indicator();
            },
          ),
          const SizedBox(width: 20),
          _titile(),
        ],
      ),
    );
}

Text _titile() {
  return const Text(
    'إظهار تاجر شنطة',
    style: TextStyle(fontSize: 18, fontFamily: 'Sukar'),
  );
}

Center _indicator() {
  return const Center(
    child: CircularProgressIndicator(),
  );
}

Checkbox _checkbox(VisibilityState state, VisibilityCubit showDealersCubit) {
  return Checkbox(
    activeColor: AppColors.secondarySec,
      value: state.shantaVisibility,
      onChanged: (value) {
        showDealersCubit.toggleVisibility(state.wholesalersVisibility, !state.shantaVisibility).then((value) {
          // showDealersCubit.getVisibility();
        });
      });
}
