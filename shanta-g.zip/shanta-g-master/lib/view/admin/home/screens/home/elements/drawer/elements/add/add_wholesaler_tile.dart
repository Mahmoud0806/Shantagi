import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/users/create/create_wholesaler.dart';

import '/data/constant/app_images.dart';
import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';
import '/view/admin/home/screens/users/wholesalers.dart';
import '../drawer_tile.dart';

Widget addWholesalerTile(BuildContext context) => DrawerTile(
      title: 'إضافة تاجر جملة',
      function: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => BlocProvider(
              create: (context) => AdminWholesalersCubit(),
              child: const CreateWholesaler(),
            ),
          ),
        );
        // controller.goToAddWholesaler(context);
      },
      image: AppImages.group,
    );
