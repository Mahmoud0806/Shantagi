import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_images.dart';
import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/view/admin/home/screens/permissions/permissions_screen.dart';
import 'drawer_tile.dart';

Widget accessControlTile(BuildContext context) => DrawerTile(
      title: 'الصلاحيات',
      function: () {
        // controller.goToAddCategory(context);
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => BlocProvider(
                create: (context) => DealerAccessCubit(),
                child: const PermissionsScreens()),
            // child: const UserPermissionsScreen()),
          ),
        );
      },
      image: AppImages.category,
    );
