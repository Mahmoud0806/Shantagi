import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/permissions/visibility/visibility_cubit.dart';
import 'elements/access_permission_tile.dart';
import 'elements/add/add_category_tile.dart';
import 'elements/add/add_client_tile.dart';
import 'elements/add/add_product_tile.dart';
import 'elements/add/add_retailer_tile.dart';
import 'elements/add/add_shanta_tile.dart';
import 'elements/add/add_wholesaler_tile.dart';
import 'elements/drawer_header.dart';
import 'elements/log_out.dart';
import 'elements/report_tile.dart';
import 'elements/visibility/shanta.dart';
import 'elements/visibility/wholesaler.dart';

class AdminDrawer extends StatefulWidget {
  const AdminDrawer({super.key});

  @override
  State<AdminDrawer> createState() => _AdminDrawerState();
}

class _AdminDrawerState extends State<AdminDrawer> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      var cubit = BlocProvider.of<VisibilityCubit>(context);
      cubit.getVisibility();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      width: MediaQuery.sizeOf(context).width * 0.75,
      child: ListView(
        padding: EdgeInsets.zero,
        children: _children(context),
      ),
    );
  }

  List<Widget> _children(BuildContext context) => [
        drawerHeader(),
        addShantaTile(context),
        addWholesalerTile(context),
        addRetailerTile(context),
        addClientTile(context),
        addCategoryTile(context),
        addProductTile(context),
        accessControlTile(context),
        wholesalerVisibility(),
        shantaVisibility(context),
        reportTile(),
        logout(context),
      ];
}
