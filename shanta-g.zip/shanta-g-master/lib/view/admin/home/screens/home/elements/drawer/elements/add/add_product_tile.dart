import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/products/add_product.dart';
import '/data/constant/app_images.dart';
import '/logic/cubits/admin/products/products_cubit.dart';
import '/view/admin/home/screens/products/products_page.dart';

import '../drawer_tile.dart';

Widget addProductTile(BuildContext context) => DrawerTile(
      title: 'إضافة منتج',
      function: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => BlocProvider(
                create: (context) => ProductsCubit(),
                child: const AddProductScreen()),
          ),
        );
        // controller.goToAddProduct(context);
      },
      image: AppImages.diamond,
    );
