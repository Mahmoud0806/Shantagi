import 'package:flutter/material.dart';
import '/view/admin/home/screens/home/elements/tabs/bar_item.dart';

Widget barTabs() => TabBar(
  isScrollable: true,
      tabs: [
        barItem('الطلبات'),
        barItem('طلبات الزبائن'),
        barItem('التصنيفات'),
        barItem('المنتجات'),
        barItem('تجار الشنطة'),
        barItem('تجار الجملة'),
        barItem('تجار المفرق'),
        barItem('الزبائن'),
      ],
    );
