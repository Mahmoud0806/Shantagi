import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/users/create/create_client.dart';
import '/data/constant/app_images.dart';
import '/logic/cubits/admin/users/clients/admin_clients_cubit.dart';
import '/view/users/client/home/client_home.dart';

import '../drawer_tile.dart';

Widget addClientTile(BuildContext context) => DrawerTile(
  title: 'إضافة زبون',
  function: () {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => MultiBlocProvider(providers: [
          BlocProvider(
            create: (context) => AdminClientsCubit(),
          ),
        ], child: const CreateClient()),
      ),
    );
    // controller.goToAddWholesaler(context);
  },
  image: AppImages.group,
);