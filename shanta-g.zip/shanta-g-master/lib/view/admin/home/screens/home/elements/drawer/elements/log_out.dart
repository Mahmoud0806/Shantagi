import 'package:flutter/material.dart';
import 'package:shantagi/data/notifications/fcm_token_handler.dart';

import '/data/constant/storage/local_storage_services.dart';
import '/view/auth/login/login.dart';
import '/view/global_elements/widgets/styles.dart';

Padding logout(BuildContext context) => Padding(
      padding: const EdgeInsets.only(top: 15, bottom: 25),
      child: GestureDetector(
        onTap: () {
          // controller.logout(context);
          deleteToken();
          LocalStorage.removeAllLocal();
          Navigator.maybePop(context);
          Navigator.maybePop(context);
          Navigator.maybePop(context);
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => const LoginScreen(),
            ),
          );
        },
        child: Row(
          children: [
            const SizedBox(
              width: 30,
            ),
            Text(
              'تسجيل الخروج',
              style: Styles.buttonText.copyWith(color: Colors.red),
            ),
          ],
        ),
      ),
    );
