import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/reports/report_cubit.dart';

Widget reportTile() => Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          Row(
            children: [
              const SizedBox(width: 20),
              Padding(
                padding: const EdgeInsets.only(bottom: 20, right: 40),
                child: BlocBuilder<ReportCubit, ReportState>(
                  builder: (context, state) {
                    var reportCubit = BlocProvider.of<ReportCubit>(context);
                    return state.status == ReportStatus.loading
                        ? _indicator()
                        : _elevatedButton(reportCubit);
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );

ElevatedButton _elevatedButton(ReportCubit reportCubit) {
  return ElevatedButton(
    onPressed: () {
      reportCubit.getReportFile();
    },
    child: _btnTitle(),
  );
}

Text _btnTitle() {
  return Text(
    ' التقارير  ',
    style: _textStyle(),
  );
}

TextStyle _textStyle() {
  return const TextStyle(
    fontSize: 18,
    color: AppColors.primary,
  );
}

Center _indicator() {
  return const Center(
    child: CircularProgressIndicator(),
  );
}
