import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/categories/create.dart';
import '/data/constant/app_images.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/view/admin/home/screens/users/clients.dart';

import '../drawer_tile.dart';

Widget addCategoryTile(BuildContext context) => DrawerTile(
      title: 'إضافة تصنيف',
      function: () {
        // controller.goToAddCategory(context);
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => BlocProvider(
                create: (context) => CategoriesCubit(),
                child: const CreateCatScreen()),
          ),
        );
      },
      image: AppImages.diamond,
    );
