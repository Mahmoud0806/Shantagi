import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/users/create/create_shanta.dart';

import '../drawer_tile.dart';
import '/data/constant/app_images.dart';
import '/logic/cubits/admin/users/shanta/admin_shanta_cubit.dart';

Widget addShantaTile(BuildContext context) => DrawerTile(
      title: ' إضافة تاجر شنطة',
      function: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (context) => MultiBlocProvider(
              providers: [
                BlocProvider(
                  create: (context) => AdminShantaCubit(),
                ),
              ],
              child: const CreateShanta(),
            ),
          ),
          // ], child: AddSubAdminScreen())),
        );
        // controller.goToAddProduct(context);
      },
      image: AppImages.group,
    );
