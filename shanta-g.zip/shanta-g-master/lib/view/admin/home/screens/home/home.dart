import 'package:flutter/material.dart';
import '/view/admin/home/screens/categories/categories_page.dart';
import '/view/admin/home/screens/orders/clients_orders.dart';
import '/view/admin/home/screens/orders/dealers_orders.dart';
import '/view/admin/home/screens/products/products_page.dart';
import '/view/admin/home/screens/users/clients.dart';
import '/view/admin/home/screens/users/retailers.dart';
import '/view/admin/home/screens/users/shanta.dart';
import '/view/admin/home/screens/users/wholesalers.dart';

import 'elements/drawer/drawer.dart';
import 'elements/tabs/tabs_bar.dart';

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});

  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          // actions: [barTabs()],
        ),
        drawer: const AdminDrawer(),
        body: DefaultTabController(
          length: 8,
          child: Column(
            children: _children(),
          ),
        ),
      ),
    );
  }

  List<Widget> _children() => [
        barTabs(),
        Expanded(
          child: TabBarView(
            children: _pages(),
          ),
        ),
      ];

  List<Widget> _pages() => [
        const AdminDealersOrdersPage(),
        const AdminClientsOrdersPage(),
        const CategoriesPage(), // categories
        const AdminProductsPage(),
        const AdminShantaPage(),
        const AdminWholesalersPage(),
        const AdminRetailersPage(),
        const AdminClientsPage(),
      ];
}
