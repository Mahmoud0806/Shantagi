import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget barItem(String title) => Container(
  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
  decoration: _decoration(),
  child: _itemTitle(title),
);

BoxDecoration _decoration() {
  return BoxDecoration(
        borderRadius: BorderRadius.circular(7),
        border: Border.all(
          color: AppColors.primary,
        ),
      );
}

Text _itemTitle(String title) {
  return Text(
    title,
    style: _titleStyle(),
  );
}

TextStyle _titleStyle() {
  return const TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.bold,
  );
}
