import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/permissions/visibility/visibility_cubit.dart';

Widget wholesalerVisibility() => Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: Row(
        children: [
          const SizedBox(
            width: 20,
          ),
          BlocBuilder<VisibilityCubit, VisibilityState>(
            builder: (context, state) {
              var visibilityCubit = BlocProvider.of<VisibilityCubit>(context);
              return state.status != VisibilityStatus.loading
                  ? _checkbox(state, visibilityCubit)
                  : _indicator();
            },
          ),
          const SizedBox(width: 20),
          _title(),
        ],
      ),
    );

Text _title() => const Text(
      'إظهار تاجر جملة',
      style: TextStyle(fontSize: 18),
    );

Center _indicator() => const Center(
      child: CircularProgressIndicator(),
    );

Checkbox _checkbox(VisibilityState state, VisibilityCubit showDealersCubit) =>
    Checkbox(
      activeColor: AppColors.secondarySec,
      checkColor: AppColors.background,
      value: state.wholesalersVisibility,
      onChanged: (value) {
        showDealersCubit.toggleVisibility(!state.wholesalersVisibility, state.shantaVisibility);
      },
    );
