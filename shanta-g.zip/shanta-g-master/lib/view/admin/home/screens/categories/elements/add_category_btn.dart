import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';
import '/view/global_elements/widgets/styles.dart';

FloatingActionButton addCategoryBtn(BuildContext context, Key formKey) =>
    FloatingActionButton(
      onPressed: () {
        showDialog(
            context: context,
            builder: (context) {
              return AlertDialog(
                title: Text('ادخل اسم المنتح',
                    style: TextStyle().copyWith(color: AppColors.primaryText)),
                content: Form(
                  key: formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // MyTextField(
                      //   // controller: controller.nameController,
                      //   // validate: (_) => controller.inputValidator(),
                      // ),
                      const SizedBox(height: 15),
                      InkWell(
                        onTap: () {
                          // if (formKey.currentState != null &&
                          //     formKey.currentState!.validate()) {
                          //   controller.addCategory();
                          //   Navigator.pop(context);
                          // }
                          // controller.addCategory(context);
                        },
                        child: Container(
                          padding: EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                            color: AppColors.primary,
                          ),
                          child: Text(
                            'إضافة',
                            style: Styles.buttonText.copyWith(
                              color: AppColors.background,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            });
      },
      backgroundColor: AppColors.primary,
      child: Icon(Icons.add),
    );
