import 'package:flutter/material.dart';

Widget catText(String data, {FontWeight? weight}) => Padding(
      padding: const EdgeInsets.only(right: 15.0),
      child: Text(
        data,
        style: _textStyle(weight),
      ),
    );

TextStyle _textStyle(FontWeight? weight) => TextStyle(
      fontWeight: weight,
      overflow: TextOverflow.ellipsis,
      fontSize: 18,
    );
