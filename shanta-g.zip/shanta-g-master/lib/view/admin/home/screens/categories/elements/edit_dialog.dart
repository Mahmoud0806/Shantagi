import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/models/category.dart';

import '/data/constant/app_colors.dart';
import '/view/global_elements/widgets/styles.dart';

Widget editDialog(BuildContext context, key, index) {
  var cubit = BlocProvider.of<CategoriesCubit>(context);
  var controller = TextEditingController();
  return AlertDialog(
    title: Text('ادخل الاسم الجديد',
        style: Styles.label0.copyWith(
          color: AppColors.primaryText,
        )),
    content: Form(
      key: key,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // MyTextField(
          //   controller: controller
          //       .nameController,
          //   validate: (_) =>
          //       controller
          //           .inputValidator(),
          // ),
          TextFormField(
            controller: controller,
          ),
          const SizedBox(
            height: 15,
          ),
          BlocConsumer<CategoriesCubit, CategoriesState>(
            listener: (context, state) {
              // if (state.status == CategoriesStatus.loaded) {
              //   List<Category> cats = [...state.categories];
              //   cats[index] = cats[index].copyWith(name: controller.text);
              //   cubit.setNewCats(cats);
              // }

            },
            builder: (context, state) {
              return InkWell(
                onTap: () {
                  if (key.currentState != null &&
                      key.currentState!.validate()) {
                    print('tname: ${controller.text}');
                    cubit.update(state.categories[index].id, controller.text).then((value){
                    Navigator.pop(context);
                      cubit.getAll();
                    });
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColors.primary,
                  ),
                  child: Text(
                    'تعديل',
                    style: Styles.buttonText.copyWith(
                      color: AppColors.background,
                      fontSize: 18,
                    ),
                  ),
                ),
              );
            },
          ),
        ],
      ),
    ),
  );
}
