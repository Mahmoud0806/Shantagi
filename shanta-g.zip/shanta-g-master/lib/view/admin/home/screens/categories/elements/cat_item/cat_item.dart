import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/view/admin/home/screens/categories/elements/cat_item/cat_text.dart';
import '/view/admin/home/screens/categories/elements/cat_item/delete_dialog.dart';
import '/view/admin/home/screens/categories/elements/edit_dialog.dart';

class CategoryItem extends StatelessWidget {
  final Key formKey;
  final int index;

  const CategoryItem({super.key, required this.formKey, required this.index});

  @override
  Widget build(BuildContext context) {
    return _categoryItem(formKey, index);
  }
}

Widget _categoryItem(formKey, index) =>
    BlocBuilder<CategoriesCubit, CategoriesState>(
      builder: (context, state) {
        return Card(
          elevation: 0,
          shape: RoundedRectangleBorder(
              side: const BorderSide(
                color: AppColors.primaryText,
              ),
              borderRadius: BorderRadius.circular(10)),
          child: Padding(
            padding: const EdgeInsets.all(15.0),
            child: Column(
              children: [
                Row(
                  children: [
                    InkWell(
                      onTap: () {
                        // cubit.nameController.clear();
                        showDialog(
                            context: context,
                            builder: (context) {
                              return editDialog(context, formKey, index);
                            });
                      },
                      child: const Icon(
                        Icons.edit_outlined,
                        size: 25,
                        color: AppColors.secondarySec,
                      ),
                    ),
                    catText('الاسم:', weight: FontWeight.bold),
                    SizedBox(
                      width: 150,
                      child: catText(state.categories[index].name),
                    ),
                    const Spacer(),
                    InkWell(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (con) {
                              return deleteDialog(context, formKey, index);
                            });
                      },
                      child: const Icon(
                        size: 25,
                        Icons.delete_outline,
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
