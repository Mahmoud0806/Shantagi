import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../global_elements/app_bar/app_bar.dart';
import '/view/global_elements/toast.dart';
import '/data/constant/app_colors.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/view/admin/home/screens/categories/elements/create/field.dart';

import 'elements/create/create_btn.dart';

class CreateCatScreen extends StatefulWidget {
  const CreateCatScreen({super.key});

  @override
  State<CreateCatScreen> createState() => _CreateCatScreenState();
}

class _CreateCatScreenState extends State<CreateCatScreen> {
  @override
  void initState() {
    fToast.init(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<CategoriesCubit>(context);
    return Scaffold(
      backgroundColor: AppColors.primary,
      appBar: customAppBar('',context, showBack: true, background: AppColors.primary, foreground: AppColors.background),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 80),
        child: SingleChildScrollView(
          child: Column(
            children: [
              catField(cubit.controller),
              BlocConsumer<CategoriesCubit, CategoriesState>(
                listener: (context, state) {
                  if(state.status == CategoriesStatus.created){
                    showToast(text: 'تم إضافة التصنيف', state: ToastStates.success);
                    Navigator.pop(context);
                  }
                  if(state.status == CategoriesStatus.error){
                    showToast(text: 'التصنيف موجود بالفعل', state: ToastStates.error);
                  }
                },
                builder: (context, state) => createBtn(context, () {
                  cubit.create(cubit.controller.text).then((value) {
                    // if(state.status == CategoriesStatus.loaded){
                    //   Navigator.pop(context);
                    // }
                  });
                }),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
