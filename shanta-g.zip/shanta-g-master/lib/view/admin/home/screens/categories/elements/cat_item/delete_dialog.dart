import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/data/constant/app_colors.dart';
import '/view/global_elements/widgets/styles.dart';

Widget deleteDialog(BuildContext context, Key formKey, int index) {
  var cubit = BlocProvider.of<CategoriesCubit>(context);
  return AlertDialog(
    title: const Text(
      'هل أنت متأكد من حذف التصنيف؟',
      style: TextStyle(fontFamily: 'Sukar'),
    ),
    content: Form(
      key: formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(15.0),
            child: Text(
              'سيتم حذف جميع المنتجات ضمن هذا التصنيف',
              style: TextStyle(fontFamily: 'Sukar', color: Colors.red),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            mainAxisSize: MainAxisSize.min,
            children: [
              BlocConsumer<CategoriesCubit, CategoriesState>(
                listener: (context, state) {
                    if(state.status == CategoriesStatus.deleted){
                      Navigator.pop(context);
                    }
                  },
                builder: (context, state) {

                  return InkWell(
                    onTap: () {
                      cubit.delete(state.categories[index].id).then((value) {
                        if(state.status == CategoriesStatus.deleted){
                        }
                          Navigator.pop(context);
                        cubit.getAll();
                      });

                    },
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.red,
                      ),
                      child: Text(
                        'حذف',
                        style: Styles.buttonText.copyWith(
                          color: AppColors.background,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(
                width: 35,
              ),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    color: AppColors.primary,
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 0.0, horizontal: 15.0),
                    child: Text(
                      'لا',
                      style: Styles.buttonText.copyWith(
                        color: AppColors.background,
                        fontSize: 18,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}
