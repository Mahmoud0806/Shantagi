import 'package:flutter/material.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/field_item/field.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/field_item/field_title.dart';

Widget catField(TextEditingController controller) => Column(
  crossAxisAlignment: CrossAxisAlignment.start,
  children: [
    fieldTitle('اسم التصنيف', color: Colors.white),
    CustomField(
      controller: controller,
    ),
  ],
);