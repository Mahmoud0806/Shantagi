import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/view/admin/home/screens/categories/elements/cat_item/cat_item.dart';

class CategoriesPage extends StatefulWidget {
  const CategoriesPage({super.key});

  @override
  State<CategoriesPage> createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      await BlocProvider.of<CategoriesCubit>(context).getAll();
    });
    super.initState();
  }

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<CategoriesCubit>(context);
    return Scaffold(
      // floatingActionButton:,
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 15),
            BlocBuilder<CategoriesCubit, CategoriesState>(
              builder: (context, state) {
                return Expanded(
                  // child: (false)
                  child: (state.status == CategoriesStatus.loading)
                      ? const Center(
                          child: CircularProgressIndicator(
                            color: AppColors.primary,
                          ),
                        )
                      : RefreshIndicator(
                          onRefresh: () => cubit.getAll(),
                          color: AppColors.primary,
                          child: ListView.separated(
                            itemBuilder: (context, index) {
                              return CategoryItem(
                                  formKey: formKey, index: index);
                            },
                            separatorBuilder: (context, index) {
                              return const SizedBox(
                                height: 10,
                              );
                            },
                            itemCount: state.categories.length,
                          ),
                        ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
