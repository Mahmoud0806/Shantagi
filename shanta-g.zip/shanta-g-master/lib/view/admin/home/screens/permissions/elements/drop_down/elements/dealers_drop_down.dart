import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

import '/models/user.dart';

Widget dealersDropDown(List<User> dealers, Function selectDealer,
    {String? selectedUser}) {
  return DropdownButton(
    style: const TextStyle(
      color: Colors.black,
    ),
    dropdownColor: Colors.white,
    menuMaxHeight: 300,
    value: selectedUser,
    isExpanded: true,
    focusColor: AppColors.secondarySec,
    onChanged: (newValue) {
      print('changed');
      print(newValue);
      selectDealer(newValue);
      // cubit.selectedRetailersValue = newValue!;
      // cubit.getRetailerSelectedWholesalers(int.parse(newValue));
    },
    items: dealers.map((user) => userItem(user)).toList(),
  );
}

DropdownMenuItem<String> userItem(User user) => DropdownMenuItem<String>(
      value: user.id.toString(),

      child: Text(
        user.name,
        style: const TextStyle(
          color: AppColors.secondarySec,
          fontWeight: FontWeight.bold
        ),
      ),
    );
