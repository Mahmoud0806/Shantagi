import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/logic/cubits/admin/permissions/access/access_cubit.dart';

import '/data/constant/app_colors.dart';

Widget listHeader(BuildContext context, String title) =>
    Padding(
      padding: const EdgeInsets.only(right: 40, left: 20, top: 40),
      child: SizedBox(
        child: Row(
          children: [
            _listTitle(title),
            const Spacer(),
            _checkBox(context),
          ],
        ),
      ),
    );

Widget _listTitle(String title) =>
    SizedBox(
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          color: AppColors.secondarySec,
        ),
      ),
    );

Widget _checkBox(BuildContext context) {
  var cubit = BlocProvider.of<DealerAccessCubit>(context);
  return BlocBuilder<DealerAccessCubit, DealerAccessState>(
      builder: (context, state) {
        return Checkbox(
          value: false,
          activeColor: AppColors.secondarySec,

          onChanged: (val) {
            cubit.selectAllWholesalers(state.wholesalers);
          },
        );
      },
    );
}
