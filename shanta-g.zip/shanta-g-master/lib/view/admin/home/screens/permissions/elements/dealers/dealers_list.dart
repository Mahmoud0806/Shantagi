import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/models/user.dart';
import '/view/admin/home/screens/permissions/elements/dealers/list_header.dart';
import 'dealer_item.dart';

Widget dealersListView(BuildContext context, List<User> users, String listTitle,
    Function onPressed,
    {Color? color, List dealers = const []}) {
  var cubit = BlocProvider.of<DealerAccessCubit>(context);
  return Column(
    children: [
      listHeader(context, listTitle),
      Expanded(
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: SizedBox(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: users.length,
              itemBuilder: (context, index) => dealerListItem(
                context,
                users[index].name,
                () {
                  onPressed(index);
                },
                color: dealers.isNotEmpty
                    ? dealers[index]
                        ? AppColors.secondarySec.withOpacity(.3)
                        : null
                    : null,
              ),
            ),
          ),
        ),
      ),
    ],
  );
}
