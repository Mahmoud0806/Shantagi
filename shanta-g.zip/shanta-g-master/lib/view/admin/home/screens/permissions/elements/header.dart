import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget permissionsHeader(String title) => Padding(
      padding: const EdgeInsets.only(right: 40, top: 40),
      child: SizedBox(
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            color: AppColors.secondarySec,
          ),
        ),
      ),
    );
