import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/admin/home/screens/permissions/elements/set_access_btn.dart';

import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/view/admin/home/screens/permissions/elements/header.dart';
import 'drop_down/retailers_dropdown.dart';
import 'lists/shanta_list.dart';
import 'lists/wholesalers_list.dart';

class RetailersPermissions extends StatefulWidget {
  const RetailersPermissions({super.key});

  @override
  State<RetailersPermissions> createState() => _RetailersPermissionsState();
}

class _RetailersPermissionsState extends State<RetailersPermissions> {
  @override
  void setState(VoidCallback fn) {
    var cubit = BlocProvider.of<DealerAccessCubit>(context);
    cubit.state.retailers.isNotEmpty
        ? cubit.getRetailerAccess(cubit.state.retailers.first.id)
        : null;
    super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<DealerAccessCubit>(context);
    return Padding(
      padding: const EdgeInsets.all(15),
      child: SizedBox(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            permissionsHeader('تاجر المفرق'),
            retailersDropdown(context),
            wholesalersList(context),
            shantaList(context),
            BlocBuilder<DealerAccessCubit, DealerAccessState>(
              builder: (context, state) {
                return setAccessBtn(context, () {
                  cubit.setRetailerAccess(
                      state.retailer.id,
                      cubit.setSelectedDealers(
                        [...state.wholesalers, ...state.shantas],
                        [...state.selectedWholesalers, ...state.selectedShanta],
                      ));
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
