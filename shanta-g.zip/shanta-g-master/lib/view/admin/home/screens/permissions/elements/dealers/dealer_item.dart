import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/data/constant/app_colors.dart';

import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/view/global_elements/widgets/styles.dart';

Widget dealerListItem(
        BuildContext context, String name, VoidCallback onPressed, {Color? color}) =>
    BlocBuilder<DealerAccessCubit, DealerAccessState>(
      builder: (context, state) {
        return ElevatedButton(
          onPressed: onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: color ?? AppColors.primary.withOpacity(.4),
            fixedSize: Size(
              MediaQuery.sizeOf(context).width * .8,
              MediaQuery.sizeOf(context).height * .05,
            ),
          ),
          child: Text(
            name,
            style: Styles.label2.copyWith(
              color: AppColors.background
            ),
          ),
        );
      },
    );
