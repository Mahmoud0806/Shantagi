import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/permissions/access/access_cubit.dart';

import 'drop_down/shanta_dropdown.dart';
import 'header.dart';
import 'lists/retailers_list.dart';

class ShantaPermissions extends StatefulWidget {
  const ShantaPermissions({super.key});

  @override
  State<ShantaPermissions> createState() => _ShantaPermissionsState();
}

class _ShantaPermissionsState extends State<ShantaPermissions> {
  @override
  void initState() {
    BlocProvider.of<DealerAccessCubit>(context).clearRetailers();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        permissionsHeader('تاجر الشنطة'),
        shantaDropdown(context),
        retailersList(context, true),
      ],
    );
  }
}
