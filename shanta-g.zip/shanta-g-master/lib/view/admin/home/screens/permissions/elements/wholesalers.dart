import 'package:flutter/material.dart';

import 'drop_down/wholesalers_dropdown.dart';
import 'header.dart';
import 'lists/retailers_list.dart';

class WholesalersPermissions extends StatefulWidget {
  const WholesalersPermissions({super.key});

  @override
  State<WholesalersPermissions> createState() => _WholesalersPermissionsState();
}

class _WholesalersPermissionsState extends State<WholesalersPermissions> {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        permissionsHeader('تاجر الجملة'),
        wholesalerDropdown(context),
        retailersList(context, false),
      ],
    );
  }
}
