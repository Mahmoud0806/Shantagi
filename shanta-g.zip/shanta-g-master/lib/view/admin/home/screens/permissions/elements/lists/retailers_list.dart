import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/view/admin/home/screens/permissions/elements/dealers/dealers_list.dart';

Widget retailersList(BuildContext context, bool isShanta) {
  var cubit = BlocProvider.of<DealerAccessCubit>(context);
  return Expanded(
    child: BlocBuilder<DealerAccessCubit, DealerAccessState>(
      builder: (context, state) {
        return dealersListView(
          context,
          state.retailers,
          'تجار المفرق',
          (index) {
            cubit.editRetailer(index);
          },
          dealers: isShanta
              ? state.selectedShantaRetailers
              : state.selectedRetailers,
        );
      },
    ),
  );
}
