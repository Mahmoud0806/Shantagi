import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/view/admin/home/screens/permissions/elements/drop_down/elements/dealers_drop_down.dart';

Widget retailersDropdown(BuildContext context) {
  var cubit = BlocProvider.of<DealerAccessCubit>(context);
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 45, vertical: 25),
    child: SizedBox(
      child: BlocBuilder<DealerAccessCubit, DealerAccessState>(
        builder: (context, state) {
          return dealersDropDown(
            state.retailers,
            (id) {
              cubit.selectRetailer(id);
              cubit.getRetailerAccess(int.parse(id));
            },
            selectedUser:
                state.retailer.id != -1000 ? '${state.retailer.id}' : null,
          );
        },
      ),
    ),
  );
}
