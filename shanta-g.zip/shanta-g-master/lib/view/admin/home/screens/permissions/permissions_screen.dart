import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/data/constant/app_colors.dart';

import 'elements/retailers.dart';
import 'elements/shanta.dart';
import 'elements/wholesalers.dart';

class PermissionsScreens extends StatefulWidget {
  const PermissionsScreens({super.key});

  @override
  State<PermissionsScreens> createState() => _PermissionsScreensState();
}

class _PermissionsScreensState extends State<PermissionsScreens> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      var cubit = BlocProvider.of<DealerAccessCubit>(context);
      await cubit.getDealers();
      print(cubit.state.shantas);
      print(cubit.state.wholesalers);
      print(cubit.state.retailers);
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.primary,
        appBar: AppBar(
          title: const Text('الصلاحيات'),
          bottom: const TabBar(
            indicatorColor: Colors.white,
            labelColor: AppColors.secondarySec,
            unselectedLabelColor: AppColors.primary,
            labelStyle: TextStyle(color: Colors.white),
            tabs: [
              Tab(text: ' تجار المفرق'),
              Tab(text: 'تجار الجملة'),
              Tab(text: 'تجار الشنطة'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            RetailersPermissions(),
            WholesalersPermissions(),
            ShantaPermissions(),
          ],
        ),
      ),
    );
  }
}
