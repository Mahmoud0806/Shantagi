import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/permissions/access/access_cubit.dart';
import '/view/admin/home/screens/permissions/elements/dealers/dealers_list.dart';

Widget shantaList(BuildContext context) {
  var cubit = BlocProvider.of<DealerAccessCubit>(context);
  return Expanded(
      child: BlocBuilder<DealerAccessCubit, DealerAccessState>(
        builder: (context, state) {
          return dealersListView(context, state.shantas, 'تجار الشنطة', (index) {
            cubit.editRetailerShanta(index);
          },
            dealers: state.selectedShanta
          );
        },
      ),
    );
}
