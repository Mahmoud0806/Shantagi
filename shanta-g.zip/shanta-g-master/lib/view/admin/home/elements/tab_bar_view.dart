import 'package:flutter/material.dart';

import '/view/admin/home/screens/users/clients.dart';
import '/view/admin/home/screens/users/retailers.dart';
import '/view/admin/home/screens/users/shanta.dart';
import '/view/admin/home/screens/users/wholesalers.dart';

Widget tabBarView() => const Expanded(
      child: TabBarView(
        children: [
          // AdminOrdersScreen(),
          // AdminClientsOrdersScreen(),
          // AdminProductsScreen(),
          // CategoriesScreen(),
          AdminShantaPage(),
          AdminWholesalersPage(),
          AdminRetailersPage(),
          AdminClientsPage(),
        ],
      ),
    );
