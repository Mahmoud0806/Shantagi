import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget customTabBar() => Expanded(
      child: TabBar(
        isScrollable: true,
        padding: const EdgeInsets.fromLTRB(5, 20, 5, 5),
        unselectedLabelColor: AppColors.primary,
        labelPadding: const EdgeInsets.all(0),
        indicatorSize: TabBarIndicatorSize.tab,
        indicator: indicator(),
        indicatorColor: Colors.transparent,
        tabs: _tabs(),
      ),
    );

BoxDecoration indicator() => BoxDecoration(
      borderRadius: BorderRadius.circular(7),
      color: AppColors.listTile,
    );

List<Widget> _tabs() => [
      barItem("الطلبات"),
      barItem('طلبات الزبائن'),
      barItem("المنتجات"),
      barItem("التصنيفات"),
      barItem('تجار شنطة'),
      barItem('تجار الجملة'),
      barItem('تجار المفرق'),
      barItem('الزبائن'),
    ];

Container barItem(String title) => Container(
      margin: const EdgeInsets.symmetric(horizontal: 5),
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 8),
      decoration: _decoration(),
      child: _itemTitle(title),
    );

BoxDecoration _decoration() {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(7),
    border: Border.all(color: AppColors.primary),
  );
}

Text _itemTitle(String title) {
  return Text(
    title,
    style: itemStyle(),
  );
}

TextStyle itemStyle() {
  return const TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.bold,
  );
}
