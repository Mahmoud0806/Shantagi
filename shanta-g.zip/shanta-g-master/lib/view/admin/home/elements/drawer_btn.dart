import 'package:flutter/material.dart';

Widget drawerBtn(BuildContext context) => Padding(
      padding: const EdgeInsets.fromLTRB(5, 10, 10, 10),
      child: SizedBox(
        height: 25,
        width: 25,
        child: _btn(context),
      ),
    );

IconButton _btn(BuildContext context) => IconButton(
      onPressed: () {
        Scaffold.of(context).openDrawer();
      },
      icon: const Icon(Icons.filter_list_outlined),
      padding: const EdgeInsets.all(0),
    );
