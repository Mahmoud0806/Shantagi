import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/switches/switches_cubit.dart';
import '/logic/cubits/switches/switches_cubit.dart';
import '/view/global_elements/fields/custom_text_field.dart';

Widget loginFields(
  TextEditingController emailController,
  TextEditingController passwordController,
) =>
    SizedBox(
      child: Column(
        children: [
          customTextField(
            controller: emailController,
            keyboard: TextInputType.emailAddress,
            label: 'البريد الإلكتروني',
            prefix: Icons.email,
          ),
          BlocBuilder<SwitchesCubit, SwitchesState>(
            builder: (context, state) {
              return customTextField(
                  controller: passwordController,
                  keyboard: TextInputType.visiblePassword,
                  label: 'كلمة المرور',
                  prefix: Icons.lock,
                  obSecure: state.obSecure,
                  suffix:
                      state.obSecure ? Icons.visibility_off : Icons.visibility,
                  suffixPressed: () {
                    var cubit = BlocProvider.of<SwitchesCubit>(context);
                    cubit.changeObSecure();
                  });
            },
          ),
        ],
      ),
    );
