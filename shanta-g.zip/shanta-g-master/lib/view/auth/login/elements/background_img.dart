import 'package:flutter/material.dart';

Widget backgroundImg() => SizedBox(
      height: double.infinity,
      width: double.infinity,
      child: Image.asset(
        'assets/images/background.png',
        fit: BoxFit.cover,
      ),
    );
