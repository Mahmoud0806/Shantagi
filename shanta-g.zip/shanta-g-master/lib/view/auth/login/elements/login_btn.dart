import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../data/notifications/fcm_token_handler.dart';
import '/data/constant/storage/secure_storage.dart';
import '/view/global_elements/toast.dart';

import '/data/constant/app_colors.dart';
import '/data/constant/constant.dart';
import '/logic/cubits/auth/auth_cubit.dart';

Widget loginBtn(BuildContext context, AuthCubit cubit) => Padding(
      padding: const EdgeInsets.only(top: 90),
      child: BlocConsumer<AuthCubit, AuthState>(
        listener: (context, state) async {
          if (cubit.emailController.text.isEmpty ||
              cubit.emailController.text.isEmpty) {
            showToast(
                text: 'الرجاء ادخال بيانات الحساب والكلمة',
                state: ToastStates.error);
          }
          if (state.status == AuthStatus.loaded) {
            token = await SecureStorage.getToken();
            print('----- ---- --- --- -- login screen token: $token');
            print('selected user::: $userType');
            Navigator.of(context).pushReplacement(
              MaterialPageRoute(
                builder: (_) => types[userType],
              ),
              // (route) => true,
            );
            print('success');
          } else if (state.status == AuthStatus.error) {
            showToast(
                text: 'خطأ في الحساب او كلمة المرور',
                state: ToastStates.error);
            print('error ${state.error}');
          }
        },
        builder: (context, state) {
          return state.status == AuthStatus.loading
              ? const Center(child: CircularProgressIndicator())
              : ElevatedButton(
                  onPressed: () async {
                    if(cubit.emailController.text.isNotEmpty &&
                        cubit.passwordController.text.length > 7){
                      await cubit.login().then((value) {
                        getToken();
                        if (state.status == AuthStatus.loaded) {}
                      });
                    }else{
                      showToast(
                          text: 'الرجاء ادخال بيانات الحساب والكلمة بشكل صحيح',
                          state: ToastStates.error);
                    }
                  },
                  style: _btnStyle(context),
                  child: _btnTitle(),
                );
        },
      ),
    );

ButtonStyle _btnStyle(BuildContext context) => ElevatedButton.styleFrom(
      backgroundColor: AppColors.primary,
      fixedSize: _btnSize(context),
      shape: _btnShape(),
    );

RoundedRectangleBorder _btnShape() => RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(5),
    );

Size _btnSize(BuildContext context) => Size(
      MediaQuery.of(context).size.width * 0.9,
      50,
    );

Text _btnTitle() => Text(
      'تسجيل الدخول',
      style: _titleStyle(),
    );

TextStyle _titleStyle() => const TextStyle(
      fontSize: 22,
      fontWeight: FontWeight.bold,
      color: AppColors.background,
    );
