import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/global_elements/toast.dart';

import '/logic/cubits/auth/auth_cubit.dart';
import '/view/auth/login/elements/login_btn.dart';
import '/view/auth/login/elements/login_fields.dart';
import '/view/global_elements/app_logo.dart';
import 'elements/background_img.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  void initState() {
    fToast.init(context);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SizedBox(
        child: Stack(
          children: [
            backgroundImg(),
            _loginInfo(context),
          ],
        ),
      ),
    );
  }

  Widget _loginInfo(BuildContext context) {
    return SizedBox(
      height: MediaQuery.sizeOf(context).height,
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: _children(context),
        ),
      ),
    );
  }

  List<Widget> _children(BuildContext context) {
    var cubit = BlocProvider.of<AuthCubit>(context);
    return [
      appLogo(),
      loginFields(cubit.emailController, cubit.passwordController),
      loginBtn(context, cubit),
    ];
  }
}
