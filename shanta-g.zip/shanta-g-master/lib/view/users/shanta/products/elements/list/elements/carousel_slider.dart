import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import '/models/product/product_image.dart';

Widget carouselSlider(BuildContext context, List<ProductImage>images) => CarouselSlider(
      // options: CarouselOptions(height: 400.0),
      items: images
          .map(
            (e) => Image.network(e.attachment)
          )
          .toList(),
      options: _options(context),
    );

CarouselOptions _options(BuildContext context) {
  return CarouselOptions(
      height: MediaQuery.of(context).size.height * 0.25,
      initialPage: 0,
      viewportFraction: 1.0,
      enableInfiniteScroll: false,
      reverse: false,
      autoPlay: true,
      onPageChanged: (index, reason) {
        // controller.changeIndex(index);
      },
      autoPlayInterval: const Duration(seconds: 3),
      autoPlayAnimationDuration: const Duration(seconds: 1),
      autoPlayCurve: Curves.fastOutSlowIn,
      scrollDirection: Axis.horizontal,
    );
}
