import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shantagi/view/users/wholesaler/products/elements/grid/details/wholesaler_product_details.dart';
import '/logic/cubits/shanta/products/products_cubit.dart';
import '/logic/cubits/shanta/products/products_cubit.dart';
import '/models/product/product.dart';

import 'elements/product_item.dart';

Widget shantaProductsList() =>
    BlocBuilder<ShantaProductsCubit, ShantaProductsState>(
      builder: (context, state) {
        return state.products.isEmpty
            ? const Center(
          child: Text('لا يوجد منتجات بعد'),
        )
            : SizedBox(
          height: 500,
              child: PageView.builder(

                        itemCount: state.products.length,
                        pageSnapping: true,
                        scrollDirection: Axis.vertical,
                        itemBuilder: (context, pagePosition) {
              // controller.createMyImages(controller.products[pagePosition].images!);
              return productItem(context, state.products[pagePosition], onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (_) => WholesalerProductDetails(product: state.products[pagePosition])));
              });
                        },
                      ),
            );
      },
    );
