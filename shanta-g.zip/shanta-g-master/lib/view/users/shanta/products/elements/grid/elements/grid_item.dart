import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/cubits.dart';

import '../../../../../../global_elements/products/grid/elements/item_hold.dart';
import 'item_image.dart';

Widget shantaGridItem(
        BuildContext context, bool isHold, int index, VoidCallback onTap) =>
    Padding(
      padding: const EdgeInsets.all(15),
      child: SizedBox(
        child: Stack(
          children: _children(context, isHold, index, onTap),
        ),
      ),
    );

List<Widget> _children(
    BuildContext context, bool isHold, int index, VoidCallback onTap) {
  var cubit = BlocProvider.of<ShantaProductsCubit>(context);
  return [
    InkWell(

      onTap:onTap,
    child: cashedImage(cubit.state.products[index].images.isNotEmpty
          ? cubit.state.products[index].images.first.attachment
          : ''),
    ),
    itemHold(cubit.state.products[index].hold, () {
      cubit.changeHold(cubit.state.products[index].id).then((value) => cubit.getAll(),);
    }),
  ];
}
