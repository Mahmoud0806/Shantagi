import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/shanta/products/products_cubit.dart';
import '/view/users/shanta/products/elements/grid/elements/grid_item.dart';
import '/view/users/wholesaler/products/elements/grid/details/wholesaler_product_details.dart';

Widget shantaProductsGrid() => Expanded(
      child: BlocBuilder<ShantaProductsCubit, ShantaProductsState>(
        builder: (context, state) {
          return state.status == ShantaProductsStatus.loading &&
                  state.products.isEmpty
              ? const Center(child: CircularProgressIndicator())
              : state.products.isEmpty
                  ? const Center(
                      child: Text('لا يوجد منتجات بعد'),
                    )
                  : GridView.builder(
                      shrinkWrap: true,
                      itemCount: state.products.length,
                      gridDelegate: _gridDelegate(),
                      itemBuilder: (context, index) => shantaGridItem(
                          context, state.product.hold, index, () {
                        var cubit =
                            BlocProvider.of<ShantaProductsCubit>(context);
                        cubit.setActive(index);
                        print('pressed');
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => WholesalerProductDetails(
                              product: state.products[index],
                            ),
                          ),
                        );
                      }),
                    );
        },
      ),
    );

SliverGridDelegateWithFixedCrossAxisCount _gridDelegate() =>
    const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2,
    );
