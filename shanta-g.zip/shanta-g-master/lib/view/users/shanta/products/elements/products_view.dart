import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/cubits.dart';
import '/logic/cubits/filters/filters_cubit.dart';
import '/view/global_elements/filters.dart';
import '/view/global_elements/products/elements/header/header.dart';
import '/view/global_elements/search_bar.dart';
import '/view/users/shanta/products/elements/grid/products_grid.dart';
import '/view/users/shanta/products/elements/list/products_list.dart';

SizedBox shantaProductsView(BuildContext context) => SizedBox(
      child: Column(
        children: _children(context),
      ),
    );

List<Widget> _children(BuildContext context) {
  var cubit = BlocProvider.of<ShantaProductsCubit>(context);
  final controller = TextEditingController();
  return [
    Row(
      children: [
        Expanded(
          child: searchBar('إبحث', controller, (s) {
            cubit.getAll(params: '?name=${controller.text}');
          }),
        ),
        _filterShanta(context),
      ],
    ),
    productsViewHeader(context),
    RefreshIndicator(
      onRefresh: cubit.getAll,
      child: BlocBuilder<ToggleCubit, ToggleState>(
        builder: (context, state) {
          return state.isListView ? shantaProductsList() : shantaProductsGrid();
        },
      ),
    ),
  ];
}

Padding _filterShanta(BuildContext context) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          IconButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (BuildContext context) =>
                    dialog(context, showDealers: false, onPressed: () {
                  var cubit = BlocProvider.of<ShantaProductsCubit>(context);
                  var filterCubit = BlocProvider.of<FiltersCubit>(context);
                  cubit.getAll(params: filterCubit.setSelectedParams());
                  Navigator.maybePop(context);
                }),
              );
            },
            icon: const Icon(
              Icons.filter_alt_outlined,
              color: AppColors.secondarySec,
            ),
          )
        ],
      ),
    );
