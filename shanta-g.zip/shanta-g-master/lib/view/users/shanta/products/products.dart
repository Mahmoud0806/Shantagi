import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shantagi/view/users/shanta/products/add/add_product.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/cubits.dart';
import '/logic/cubits/filters/filters_cubit.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/users/shanta/products/elements/products_view.dart';

class ShantaProductsScreen extends StatefulWidget {
  const ShantaProductsScreen({super.key});

  @override
  State<ShantaProductsScreen> createState() => _ShantaProductsScreenState();
}

class _ShantaProductsScreenState extends State<ShantaProductsScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      var catCubit = BlocProvider.of<CategoriesCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      await BlocProvider.of<ShantaProductsCubit>(context).getAll();
      await catCubit.getAll();
      filterCubit.fillCats(catCubit.state.categories);
      print('${BlocProvider.of<ShantaProductsCubit>(context).state.products}');
      _scrollController.addListener(_loadMoreData);
    });
    super.initState();
  }
  final _scrollController = ScrollController();

  void _loadMoreData() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent) {
      var cubit = BlocProvider.of<ClientProductsCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      cubit.getAll(params: filterCubit.setSelectedParams(), saveOld: true, savePage: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('المنتجات', context),
      body: shantaProductsView(context),
      floatingActionButton: IconButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddShantaProductScreen(),
            ),
          );
        },
        style: IconButton.styleFrom(
            backgroundColor: AppColors.primary,
            minimumSize: const Size(55, 55),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15),
            )),
        icon: const Icon(
          Icons.add,
          size: 35,
          color: AppColors.background,
        ),
      ),
    );
  }
}
