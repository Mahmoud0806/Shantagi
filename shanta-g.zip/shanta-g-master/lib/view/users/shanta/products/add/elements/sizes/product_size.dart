import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/products/products_cubit.dart';
import '/view/admin/home/screens/users/elements/user_item/elements/field_item/field.dart';
import 'elements/add_size_btn.dart';
import 'elements/size_item.dart';

Widget addProductSizes(BuildContext context, key) {
  var cubit = BlocProvider.of<ProductsCubit>(context);
  return GestureDetector(
    onTap: () {
      showDialog(
          context: context,
          builder: (context) {
            return GestureDetector(
              onTap: () {
                FocusManager.instance.primaryFocus?.unfocus();
              },
              child: AlertDialog(
                title: const Text(
                  'أضف القياسات المتوفرة للمنتج',
                  style: TextStyle(fontFamily: 'Sukar'),
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    productSizes(context),
                    sizeField(context, key),
                    addSizeBtn(context, key),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: () {
                      print(cubit.state.sizes);
                      // print(controller.listDynamic);
                      Navigator.pop(context);
                    },
                    child: Container(
                      width: MediaQuery.sizeOf(context).width,
                      height: 35,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(5),
                          color: AppColors.primary),
                      child: const Center(
                        child: Text(
                          'حفظ',
                          style: TextStyle(
                            fontFamily: 'Sukar',
                            fontSize: 18,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          });
    },
    child: Container(
      width: MediaQuery.sizeOf(context).width,
      decoration: BoxDecoration(
        border: Border.all(
          color: Colors.white,
        ),
        borderRadius: BorderRadius.circular(25),
        color: Colors.white,
      ),
      child: const Padding(
        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: Center(
          child: Text(
            'أضف القياسات المتوفرة',
            style: TextStyle(
              fontFamily: 'Sukar',
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: AppColors.primary,
            ),
          ),
        ),
      ),
    ),
  );
}

CustomField sizeField(BuildContext context, key) {
  return CustomField(
    controller: BlocProvider.of<ProductsCubit>(context).sizeController,
    // controller: addProductSizeController,
    // validate: (_) => controller.inputValidator(
    //     controller.addProductSizeController
    // ),
    onSubmit: (value) {
      if (key.currentState != null && key.currentState!.validate()) {
        // controller.addSize();
        FocusManager.instance.primaryFocus?.unfocus();
      }
    },
  );
}

Widget productSizes(BuildContext context) {
  var cubit = BlocProvider.of<ProductsCubit>(context);
  return BlocBuilder<ProductsCubit, ProductsState>(
    builder: (context, state) {
      return SizedBox(
        height: 100,
        width: double.maxFinite,
        child: (cubit.state.sizes.isEmpty) ? noSizes() : sizesList(context),
      );
    },
  );
}

ListView sizesList(BuildContext context) {
  var cubit = BlocProvider.of<ProductsCubit>(context);
  return ListView.separated(
    itemBuilder: (context, index) {
      return sizeItem(cubit.state.sizes[index], index, context);
    },
    separatorBuilder: (context, index) => const Divider(),
    itemCount: cubit.state.sizes.length,
    // itemCount: controller.listDynamic.length,
  );
}

Center noSizes() {
  return Center(
    child: Text(
      'لا يوجد قياسات مضافة',
      style: TextStyle(
        fontFamily: 'Sukar',
        color: Colors.grey.shade700,
        fontSize: 16,
      ),
    ),
  );
}
