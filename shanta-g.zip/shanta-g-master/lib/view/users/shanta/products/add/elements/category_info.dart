import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/categories/categories_cubit.dart';

Widget selectCategory(BuildContext context) {
  var cubit = BlocProvider.of<CategoriesCubit>(context);
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      _title(),
      BlocBuilder<CategoriesCubit, CategoriesState>(
        builder: (context, state) {
          return Container(
            margin: const EdgeInsets.symmetric(horizontal: 50, vertical: 20),
            padding: const EdgeInsets.symmetric(horizontal: 5),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              color: Colors.white,
            ),
            child: DropdownButton(
              dropdownColor: Colors.white,
              menuMaxHeight: 300,
              value: state.catItem.value,
              isExpanded: true,
              onChanged: (String? newValue) {
                cubit.selectCatItem(newValue);
                // setState(() {
                //   controller.selectedCategoryValue =
                //   newValue!;
                // });
              },
              items: state.categoriesItems,
              // items: categoryItems,
            ),
          );
        },
      ),
    ],
  );
}

Padding _title() {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 35, vertical: 5),
    child: Text(
      'التصنيف',
      style: _titleStyle(),
    ),
  );
}

TextStyle _titleStyle() {
  return const TextStyle(
    fontSize: 18,
    color: Colors.white,
  );
}
