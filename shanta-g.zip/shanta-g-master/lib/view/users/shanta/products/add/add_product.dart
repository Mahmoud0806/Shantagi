import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/admin/users/shanta/admin_shanta_cubit.dart';
import '/logic/cubits/admin/users/wholesalers/admin_wholesalers_cubit.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import 'elements/product_fields/product_fields.dart';

class AddShantaProductScreen extends StatefulWidget {
  const AddShantaProductScreen({super.key});

  @override
  State<AddShantaProductScreen> createState() => _AddShantaProductScreenState();
}

class _AddShantaProductScreenState extends State<AddShantaProductScreen> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      BlocProvider.of<CategoriesCubit>(context).getAll();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: AppColors.primary,
        appBar: customAppBar(
          'إضافة منتج',
          context,
          showBack: true,
          background: AppColors.primary,
          foreground: AppColors.background,
        ),
        // appBar: customAppBar('إضافة منتج'),
        body: Form(
          key: formKey,
          child: shantaProductsFields(context, formKey),
        ),
      ),
    );
  }
}
