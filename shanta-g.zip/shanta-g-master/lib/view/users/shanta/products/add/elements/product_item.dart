import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/admin/products/products_cubit.dart';

class ProductItem extends StatelessWidget {
  final String url;
  final int index;

  const ProductItem({super.key, required this.url, required this.index});

  @override
  Widget build(BuildContext context) {
    return _productItem(context, url, index);
  }
}

Widget _productItem(BuildContext context, String url, int index) => SizedBox(
      child: BlocBuilder<ProductsCubit, ProductsState>(
        builder: (context, state) {
          return Padding(
            padding: const EdgeInsets.all(5),
            child: InkWell(
              onTap: () {
                // Navigator.push(
                //   context,
                //   MaterialPageRoute(
                //     builder: (_) => S(index: index),
                //   ),
                // );
                //
              },
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: CachedNetworkImage(
                  fit: BoxFit.cover,
                  imageUrl: state.products[index].images.isNotEmpty
                      ? state.products[index].images.first.attachment
                      : '',
                  errorWidget: (context, error, stackTrace) =>
                      const Text('error'),
                ),
              ),
              // child: _image(url),
            ),
          );
        },
      ),
    );

Image _image(url) {
  return Image.network(
    url,
    fit: BoxFit.cover,
  );
}
