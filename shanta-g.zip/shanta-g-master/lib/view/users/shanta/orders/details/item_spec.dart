
import 'package:flutter/material.dart';

class ShantaItemSpec extends StatelessWidget {
  final String title;
  final String value;

  const ShantaItemSpec({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: _textStyle(),
          ),
          const SizedBox(width: 15,),
          Expanded(
            child: Text(
              value,
              maxLines: 3,
              style: _textStyle(),
            ),
          ),
        ],
      ),
    );
  }
}

TextStyle _textStyle() => TextStyle(
      color: Colors.black,
      fontSize: 16,
    );

// Widget _itemSpec(String title, String value) =>
//     Padding(
//       padding: const EdgeInsets.all(10.0),
//       child: SizedBox(
//         width: MediaQuery
//             .sizeOf(context)
//             .width * 0.5,
//         child: Row(
//           children: [
//             Text(
//               title,
//               style: _textStyle(),
//             ),
//             const SizedBox(width: 15),
//             Text(
//               value,
//               style: _textStyle(),
//             ),
//           ],
//         ),
//       ),
//     );
