import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shantagi/view/users/shanta/orders/details/submit_order_btn.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/cubits.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import 'item_info.dart';

class ShantaOrderDetails extends StatefulWidget {
  const ShantaOrderDetails({super.key});

  @override
  State<ShantaOrderDetails> createState() => _ShantaOrderDetailsState();
}

class _ShantaOrderDetailsState extends State<ShantaOrderDetails> {
  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<ShantaOrdersCubit>(context);
    return Scaffold(
      appBar: customAppBar('تفاصيل الطلبية', context,
          showBack: true, foreground: AppColors.primary),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          children: [
            BlocBuilder<ShantaOrdersCubit, ShantaOrdersState>(
                builder: (context, state) {
              return ListView.builder(
                shrinkWrap: true,
                itemBuilder: (context, int index) => _orderItem(context, index),
                itemCount: state.order.orderItems.length,
              );
            }),
            const Spacer(),
            cubit.state.order.status == 'new'
                ? shantaSubmitOrder(context)
                : const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }

  SizedBox _orderItem(BuildContext context, int index) {
    return SizedBox(
      // height: MediaQuery.sizeOf(context).height * 0.35,
      child: Card(
        color: AppColors.secondarySec.withOpacity(0.3),
        shadowColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _itemImage(index),
              ShantaItemInfo(index: index),
            ],
          ),
        ),
      ),
    );
  }

  Widget _itemImage(int index) {
    return BlocBuilder<ShantaOrdersCubit, ShantaOrdersState>(
      builder: (context, state) {
        return SizedBox(
          height: 120,
          width: 120,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(5),
            child: Image.network(
              state.order.orderItems[index].product.images.isNotEmpty
                  ? state
                      .order.orderItems[index].product.images.first.attachment
                  : '',
              // 'order.orderItems![index].product!.images![0].attachment!',
              fit: BoxFit.cover,
            ),
          ),
        );
      },
    );
  }
}
