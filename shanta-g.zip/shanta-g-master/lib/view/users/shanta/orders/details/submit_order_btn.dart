import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/cubits.dart';

Widget shantaSubmitOrder(
  BuildContext context,
) {
  var cubit = BlocProvider.of<ShantaOrdersCubit>(context);
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 45, horizontal: 25),
    child: BlocBuilder<WholesalerOrdersCubit, WholesalerOrdersState>(
      builder: (context, state) {
        return ElevatedButton(
          onPressed: () {
            cubit.confirmOrder().then((onValue) {
              cubit.getAll();
              Navigator.maybePop(context);
            });
          },
          style: _btnStyle(context),
          child: Text(
            'حفظ',
            style: _style(),
          ),
        );
      },
    ),
  );
}

ButtonStyle _btnStyle(BuildContext context) {
  return ElevatedButton.styleFrom(
    minimumSize: Size(
      MediaQuery.of(context).size.width * 0.8,
      MediaQuery.of(context).size.height * 0.07,
    ),
    backgroundColor: AppColors.primary,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(5),
    ),
    padding: const EdgeInsets.symmetric(vertical: 10),
  );
}

TextStyle _style() => TextStyle(
    fontSize: 20,
    // height: 1,
    fontWeight: FontWeight.bold,
    color: AppColors.background.withOpacity(0.87));
