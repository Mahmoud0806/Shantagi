import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shantagi/data/constant/app_colors.dart';
import 'package:shantagi/models/order/order_item.dart';

import '/logic/cubits/cubits.dart';
import 'item_spec.dart';
import 'item_title.dart';

class ShantaItemInfo extends StatelessWidget {
  final int index;

  const ShantaItemInfo({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: BlocBuilder<ShantaOrdersCubit, ShantaOrdersState>(
        builder: (context, state) {
          return Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: _children(context, state),
            ),
          );
        },
      ),
    );
  }

  List<Widget> _children(BuildContext context, ShantaOrdersState state) => [
        shantaItemTitle(context, state.order.orderItems[index].product.name),
        ShantaItemSpec(
            title: 'القياس:', value: state.order.orderItems[index].size),
        ShantaItemSpec(
            title: 'العدد المطلوب:',
            value: '${state.order.orderItems[index].requiredAmount}'),
        _acceptableAmount(state.order.orderItems[index], index),
        state.order.orderItems[index].notes != ''
            ? SizedBox(
                child: ShantaItemSpec(
                    title: 'ملاحظات:',
                    value: state.order.orderItems[index].notes),
              )
            : const SizedBox.shrink(),
      ];
}

RenderObjectWidget _acceptableAmount(OrderItem item, int index) {
  return (item.size != '')
      ? Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10),
        child: Row(
            children: [
              const Text(
                'المتوفر:',
                style: TextStyle(
                  fontSize: 16,
                  fontFamily: 'Sukar',
                ),
              ),
              (item.acceptableAmount > 0)
                  ? Text(
                      '${item.acceptableAmount}',
                      style: const TextStyle(
                        fontSize: 14,
                        fontFamily: 'Sukar',
                      ),
                    )
                  : Padding(
                      padding: const EdgeInsets.all(10),
                      child: SizedBox(
                        width: 30,
                        height: 20,
                        child: BlocBuilder<ShantaOrdersCubit,
                            ShantaOrdersState>(
                          builder: (context, state) {
                            return TextFormField(
                              textAlign: TextAlign.center,
                              maxLength: 2,
                              controller: state.itemsFields[index],
                              cursorColor: AppColors.primary,
                              style: const TextStyle(color: AppColors.primary),
                              decoration: InputDecoration(
                                counterText: '',
                                contentPadding: EdgeInsets.zero,
                                focusedBorder: _focusBorder(),
                                enabledBorder: _outlineInputBorder(),
                                disabledBorder: _outlineInputBorder(),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
            ],
          ),
      )
      : const SizedBox.shrink();
}

OutlineInputBorder _focusBorder() => const OutlineInputBorder(
      borderSide: BorderSide(
        color: AppColors.primary,
        width: 1.5,
      ),
      borderRadius: BorderRadius.all(Radius.circular(3)),
    );

OutlineInputBorder _outlineInputBorder() => const OutlineInputBorder(
      borderSide: BorderSide(color: Colors.black),
      borderRadius: BorderRadius.all(
        Radius.circular(3),
      ),
    );
