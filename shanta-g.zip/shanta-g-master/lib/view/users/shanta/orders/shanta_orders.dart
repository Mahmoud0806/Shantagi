import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/cubits.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/users/shanta/orders/elements/orders_list.dart';

class ShantaOrdersScreen extends StatefulWidget {
  const ShantaOrdersScreen({super.key});

  @override
  State<ShantaOrdersScreen> createState() => _ShantaOrdersScreenState();
}

class _ShantaOrdersScreenState extends State<ShantaOrdersScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      await BlocProvider.of<ShantaOrdersCubit>(context).getAll();
      print('${BlocProvider.of<ShantaOrdersCubit>(context).state.orders}');
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<ShantaOrdersCubit>(context);
    return Scaffold(
      appBar: customAppBar('الطلبات', context),
      body: RefreshIndicator(
          onRefresh: cubit.getAll,
          child: shantaOrdersList()),
    );
  }
}
