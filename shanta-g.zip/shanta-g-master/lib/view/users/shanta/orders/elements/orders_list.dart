import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/shanta/orders/orders_cubit.dart';
import '/view/global_elements/orders/order_item.dart';
import '/view/users/shanta/orders/details/details_screen.dart';

Widget shantaOrdersList() => BlocBuilder<ShantaOrdersCubit, ShantaOrdersState>(
      builder: (context, state) {
        return state.status == ShantaOrdersStatus.loading &&
                state.orders.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : state.orders.isEmpty
                ? const Center(
                    child: Text('لا يوجد طلبات بعد'),
                  )
                : ListView.builder(
                    itemCount: state.orders.length,
                    itemBuilder: (context, index) =>
                        orderItem(state.orders[index], () {
                      var cubit = BlocProvider.of<ShantaOrdersCubit>(context);
                      cubit.setActive(index);
                      cubit.fillAmountsFields(
                          state.orders[index].orderItems.length);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ShantaOrderDetails(),
                        ),
                      );
                    }),
                  );
      },
    );
