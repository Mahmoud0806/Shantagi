import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/home/home_cubit.dart';
import '/view/global_elements/nav_bar/nav_bar_widget.dart';
import '/view/global_elements/profile/profile_screen.dart';
import '/view/users/shanta/orders/shanta_orders.dart';
import '/view/users/shanta/products/products.dart';

class ShantaHome extends StatelessWidget {
  const ShantaHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) {
          return _screens[state.index];
        },
      ),
      bottomNavigationBar: navBar(context),
    );
  }

  final List<Widget> _screens = const [
    ProfileScreen(),
    ShantaProductsScreen(),
    ShantaOrdersScreen(),
  ];
}
