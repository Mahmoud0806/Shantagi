import 'package:flutter/material.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/data/constant/app_colors.dart';

Widget productTitle(ClientCartState state, int cartItemIndex) {
  return SizedBox(
    child: Text(
      state.items[cartItemIndex].name,
      style:  const TextStyle(
        color: AppColors.primary,
        overflow: TextOverflow.ellipsis,
        fontSize: 20,
      ),
    ),
  );
}