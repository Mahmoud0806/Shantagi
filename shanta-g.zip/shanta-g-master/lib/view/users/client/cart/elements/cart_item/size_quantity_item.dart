import 'package:flutter/material.dart';

Widget sizeQuantityItem(String size, int quantity) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceAround,
    children: [
      Text(
        size,
        style: _textStyle(),
      ),
      Text(
        '$quantity',
        style: _textStyle(),
      ),
    ],
  );
}

TextStyle _textStyle() => const TextStyle(
      fontSize: 16,
    );
