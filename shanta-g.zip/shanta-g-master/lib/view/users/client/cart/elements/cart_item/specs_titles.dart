import 'package:flutter/material.dart';

Row specsTitles() {
  return const Row(
    mainAxisAlignment: MainAxisAlignment.spaceAround,
    children: [
      Text(
        'القياس',
        style: TextStyle(
          fontSize: 16,
        ),
      ),
      Text(
        'المطلوب',
        style: TextStyle(
          fontSize: 16,
        ),
      ),
    ],
  );
}