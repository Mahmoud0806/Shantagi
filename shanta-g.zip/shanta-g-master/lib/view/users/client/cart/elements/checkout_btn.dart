import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '/view/global_elements/toast.dart';
import '/data/constant/app_colors.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/models/cart/cart_item.dart';

Widget checkoutBtn(BuildContext context, ClientCartCubit cubit) =>
    BlocBuilder<ClientCartCubit, ClientCartState>(
      builder: (context, state) {
        return state.status == CartStatus.loading
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  fixedSize: Size(
                    MediaQuery.sizeOf(context).width * .85,
                    MediaQuery.sizeOf(context).height * .06,
                  ),
                ),
                onPressed: () {
                  List items = CartItem.toListOfMaps(cubit.state.items);
                  cubit.cartCheckout(items).then((value) {
                    if(state.status == CartStatus.loaded){
                      showToast(
                          text: 'تم طلب المنتجات',
                          state: ToastStates.success,
                          gravity: ToastGravity.TOP);
                      cubit.emptyCart();
                      Navigator.maybePop(context);
                    }
                  });
                },
                child: Text(
                  'تأكيد الطلب',
                  style: _titleStyle(),
                ),
              );
      },
    );

TextStyle _titleStyle() => const TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
      color: Colors.white,
    );
