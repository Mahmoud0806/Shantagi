import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '/view/global_elements/widgets/styles.dart';

import '/data/constant/app_images.dart';

class CartEmpty extends StatelessWidget {
  const CartEmpty({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: [
          _emptyItem(context, AppImages.cartEmptyBackground),
          Center(
            child: Text(
              'السلة فارغة',
              style: Styles.label1,
            ),
          ),
        ],
      ),
    );
  }

  SizedBox _emptyItem(BuildContext context, String image) {
    return SizedBox(
      height: MediaQuery.of(context).size.height * 0.4,
      width: MediaQuery.of(context).size.width,
      child: SvgPicture.asset(image, fit: BoxFit.fill),
    );
  }
}
