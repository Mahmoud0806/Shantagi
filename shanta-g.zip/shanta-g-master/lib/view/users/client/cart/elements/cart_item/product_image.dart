import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '/data/constant/app_images.dart';

Widget productImage(String url) {
  return ClipRRect(
    borderRadius: BorderRadius.circular(5),
    child: SvgPicture.asset(
      AppImages.logo,
      height: 150,
      width: 150,
    ),
    // child: FastCachedImage(
    //   url: url,
    //   height: 150,
    //   width: 150,
    // ),
    //
  );
}
