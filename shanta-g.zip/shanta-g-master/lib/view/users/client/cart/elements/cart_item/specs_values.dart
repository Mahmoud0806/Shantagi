import 'package:flutter/material.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';

Row specsValues(ClientCartState state, int cartItemIndex) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceAround,
    children: [
      Text(
        state.items[cartItemIndex].sizes.isNotEmpty
            ? state.items[cartItemIndex].sizes
            : 'empty',
        style: const TextStyle(
          fontSize: 16,
        ),
      ),
      Text(
        state.items[cartItemIndex].amounts.isNotEmpty
            ? state.items[cartItemIndex].amounts
            : 'empty',
        style: const TextStyle(
          fontSize: 16,
        ),
      ),
    ],
  );
}