import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '/data/constant/app_images.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';

Widget emptyCartBtn(ClientCartCubit cartCubit) => Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        InkWell(
          onTap: () {
            // controller.clearCart();
            cartCubit.emptyCart();
          },
          child: SvgPicture.asset(AppImages.trash),
        ),
      ],
    );
