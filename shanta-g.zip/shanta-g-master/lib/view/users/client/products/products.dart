import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:path_provider/path_provider.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/logic/cubits/client/products/products_cubit.dart';
import '/logic/cubits/filters/filters_cubit.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/global_elements/filters.dart';
import '/view/global_elements/search_bar.dart';
import '/view/users/client/products/elements/products_view.dart';
import '../cart/cart_screen.dart';

class ClientProductsScreen extends StatefulWidget {
  const ClientProductsScreen({super.key});

  @override
  State<ClientProductsScreen> createState() => _ClientProductsScreenState();
}

class _ClientProductsScreenState extends State<ClientProductsScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      var catCubit = BlocProvider.of<CategoriesCubit>(context);
      final filterCubit = BlocProvider.of<FiltersCubit>(context);
      await BlocProvider.of<ClientProductsCubit>(context).getAll();
      await _initCashedImage();
      await catCubit.getAll();
      filterCubit.fillCats(catCubit.state.categories);
      _scrollController.addListener(_loadMoreData);

      print('${BlocProvider.of<ClientProductsCubit>(context).state.products}');
    });
    super.initState();
  }

  Future _initCashedImage() async {
    String storageLocation = (await getApplicationDocumentsDirectory()).path;
    // await FastCachedImageConfig.init(
    //   subDir: storageLocation,
    //   clearCacheAfter: const Duration(days: 15),
    // );
  }

  final controller = TextEditingController();
  final _scrollController = ScrollController();

  void _loadMoreData() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent) {
      var cubit = BlocProvider.of<ClientProductsCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      cubit.getAll(params: filterCubit.setSelectedParams(), saveOld: true, savePage: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<ClientProductsCubit>(context);
    return Scaffold(
      appBar: customAppBar(
        'المنتجات',
        context,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const CartScreen()));
          },
          icon: const Icon(Icons.shopping_cart),
        ),
      ),
      body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: searchBar('إبحث', controller, (s) {
                  print('controller :: ;:: ;; : ${controller.text}');
                  cubit.getAll(params: '?name=${controller.text}');
                }),
              ),
              _filterClient(context),
            ],
          ),
          Expanded(
            child: RefreshIndicator(
              onRefresh: BlocProvider.of<ClientProductsCubit>(context).getAll,
              child: BlocBuilder<ClientProductsCubit, ClientProductsState>(
                builder: (context, state) {
                  return state.status == ClientProductsStatus.loading &&
                          state.products.isEmpty
                      ? const Center(
                          child: CircularProgressIndicator(),
                        )
                      : clientProductsView(
                          context, state.products, _scrollController);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Padding _filterClient(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          IconButton(
            onPressed: () {
              showDialog(
                context: context,
                builder: (BuildContext context) =>
                    dialog(context, showDealers: true, onPressed: () {
                  var cubit = BlocProvider.of<ClientProductsCubit>(context);
                  var filterCubit = BlocProvider.of<FiltersCubit>(context);
                  cubit.getAll(params: filterCubit.setSelectedParams());
                  Navigator.maybePop(context);
                }),
              );
            },
            icon: const Icon(
              Icons.filter_alt_outlined,
              color: AppColors.secondarySec,
            ),
          )
        ],
      ),
    );
  }
}
