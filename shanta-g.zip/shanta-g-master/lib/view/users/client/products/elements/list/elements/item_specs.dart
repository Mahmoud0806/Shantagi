import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Padding itemSpec(String spec, String value) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          _text(
            spec,
            style: _specStyle().copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(width: 15),
          Expanded(child: _text(value, style: _specStyle().copyWith(height: 1.5))),
        ],
      ),
    );

Text _text(String value, {TextStyle? style}) {
  return Text(
    value,
    maxLines: 2,
    style: style ?? _specStyle(),
  );
}

TextStyle _specStyle() => TextStyle(
      fontSize: 18,
      height: 1,
      // fontWeight: FontWeight.w900,
      color: AppColors.primary.withOpacity(0.87),
    );
