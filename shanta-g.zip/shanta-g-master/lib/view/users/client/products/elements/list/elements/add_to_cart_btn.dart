import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '/view/global_elements/toast.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/models/cart/cart_item.dart';
import '/models/product/product.dart';
import '/data/constant/app_colors.dart';

Widget addToCartBtn(
  BuildContext context,
  Product product,
  List<String> sizes,
  List amounts,
) =>
    Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 25),
      child: ElevatedButton(
        onPressed: () {
          bool hasAmounts = false;
          for (int i = 0; i < amounts.length; i++) {
            // newAmounts.add(amounts[i].text);
            if (amounts[i].text != '') {
              hasAmounts = true;
              print(amounts[i].text);
              BlocProvider.of<ClientCartCubit>(context).addToCart(
                CartItem.fromProduct(
                  product,
                  amounts[i].text,
                  product.sizes[i],
                  'notes',
                ),
              );
              amounts[i].clear();
            }
          }
          if (hasAmounts) {
            showToast(
                text: 'تم الاضافة للسلة',
                state: ToastStates.success,
                gravity: ToastGravity.TOP);
          } else {
            showToast(
                text: 'الرجاء إضافة قياسات',
                state: ToastStates.warning,
                gravity: ToastGravity.TOP);
          }
          // for (int i = 0; i < amounts.length; i++) {
          //   // newAmounts.add(amounts[i].text);
          //   if (amounts[i].text != '') {
          //     print(amounts[i].text);
          //     BlocProvider.of<ClientCartCubit>(context).addToCart(
          //       CartItem.fromProduct(
          //         product,
          //         amounts[i].text,
          //         product.sizes[i],
          //         'notes',
          //       ),
          //     );
          //   }
          // }
        },
        style: _btnStyle(context),
        child: Text(
          'إضافة إلى السلة',
          style: _style(),
        ),
      ),
    );

ButtonStyle _btnStyle(BuildContext context) {
  return ElevatedButton.styleFrom(
    minimumSize: Size(
      MediaQuery.of(context).size.width * 0.8,
      MediaQuery.of(context).size.height * 0.07,
    ),
    backgroundColor: AppColors.primary,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(5),
    ),
    padding: const EdgeInsets.symmetric(vertical: 10),
  );
}

TextStyle _style() => TextStyle(
    fontSize: 20,
    // height: 1,
    fontWeight: FontWeight.bold,
    color: AppColors.background.withOpacity(0.87));
