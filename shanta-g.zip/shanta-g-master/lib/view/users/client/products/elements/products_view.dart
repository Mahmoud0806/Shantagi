import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/global/toggle_view/toggle_cubit.dart';
import '/view/global_elements/products/elements/header/header.dart';
import '/view/users/client/products/elements/grid/products_grid.dart';
import '/view/users/client/products/elements/list/products_list.dart';

SizedBox clientProductsView(BuildContext context, products, ScrollController controller) => SizedBox(
      child: Column(
        children: _children(context, products, controller),
      ),
    );

List<Widget> _children(BuildContext context, products, ScrollController controller) => [
      productsViewHeader(context),
      BlocBuilder<ToggleCubit, ToggleState>(
        builder: (context, state) {
          return state.isListView
              ? clientProductsList(products)
              : clientProductsGrid(products, controller);
        },
      ),
    ];
