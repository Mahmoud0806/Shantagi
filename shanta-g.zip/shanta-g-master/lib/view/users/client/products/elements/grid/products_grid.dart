import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/view/users/client/products/details/client_product_details.dart';
import '/logic/cubits/client/products/products_cubit.dart';
import '/view/users/client/products/elements/grid/elements/grid_item.dart';
import '/models/product/product.dart';

Widget clientProductsGrid(List<Product> products, ScrollController controller) => Expanded(
      child: products.isEmpty
          ? const Center(
              child: Text('لا يوجد منتجات بعد'),
            )
          : GridView.builder(
        controller: controller,
              shrinkWrap: true,
              itemCount: products.length,
              gridDelegate: _gridDelegate(),
              itemBuilder: (context, index) =>
                  clientGridItem(context, products[index], () {
                var cubit = BlocProvider.of<ClientProductsCubit>(context);
                cubit.setActiveProduct(index);
                var cartCubit = BlocProvider.of<ClientCartCubit>(context);
                cartCubit.fillAmount(products[index].sizes.length);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) =>
                        ClientProductDetails(product: products[index]),
                  ),
                );
              }),
            ),
    );

SliverGridDelegateWithFixedCrossAxisCount _gridDelegate() =>
    const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2,
    );
