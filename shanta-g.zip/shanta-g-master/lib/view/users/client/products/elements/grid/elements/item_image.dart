import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';

class CashedImage extends StatefulWidget {
  final String url;

  const CashedImage({super.key, required this.url});

  @override
  State<CashedImage> createState() => _CashedImageState();
}

class _CashedImageState extends State<CashedImage> {
  @override
  void initState() {
    _initCashedImage();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return _image(context, widget.url);
  }

  Future _initCashedImage() async {
    String storageLocation = (await getApplicationDocumentsDirectory()).path;
    // await FastCachedImageConfig.init(
    //   subDir: storageLocation,
    //   clearCacheAfter: const Duration(days: 15),
    // );
  }

  Widget _image(BuildContext context, String url) => ClipRRect(
    borderRadius: BorderRadius.circular(15),
    child: CachedNetworkImage(
      fit: BoxFit.cover,
      // url: 'https://st.depositphotos.com/1000128/1949/i/450/depositphotos_19492613-stock-photo-gold-ingots.jpg',
      imageUrl: url,
      errorWidget: _errorBuilder,
      // loadingBuilder: _loadingBuilder,
    ),
  );

  Widget _errorBuilder(context, exception, stacktrace) {
    return const Center(
      child: Text(
        'error while loading Image',
        style: TextStyle(color: Colors.red),
      ),
    );
    // return Text(stacktrace.toString());
  }

  Widget _loadingBuilder(context, progress) {
    return SizedBox(
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (progress.isDownloading && progress.totalBytes != null)
            indicatorText(progress),
          _loadingIndicator(progress),
        ],
      ),
    );
  }

  Text indicatorText(progress) {
    return Text(
      '${progress.downloadedBytes ~/ 1024} / ${progress.totalBytes! ~/ 1024} kb',
      style: const TextStyle(color: Colors.red),
    );
  }

  SizedBox _loadingIndicator(progress) {
    return SizedBox(
      width: 120,
      height: 120,
      child: CircularProgressIndicator(
          color: Colors.red, value: progress.progressPercentage.value),
    );
  }
}
