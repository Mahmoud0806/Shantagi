import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/models/product/product.dart';

import 'elements/product_item.dart';

Widget clientProductsList(List<Product> products) => Expanded(
      child: products.isEmpty
          ? const Center(
              child: Text('لا يوجد منتجات بعد'),
            )
          : PageView.builder(
              itemCount: products.length,
              pageSnapping: true,
              scrollDirection: Axis.vertical,
              itemBuilder: (context, pagePosition) {
                var cartCubit = BlocProvider.of<ClientCartCubit>(context);
                cartCubit.fillAmount(products[pagePosition].sizes.length);
                // controller.createMyImages(controller.products[pagePosition].images!);
                return productItem(context, products[pagePosition]);
              },
            ),
    );
