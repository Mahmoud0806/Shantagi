import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../global_elements/toast.dart';
import '/data/constant/app_colors.dart';


import '/models/product/product.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/global_elements/products/details/product_details.dart';

class ClientProductDetails extends StatefulWidget {
  final Product product;

  const ClientProductDetails({super.key, required this.product});

  @override
  State<ClientProductDetails> createState() => _ClientProductDetailsState();
}

class _ClientProductDetailsState extends State<ClientProductDetails> {
  @override
  void initState() {
    fToast.init(context);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('تفاصيل المنتج', context,
          showBack: true, foreground: AppColors.primary),
      body: productDetails(context, widget.product, showCart: true),
    );
  }
}
