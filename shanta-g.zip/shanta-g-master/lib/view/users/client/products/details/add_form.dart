import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/view/global_elements/widgets/styles.dart';

Widget requirementForm(BuildContext context, List<String> sizes) {
  var cubit = BlocProvider.of<ClientCartCubit>(context);
  return (sizes.isNotEmpty)
      ? Center(
          child: SizedBox(
            height: (90 + (30 * sizes.length / 1.35)),
            width: MediaQuery.of(context).size.width * 0.6,
            // decoration: BoxDecoration(
            //   border: Border.all(width: 1),
            //   borderRadius: BorderRadius.circular(5),
            // ),
            // color: Colors.green,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text(
                        'القياسات المتوفرة',
                        style: Styles.label1.copyWith(height: 1.5),
                      ),
                      Text(
                        'العدد',
                        style: Styles.label1.copyWith(height: 1.5),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Container(
                              width: 30,
                              height: 20,
                              decoration: BoxDecoration(
                                border: Border.all(),
                                borderRadius: BorderRadius.circular(3),
                              ),
                              child: Center(
                                  child: Text(
                                sizes[index].replaceAll('"', ''),
                                style: Styles.label2.copyWith(height: 0),
                              )),
                            ),
                            SizedBox(
                              width: 30,
                              height: 20,
                              child: TextFormField(
                                textAlign: TextAlign.center,
                                maxLength: 2,
                                controller: cubit.sizesControllers[index],
                                // validator: (_) =>
                                //     controller
                                //         .numberValidator(),
                                cursorColor: AppColors.primary,
                                style:
                                    const TextStyle(color: AppColors.primary),
                                decoration: const InputDecoration(
                                  counterText: '',
                                  contentPadding: EdgeInsets.zero,
                                  focusedBorder: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color: AppColors.primary,
                                      width: 1.5,
                                    ),
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(3),
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black),
                                    borderRadius: BorderRadius.all(
                                      Radius.circular(3),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                    itemCount: sizes.length,
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.all(5),
                  child: Text(
                    'الرجاء إدخال أرقام فقط',
                    style: TextStyle(
                      fontFamily: 'Sukar',
                      fontSize: 16,
                    ),
                  ),
                ),
              ],
            ),
          ),
        )
      : Padding(
          padding: const EdgeInsets.symmetric(vertical: 3),
          child: Row(
            children: [
              Text(
                'العدد المطلوب:',
                style: Styles.label1.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(width: 15),
              SizedBox(
                width: 70,
                height: 45,
                child: TextFormField(
                  textAlign: TextAlign.center,
                  maxLength: 2,
                  // controller:
                  // controller.numberController,
                  // validator: (_) =>
                  //     controller
                  //         .numberValidator(),
                  cursorColor: AppColors.primary,
                  style: const TextStyle(color: AppColors.primary),
                  decoration: const InputDecoration(
                    counterText: '',
                    errorStyle: TextStyle(fontSize: 12),
                    contentPadding: EdgeInsets.symmetric(vertical: 5),
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: AppColors.primary,
                        width: 1.5,
                      ),
                      borderRadius: BorderRadius.all(
                        Radius.circular(3),
                      ),
                    ),
                    errorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.red),
                      borderRadius: BorderRadius.all(
                        Radius.circular(3),
                      ),
                    ),
                    focusedErrorBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.transparent),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                      borderRadius: BorderRadius.all(
                        Radius.circular(3),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
}
