import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/client/orders/orders_cubit.dart';
import '/logic/cubits/client/orders/orders_cubit.dart';
import '/view/users/client/orders/elements/orders_list.dart';
import '/view/users/wholesaler/orders/elements/orders_list.dart';

import '/view/global_elements/app_bar/app_bar.dart';

class ClientOrdersScreen extends StatefulWidget {
  const ClientOrdersScreen({super.key});

  @override
  State<ClientOrdersScreen> createState() => _ClientOrdersScreenState();
}

class _ClientOrdersScreenState extends State<ClientOrdersScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      await BlocProvider.of<ClientOrdersCubit>(context).get();
    });
    super.initState();
  }
  
  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<ClientOrdersCubit>(context);
    return Scaffold(
      appBar: customAppBar('الطلبات', context),
      body: RefreshIndicator(
          onRefresh: cubit.get,
          child: clientOrdersList(context)),
      // body: SizedBox(child: wholesalerOrdersList()),
    );
  }
}
