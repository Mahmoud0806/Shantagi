import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/client/orders/orders_cubit.dart';
import '/view/global_elements/orders/order_item.dart';
import '/view/users/client/orders/details/details_screen.dart';

Widget clientOrdersList(BuildContext context) {
  var cubit = BlocProvider.of<ClientOrdersCubit>(context);
  return BlocBuilder<ClientOrdersCubit, ClientOrdersState>(
    builder: (context, state) {
      return state.orders.isEmpty &&
            state.status == ClientOrdersStatus.loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : state.orders.isEmpty
          ? const Center(
              child: Text('لا يوجد طلبات بعد'),
            )
          : ListView.builder(
              itemCount: state.orders.length,
              shrinkWrap: true,
              itemBuilder: (context, index) =>
                  orderItem(state.orders[index], () {
                cubit.setActiveOrder(index);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => const ClientOrderDetails(),
                  ),
                );
              }),
            );
    },
  );
}
