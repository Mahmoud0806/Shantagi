import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/client/orders/orders_cubit.dart';
import '/view/users/client/orders/details/manage_items_btn.dart';
import 'item_spec.dart';
import 'item_title.dart';

class ClientItemInfo extends StatelessWidget {
  final int index;

  const ClientItemInfo({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<ClientOrdersCubit>(context);
    return Expanded(
      child: BlocBuilder<ClientOrdersCubit, ClientOrdersState>(
        builder: (context, state) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _children(context, state, index),
          );
        },
      ),
    );
  }

  List<Widget> _children(
          BuildContext context, ClientOrdersState state, index) =>
      [
        clientItemTitle(context, state.order.orderItems[index].product.name),
        ClientItemSpec(
            title: 'القياس:', value: state.order.orderItems[index].size),
        ClientItemSpec(
            title: 'العدد المطلوب:',
            value: state.order.orderItems[index].requiredAmount.toString()),
        state.order.orderItems[index].acceptableAmount >= 0
            ? ClientItemSpec(
                title: 'العدد المقبول:',
                value:
                    state.order.orderItems[index].acceptableAmount.toString())
            : const SizedBox.shrink(),
        if (state.order.orderItems[index].notes != '')
          ClientItemSpec(
            title: 'ملاحظات:',
            value: state.order.orderItems[index].notes,
          ),
        if (state.order.orderItems[index].status == 'answered')
          ManageUserOrderItemBtn(
            id: state.order.orderItems[index].id,
            index: index,
          ),
      ];
}
