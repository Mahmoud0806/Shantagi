import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget clientItemTitle(BuildContext context, title) => Padding(
  padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
  child: SizedBox(
      width:MediaQuery.sizeOf(context).width * 0.5 ,
        child: Text(
          title,
          overflow: TextOverflow.ellipsis,
          style: _textStyle(),
        ),
      ),
);

TextStyle _textStyle() {
  return const TextStyle(
    color: AppColors.secondarySec,
    fontSize: 20,
  );
}
