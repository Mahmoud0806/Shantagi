import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/client/orders/orders_cubit.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import 'item_info.dart';

class ClientOrderDetails extends StatefulWidget {
  const ClientOrderDetails({super.key});

  @override
  State<ClientOrderDetails> createState() => _ClientOrderDetailsState();
}

class _ClientOrderDetailsState extends State<ClientOrderDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('تفاصيل الطلبية', context, showBack: true),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: BlocBuilder<ClientOrdersCubit, ClientOrdersState>(
          builder: (context, state) {
            return ListView.builder(
              shrinkWrap: true,
              itemBuilder: (context, int index) =>
                  _orderItem(context, state, index),
              itemCount: state.order.orderItems.length,
              // itemCount: order.orderItems!.length,
            );
          },
        ),
      ),
    );
  }

  SizedBox _orderItem(BuildContext context, state, int index) {
    return SizedBox(
      // height: MediaQuery.sizeOf(context).height * 0.35,
      child: Card(
        color: AppColors.secondarySec.withOpacity(0.3),
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _itemImage(state, index),
              ClientItemInfo(index: index),
            ],
          ),
        ),
      ),
    );
  }

  SizedBox _itemImage(ClientOrdersState state, int index) {
    return SizedBox(
      height: 120,
      width: 120,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(5),
        child: CachedNetworkImage(
          // 'src',
          imageUrl: state.order.orderItems[index].product.images.isNotEmpty
              ? state.order.orderItems[index].product.images.first.attachment
              : '',
          fit: BoxFit.cover,
          errorWidget: (context, error, stackTrace) => const Center(
            child: Text('unable to load', style: TextStyle(
              color: Colors.red,
            ),),
          ),
        ),
      ),
    );
  }
}
