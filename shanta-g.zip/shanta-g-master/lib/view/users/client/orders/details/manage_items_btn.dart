import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/cubits.dart';

class ManageUserOrderItemBtn extends StatelessWidget {
  final int id;
  final int index;

  const ManageUserOrderItemBtn(
      {required this.id, required this.index, super.key});

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<ClientOrdersCubit>(context);
    return BlocBuilder<ClientOrdersCubit, ClientOrdersState>(
      builder: (context, state) {
        return state.status == ClientOrdersStatus.loading &&
                id == 'cubit.state.order.or'
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _itemManageButton('رفض', Colors.red, () {
                    cubit.changeItemStatus(id, index, false);
                    // cubit.orderItemId = id;
                    // cubit.changeOrderItem(id, 'cancelled');
                    // Navigator.pop(context);
                  }),
                  _itemManageButton('قبول', Colors.green, () {
                    cubit.changeItemStatus(id, index, true).then((onValue) {
                      cubit.get();
                      Navigator.maybePop(context);
                    });
                    // cubit.orderItemId = id;
                    // cubit.changeOrderItem(id, 'accepted');
                    // Navigator.pop(context);
                  }),
                ],
              );
      },
    );
  }

  InkWell _itemManageButton(String title, Color color, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        decoration: _boxDecoration(color),
        width: 50,
        height: 20,
        child: _buttonTitle(title),
      ),
    );
  }

  BoxDecoration _boxDecoration(Color color) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(3),
      color: color,
    );
  }

  Center _buttonTitle(String title) {
    return Center(
      child: Text(
        title,
        style:
            TextStyle(color: Colors.white, fontSize: 14, fontFamily: "Sukar"),
      ),
    );
  }
}
