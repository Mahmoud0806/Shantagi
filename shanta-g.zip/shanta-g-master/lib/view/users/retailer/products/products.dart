import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/logic/cubits/filters/filters_cubit.dart';
import '/logic/cubits/retailer/dealers/retailer_dealers_cubit.dart';
import '/logic/cubits/retailer/products/products_cubit.dart';
import '/models/user.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/global_elements/filters.dart';
import '/view/global_elements/search_bar.dart';
import '/view/users/retailer/cart/cart_screen.dart';
import '/view/users/retailer/products/elements/products_view.dart';

class RetailerProductsScreen extends StatefulWidget {
  const RetailerProductsScreen({super.key});

  @override
  State<RetailerProductsScreen> createState() => _RetailerProductsScreenState();
}

class _RetailerProductsScreenState extends State<RetailerProductsScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      var dealersCubit = BlocProvider.of<RetailerDealersCubit>(context);
      var catCubit = BlocProvider.of<CategoriesCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      await BlocProvider.of<RetailerProductsCubit>(context).getAll();
      await catCubit.getAll();
      List<User> dealers = await dealersCubit.getAll();
      filterCubit.fillCats(catCubit.state.categories);
      filterCubit.fillDealers(dealers);
      _scrollController.addListener(_loadMoreData);
    });
    super.initState();
  }

  final controller = TextEditingController();
  final _scrollController = ScrollController();

  void _loadMoreData() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent) {
      var cubit = BlocProvider.of<RetailerProductsCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      cubit.getAll(params: filterCubit.setSelectedParams(), saveOld: true, savePage: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<RetailerProductsCubit>(context);
    return Scaffold(
      appBar: customAppBar(
        'المنتجات',
        context,
        leading: IconButton(
          onPressed: () {
            Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const CartScreen()),
            );
          },
          icon: const Icon(Icons.shopping_cart),
        ),
      ),
      body: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: searchBar('إبحث', controller, (s) {
                  print('controller :: ;:: ;; : ${controller.text}');
                  cubit.getAll(params: '?name=${controller.text}');
                }),
              ),
              _filterRetailer(context),
            ],
          ),
          Expanded(
            child: BlocBuilder<RetailerProductsCubit, RetailerProductsState>(
              builder: (context, state) {
                return RefreshIndicator(
                    onRefresh: () => cubit.getAll(),
                    child: state.status == RetailerProductsStatus.loading &&
                            state.products.isEmpty
                        ? const Center(
                            child: CircularProgressIndicator(),
                          )
                        : retailerProductsView(
                            context,
                            state.products,
                            controller: _scrollController,
                          ));
              },
            ),
          ),
        ],
      ),
    );
  }

  Padding _filterRetailer(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            IconButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) =>
                      dialog(context, showDealers: true, onPressed: () {
                    var cubit = BlocProvider.of<RetailerProductsCubit>(context);
                    var filterCubit = BlocProvider.of<FiltersCubit>(context);
                    cubit.getAll(params: filterCubit.setSelectedParams());
                    Navigator.maybePop(context);
                  }),
                );
              },
              icon: const Icon(
                Icons.filter_alt_outlined,
                color: AppColors.secondarySec,
              ),
            )
          ],
        ),
      );
}
