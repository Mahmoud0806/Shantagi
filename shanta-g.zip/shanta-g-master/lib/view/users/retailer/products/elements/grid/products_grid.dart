import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/cubits.dart';
import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';
import '/models/product/product.dart';
import '../../elements/details/retailer_product_details.dart';
import '../../elements/grid/elements/grid_item.dart';

Widget retailerProductsGrid(
        List<Product> products, ScrollController controller) =>
    Expanded(
      child: products.isNotEmpty
          ? GridView.builder(
              controller: controller,
              shrinkWrap: true,
              itemCount: products.length,
              gridDelegate: _gridDelegate(),
              itemBuilder: (context, index) => retailerGridItem(
                context,
                products[index],
                () {
                  var cubit = BlocProvider.of<RetailerProductsCubit>(context);
                  cubit.setActiveProduct(index);
                  var cartCubit = BlocProvider.of<RetailerCartCubit>(context);
                  cartCubit.fillAmount(products[index].sizes.isEmpty
                      ? 1
                      : products[index].sizes.length);
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) =>
                          RetailerProductDetails(product: products[index]),
                    ),
                  );
                },
              ),
              // RetailerProductDetails(product: products[index]),
            )
          : const Center(
              child: Text('لا يوجد منتجات بعد'),
            ),
    );

SliverGridDelegateWithFixedCrossAxisCount _gridDelegate() =>
    const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2,
    );
