import 'package:flutter/material.dart';

import '/models/product/product.dart';
import 'elements/product_item.dart';

Widget retailerProductsList(List<Product> products) => Expanded(
      child: products.isNotEmpty
          ? PageView.builder(
              itemCount: products.length,
              pageSnapping: true,
              scrollDirection: Axis.vertical,
              itemBuilder: (context, pagePosition) {
                // controller.createMyImages(controller.products[pagePosition].images!);
                return productItem(
                    context, products[pagePosition], pagePosition);
              },
            )
          : const Center(
              child: Text('لا يوجد منتجات بعد'),
            ),
    );
