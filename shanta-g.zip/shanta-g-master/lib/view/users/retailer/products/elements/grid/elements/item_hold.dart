import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

Widget itemHold(bool isHold) => SizedBox(
      child: SvgPicture.asset(
        _image(isHold),
        height: 20,
        width: 20,
      ),
    );

String _image(bool isHold) =>
    isHold ? 'assets/icons/global/hold.svg' : 'assets/icons/global/show.svg';
