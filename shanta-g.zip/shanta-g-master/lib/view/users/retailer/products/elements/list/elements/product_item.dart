import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';
import '/logic/cubits/retailer/products/products_cubit.dart';
import '/models/product/product.dart';
import '/view/users/retailer/products/elements/details/retailer_product_details.dart';
import 'carousel_indicator.dart';
import 'carousel_slider.dart';
import 'item_specs.dart';
import 'item_title.dart';

Widget productItem(BuildContext context, product, int index) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: InkWell(
        onTap: () {
          var cubit = BlocProvider.of<RetailerProductsCubit>(context);
          cubit.setActiveProduct(index);
          var cartCubit = BlocProvider.of<RetailerCartCubit>(context);
          cartCubit.fillAmount(cubit.state.products[index].sizes.length);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  RetailerProductDetails(product: cubit.state.products[index]),
            ),
          );
        },
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _children(context, product),
          ),
        ),
      ),
    );

List<Widget> _children(BuildContext context, Product product) => [
      const SizedBox(height: 15),
      _itemImage(context, product.images),
      itemTitle(product.name),
      itemSpec('الوزن:', product.weight.toString()),
      itemSpec('عيار:', product.karat),
      itemSpec('الوصف:', product.description),
      itemSpec('القياسات المتوفرة:', product.sizes.join(', ')),
    ];

Stack _itemImage(BuildContext context, images) {
  return Stack(
    alignment: Alignment.bottomCenter,
    children: [
      carouselSlider(context, images),
      carouselIndicator(1, 0),
    ],
  );
}
