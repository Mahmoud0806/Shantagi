import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';
import '/models/cart/cart_item.dart';
import '/models/product/product.dart';
import '/view/global_elements/fields/custom_text_field.dart';
import '/view/global_elements/toast.dart';
import '/view/global_elements/widgets/styles.dart';

Widget retailerAddToCartBtn(
  BuildContext context,
  Product product,
  List<String> sizes,
  List amounts,
) =>
    Padding(
      padding: const EdgeInsets.symmetric(vertical: 45, horizontal: 25),
      child: ElevatedButton(
        onPressed: () {
          var noteController = TextEditingController();
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('أدخل الملاحظات',
                  style:
                      const TextStyle().copyWith(color: AppColors.primaryText)),
              content: Form(
                // key: formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    customTextField(
                      controller: noteController,
                      label: '',
                      // validate: (_) => controller.inputValidator(),
                    ),
                    const SizedBox(height: 15),
                    InkWell(
                      onTap: () {
                        for (int i = 0; i < amounts.length; i++) {
                          // newAmounts.add(amounts[i].text);
                          if (amounts[i].text != '') {
                            print(amounts[i].text);
                            var cubit =
                                BlocProvider.of<RetailerCartCubit>(context);

                            product.sizes.isEmpty
                                ? cubit
                                    .addToCart(
                                    CartItem.fromProduct(
                                      product,
                                      amounts.first.text,
                                      '',
                                      noteController.text,
                                    ),
                                  )
                                    .then((onValue) {
                                    Navigator.maybePop(context);
                                    showToast(
                                        text: 'تمت اضافة المنتج للسلة',
                                        state: ToastStates.success,
                                        gravity: ToastGravity.TOP);
                                    cubit.clearAmounts();
                                  })
                                : cubit
                                    .addToCart(
                                    CartItem.fromProduct(
                                      product,
                                      amounts[i].text,
                                      product.sizes[i],
                                      noteController.text,
                                    ),
                                  )
                                    .then((onValue) {
                                    Navigator.maybePop(context);
                                    showToast(
                                        text: 'تمت اضافة المنتج للسلة',
                                        state: ToastStates.success,
                                        gravity: ToastGravity.TOP);
                                    cubit.clearAmounts();
                                  });
                          }
                        }
                        // if (formKey.currentState != null &&
                        //     formKey.currentState!.validate()) {
                        //   controller.addCategory();
                        //   Navigator.pop(context);
                        // }
                        // controller.addCategory(context);
                      },
                      child: Container(
                        padding: EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          color: AppColors.primary,
                        ),
                        child: Text(
                          'إضافة',
                          style: Styles.buttonText.copyWith(
                            color: AppColors.background,
                            fontSize: 18,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        style: _btnStyle(context),
        child: Text(
          'إضافة إلى السلة',
          style: _style(),
        ),
      ),
    );

ButtonStyle _btnStyle(BuildContext context) {
  return ElevatedButton.styleFrom(
    minimumSize: Size(
      MediaQuery.of(context).size.width * 0.8,
      MediaQuery.of(context).size.height * 0.07,
    ),
    backgroundColor: AppColors.primary,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(5),
    ),
    padding: const EdgeInsets.symmetric(vertical: 10),
  );
}

TextStyle _style() => TextStyle(
    fontSize: 20,
    // height: 1,
    fontWeight: FontWeight.bold,
    color: AppColors.background.withOpacity(0.87));
