import 'package:flutter/material.dart';
import '/models/product/product.dart';
import '/view/users/client/products/elements/grid/elements/item_image.dart';

import 'item_hold.dart';
import 'item_image.dart';

Widget retailerGridItem(
    BuildContext context, Product product, VoidCallback onTap) =>
    Padding(
      padding: const EdgeInsets.all(15.0),
      child: SizedBox(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(15),
          child: Stack(
            children: _children(context, product, onTap),
          ),
        ),
      ),
    );

List<Widget> _children(
    BuildContext context, Product product, VoidCallback onTap) {
  // var cubit = BlocProvider.of<ClientProductsCubit>(context);
  return [
    CashedImage(
      url: product.images.isNotEmpty ? product.images.first.attachment : '',
    ),
    // itemHold(product.hold),
    _gestureDetector(context, onTap),
  ];
}

GestureDetector _gestureDetector(BuildContext context, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
    //     () {
    //   Navigator.of(context).push(
    //     MaterialPageRoute(
    //       builder: (_) => productDetails(context),
    //     ),
    //   );
    // },
  );
}
