
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';
import '/models/product/product.dart';
import '/models/product/product_image.dart';
import '/view/global_elements/products/details/elements/product_spec_item.dart';
import '/view/global_elements/products/details/elements/product_title.dart';
import '/view/users/retailer/products/elements/details/add_to_cart_btn.dart';

import '../list/elements/carousel_indicator.dart';
import '../list/elements/carousel_slider.dart';
import 'add_form.dart';

Widget retailerProductDetails(BuildContext context, Product product,
    {bool? showCart, cubit}) =>
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _children(context, product, showCart: showCart, cubit: cubit),
        ),
      ),
    );

List<Widget> _children(BuildContext context, Product product,
    {bool? showCart, cubit}) {
  var cubit = BlocProvider.of<RetailerCartCubit>(context);

  return [
    const SizedBox(height: 15),
    _itemImage(context, product.images),
    productTitle(product.name),
    productSpecItem(context,'الوزن:', '${product.weight}'),
    productSpecItem(context,'عيار:', product.karat),
    productSpecItem(context,'الوصف:', product.description),
    // productSpecItem('القياسات المتوفرة:', product.sizes.join(', ')),
      requirementForm(context, product.sizes),
      retailerAddToCartBtn(context, product, [],cubit.sizesControllers )

  ];
}

Stack _itemImage(BuildContext context, List<ProductImage> images) {
  print('image link :: :: ${images.isNotEmpty ? images.first.attachment : ''}');
  return Stack(
    alignment: Alignment.bottomCenter,
    children: [
      carouselSlider(context, images),
      carouselIndicator(images.length, 0),
    ],
  );
}
