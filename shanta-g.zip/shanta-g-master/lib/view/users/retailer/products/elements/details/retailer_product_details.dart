import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../../global_elements/toast.dart';
import '/data/constant/app_colors.dart';
import '/view/users/retailer/products/elements/details/retailer_product_info.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';

import '/models/product/product.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/global_elements/products/details/product_details.dart';

class RetailerProductDetails extends StatefulWidget {
  final Product product;

  const RetailerProductDetails({super.key, required this.product});

  @override
  State<RetailerProductDetails> createState() => _RetailerProductDetailsState();
}

class _RetailerProductDetailsState extends State<RetailerProductDetails> {

  @override
  void initState() {
    fToast.init(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('تفاصيل المنتج', context, showBack: true, foreground: AppColors.primary),
      body: retailerProductDetails(context, widget.product, showCart: true),
      // body: productDetails(context, widget.product, showCart: true),
    );
  }
}
