import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/global/toggle_view/toggle_cubit.dart';
import '/models/product/product.dart';
import '/view/global_elements/products/elements/header/header.dart';
import '/view/users/retailer/products/elements/grid/products_grid.dart';
import '/view/users/retailer/products/elements/list/products_list.dart';

SizedBox retailerProductsView(BuildContext context, List<Product> products, {ScrollController? controller}) =>
    SizedBox(
      child: Column(
        children: _children(context, products, controller: controller),
      ),
    );

List<Widget> _children(BuildContext context, List<Product> products, {ScrollController? controller}) => [
      productsViewHeader(context),
      BlocBuilder<ToggleCubit, ToggleState>(
        builder: (context, state) {
          print(products.length);
          return state.isListView
              ? retailerProductsList(products)
              : retailerProductsGrid(products, controller!);
        },
      ),
    ];
