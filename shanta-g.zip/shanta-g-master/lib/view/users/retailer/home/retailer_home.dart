import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/users/retailer/orders/orders_screen.dart';
import '/view/users/retailer/products/products.dart';

import '/logic/cubits/home/home_cubit.dart';
import '/view/global_elements/nav_bar/nav_bar_widget.dart';
import '/view/global_elements/profile/profile_screen.dart';

class RetailerHome extends StatelessWidget {
  const RetailerHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) {
          return _screens[state.index];
        },
      ),
      bottomNavigationBar: navBar(context),
    );
  }

  final List<Widget> _screens = const [
    ProfileScreen(),
    RetailerProductsScreen(),
    RetailerOrdersScreen(),
  ];
}
