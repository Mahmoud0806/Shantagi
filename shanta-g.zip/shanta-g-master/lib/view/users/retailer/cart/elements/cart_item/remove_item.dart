import 'package:flutter/material.dart';

import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';

Widget removeItem(RetailerCartCubit cubit, int id) => IconButton(
      onPressed: () {
        cubit.removeFromCart(id);
      },
      icon: const Icon(
        Icons.delete_forever_outlined,
        color: Colors.red,
      ),
    );
