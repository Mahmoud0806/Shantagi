import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';

import '/data/constant/app_images.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';

Widget emptyCartBtn(RetailerCartCubit cartCubit) => Row(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        InkWell(
          onTap: () {
            // controller.clearCart();
            cartCubit.emptyCart();
          },
          child: SvgPicture.asset(AppImages.trash),
        ),
      ],
    );
