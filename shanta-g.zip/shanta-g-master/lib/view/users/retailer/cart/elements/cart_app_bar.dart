import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

AppBar cartAppBar(BuildContext context) => AppBar(
      automaticallyImplyLeading: false,
      title: const Text(
        'سلة المشتريات',
        style: TextStyle(
          fontFamily: 'Sukar',
          fontSize: 25,
          fontWeight: FontWeight.bold,
          color: AppColors.primary,
        ),
      ),
      backgroundColor: Colors.grey[50],
      elevation: 0,
      leading:
        IconButton(
          padding: const EdgeInsets.all(0),
          onPressed: () {
            Navigator.maybePop(context);
          },
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: AppColors.primary,),
        ),
    );
