import 'package:flutter/material.dart';

import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';

Row specsValues(RetailerCartState state, int cartItemIndex) {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceAround,
    children: [
      Text(
        state.items[cartItemIndex].sizes.isNotEmpty
            ? state.items[cartItemIndex].sizes
            : 'empty',
        style: const TextStyle(
          fontSize: 16,
        ),
      ),
      Text(
        state.items[cartItemIndex].amounts.isNotEmpty
            ? state.items[cartItemIndex].amounts
            : 'empty',
        style: const TextStyle(
          fontSize: 16,
        ),
      ),
    ],
  );
}
