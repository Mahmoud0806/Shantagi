import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';
import '/models/cart/cart_item.dart';

Widget checkoutBtn(BuildContext context, RetailerCartCubit cubit) =>
    BlocBuilder<RetailerCartCubit, RetailerCartState>(
      builder: (context, state) {
        return state.status == CartStatus.loading
            ? const Center(child: CircularProgressIndicator())
            : ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primary,
                  fixedSize: Size(
                    MediaQuery.sizeOf(context).width * .85,
                    MediaQuery.sizeOf(context).height * .06,
                  ),
                ),
                onPressed: () {
                  List items = CartItem.toListOfMaps(cubit.state.items);
                  print('$items');
                  cubit.cartCheckout(items);
                },
                child: Text(
                  'تأكيد الطلب',
                  style: _titleStyle(),
                ),
              );
      },
    );

TextStyle _titleStyle() => const TextStyle(
      fontSize: 20,
      fontWeight: FontWeight.bold,
      color: Colors.white,
    );
