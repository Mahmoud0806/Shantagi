import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

Widget productImage(String url) {
  return ClipRRect(
    borderRadius: BorderRadius.circular(5),
    // child: SvgPicture.asset(
    //   AppImages.logo,
    //   height: 150,
    //   width: 150,
    // ),
    child: CachedNetworkImage(
      imageUrl: url,
      height: 150,
      width: 150,
    ),
  );
}
