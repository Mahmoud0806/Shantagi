import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/retailer/cart/retailer_cart_cubit.dart';
import '/view/users/client/cart/elements/cart_empty.dart';
import 'elements/cart_app_bar.dart';
import 'elements/cart_item/product_image.dart';
import 'elements/cart_item/product_title.dart';
import 'elements/cart_item/remove_item.dart';
import 'elements/cart_item/specs_titles.dart';
import 'elements/cart_item/specs_values.dart';
import 'elements/checkout_btn.dart';
import 'elements/empty_cart_btn.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  @override
  Widget build(BuildContext context) {
    var cartCubit = BlocProvider.of<RetailerCartCubit>(context);
    return BlocConsumer<RetailerCartCubit, RetailerCartState>(
      listener: (context, state) {},
      builder: (context, state) {
        return Scaffold(
          appBar: cartAppBar(context, ),
          body: (state.items.isEmpty)
              ? const CartEmpty()
              : Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      emptyCartBtn(cartCubit),
                      Expanded(
                        child: ListView.builder(
                          itemBuilder: (context, int cartItemIndex) => Padding(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    productImage(
                                        state.items[cartItemIndex].imageLink),
                                    Expanded(
                                      child: Column(
                                        children: [
                                          Row(
                                            children: [
                                              const Spacer(),
                                              productTitle(
                                                  state, cartItemIndex),
                                              const Spacer(),
                                              removeItem(
                                                cartCubit,
                                                cartItemIndex,
                                              ),
                                            ],
                                          ),
                                          SizedBox(
                                            height: 125,
                                            width: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.4,
                                            child: Column(
                                              children: [
                                                Padding(
                                                  padding:
                                                      const EdgeInsets.all(8.0),
                                                  child: Column(
                                                    children: [
                                                      specsTitles(),
                                                      specsValues(
                                                          state, cartItemIndex),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          itemCount: state.items.length,
                        ),
                      ),
                      checkoutBtn(context, cartCubit),
                    ],
                  ),
                ),
        );
      },
    );
  }
}
