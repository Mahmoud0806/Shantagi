import 'package:flutter/material.dart';

import '/models/order/order_item.dart';
import '/view/users/retailer/orders/details/item_spec.dart';
import '/view/users/retailer/orders/details/item_title.dart';
import 'manage_items_btn.dart';

class ItemInfo extends StatelessWidget {
  final OrderItem item;

  const ItemInfo({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _children(context, item),
        ),
      ),
    );
  }
}

List<Widget> _children(BuildContext context, OrderItem item) => [
      itemTitle(context, item.product.name),
      ItemSpec(title: 'القياس:', value: item.size),
      ItemSpec(title: 'العدد المطلوب:', value: '${item.requiredAmount}'),
      item.status == 'answered'
          ? ItemSpec(title: 'العدد المتوفر:', value: '${item.acceptableAmount}')
          : const SizedBox.shrink(),
      item.notes != ''
          ? ItemSpec(title: 'ملاحظات:', value: item.notes)
          : const SizedBox.shrink(),
      item.status == 'answered'
          ? ManageOrderItemBtn(id: item.id)
          : const SizedBox.shrink(),
      // : const SizedBox.shrink(),
    ];
