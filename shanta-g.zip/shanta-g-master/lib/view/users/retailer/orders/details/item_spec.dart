import 'package:flutter/material.dart';

class ItemSpec extends StatelessWidget {
  final String title;
  final String value;

  const ItemSpec({super.key, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: _textStyle(),
          ),
          const SizedBox(width: 15),
          Text(
            maxLines: 3,
            value,
            style: _textStyle(),
          ),
        ],
      ),
    );
  }
}

TextStyle _textStyle() => const TextStyle(
      color: Colors.black,
      overflow: TextOverflow.ellipsis,
      fontSize: 16,
    );
