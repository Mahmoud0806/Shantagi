import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/cubits.dart';

class ManageOrderItemBtn extends StatelessWidget {
  final int id;

  const ManageOrderItemBtn({required this.id, super.key});

  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<RetailerOrdersCubit>(context);
    return BlocBuilder<RetailerOrdersCubit, RetailerOrdersState>(
      builder: (context, state) {
        return state.status == RetailerOrdersStatus.loading &&
                id == 'cubit.orderItemId'
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _itemManageButton('رفض', Colors.red, () {
                    cubit.changeItemStatus(id, false).then((onValue) {
                      cubit.getAll();
                    Navigator.maybePop(context);
                    });
                    // cubit.orderItemId = id;
                    // cubit.changeOrderItem(id, 'cancelled');
                  }),
                  _itemManageButton('قبول', Colors.green, () {
                    cubit.changeItemStatus(id, true).then((onValue) {
                      cubit.getAll();
                    Navigator.maybePop(context);
                    });
                    // cubit.orderItemId = id;
                    // cubit.changeOrderItem(id, 'accepted');
                  }),
                ],
              );
      },
    );
  }

  InkWell _itemManageButton(String title, Color color, VoidCallback onPressed) {
    return InkWell(
      onTap: onPressed,
      child: Container(
        decoration: _boxDecoration(color),
        width: 50,
        height: 20,
        child: _buttonTitle(title),
      ),
    );
  }

  BoxDecoration _boxDecoration(Color color) {
    return BoxDecoration(
      borderRadius: BorderRadius.circular(3),
      color: color,
    );
  }

  Center _buttonTitle(String title) {
    return Center(
      child: Text(
        title,
        style:
            TextStyle(color: Colors.white, fontSize: 14, fontFamily: "Sukar"),
      ),
    );
  }
}
