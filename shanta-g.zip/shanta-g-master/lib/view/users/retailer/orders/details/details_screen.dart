import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';
import '/models/order/order.dart';
import '/models/order/order_item.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/users/retailer/orders/details/item_info.dart';

class RetailerOrderDetails extends StatefulWidget {
  final Order order;

  const RetailerOrderDetails({super.key, required this.order});

  @override
  State<RetailerOrderDetails> createState() => _RetailerOrderDetailsState();
}

class _RetailerOrderDetailsState extends State<RetailerOrderDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('تفاصيل الطلبية', context,
          showBack: true, foreground: AppColors.primary),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: ListView.builder(
          itemCount: widget.order.orderItems.length,
          shrinkWrap: true,
          itemBuilder: (context, int index) =>
              _orderItem(context, widget.order.orderItems[index]),
        ),
      ),
    );
  }

  SizedBox _orderItem(BuildContext context, OrderItem orderItem) {
    return SizedBox(
      height: MediaQuery.sizeOf(context).height * 0.35,
      child: Card(
        color: AppColors.background.withOpacity(0.9),
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _itemImage(orderItem.product.images.isNotEmpty
                  ? orderItem.product.images[0].attachment
                  : ''),
              ItemInfo(item: orderItem),
            ],
          ),
        ),
      ),
    );
  }

  SizedBox _itemImage(String url) {
    return SizedBox(
      height: 120,
      width: 120,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(5),
        child: Image.network(
          url,
          // 'order.orderItems![index].product!.images![0].attachment!',
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
