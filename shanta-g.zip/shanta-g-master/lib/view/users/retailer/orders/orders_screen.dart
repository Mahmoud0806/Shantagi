import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/retailer/orders/orders_cubit.dart';

import '/view/global_elements/app_bar/app_bar.dart';
import 'elements/orders_list.dart';

class RetailerOrdersScreen extends StatefulWidget {
  const RetailerOrdersScreen({super.key});

  @override
  State<RetailerOrdersScreen> createState() => _RetailerOrdersScreenState();
}

class _RetailerOrdersScreenState extends State<RetailerOrdersScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      await BlocProvider.of<RetailerOrdersCubit>(context).getAll();
      // print('${BlocProvider.of<RetailerOrdersCubit>(context).state.orders}');
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('الطلبات', context),
      body: retailerOrders(),
    );
  }
}
