import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/retailer/orders/orders_cubit.dart';
import '/models/order/order.dart';
import '/view/users/retailer/orders/details/details_screen.dart';
import 'elements/item_info.dart';
import 'elements/item_status.dart';

SizedBox retailerOrderItem(BuildContext context, Order order) => SizedBox(
      child: InkWell(
        onTap: () {
          var cubit = BlocProvider.of<RetailerOrdersCubit>(context);
          cubit.setActiveOrder(order.id);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => RetailerOrderDetails(order: order),
            ),
          );
        },
        child: Card(
          color: AppColors.background,
          elevation: 3,
          shape: _shape(),
          margin: const EdgeInsets.all(15.0),
          child: _itemElements(order),
        ),
      ),
    );

Widget _itemElements(Order order, {bool? showStatus = true}) => Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        children: _columnChildren(order, showStatus),
      ),
    );

List<Widget> _columnChildren(Order order, bool? showStatus) => [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: _rowChildren(order),
      ),
      const SizedBox(height: 50),
      showStatus != false
          ? itemStatus(status: order.status)
          : const SizedBox.shrink(),
    ];

List<Widget> _rowChildren(Order order) => [
      itemInfo(
        order.createdAt == ''
            ? ''
            : DateFormat('dd/MM/yyyy').format(
                DateTime.tryParse(order.createdAt) ?? DateTime(2000),
              ),
      ),
      itemInfo(order.number),
    ];

RoundedRectangleBorder _shape() {
  return RoundedRectangleBorder(
    side: const BorderSide(color: AppColors.primaryText),
    borderRadius: BorderRadius.circular(5),
  );
}
