import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/retailer/orders/orders_cubit.dart';
import '/view/users/retailer/orders/elements/order_item.dart';

Widget retailerOrders() =>
    BlocBuilder<RetailerOrdersCubit, RetailerOrdersState>(
      builder: (context, state) {
        return state.status == RetailerOrdersStatus.loading
            ? const Center(
                child: CircularProgressIndicator(),
              )
            : state.orders.isEmpty
                ? const Center(
                    child: Text('لا يوجد طلبات بعد'),
                  )
                : ListView.builder(
                    itemCount: state.orders.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) => retailerOrderItem(
                      context,
                      state.orders[index],
                    ),
                  );
      },
    );
