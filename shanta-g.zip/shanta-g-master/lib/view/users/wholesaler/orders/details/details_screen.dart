import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/cubits.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import 'item_info.dart';
import 'submit_order_btn.dart';

class WholesalerOrderDetails extends StatefulWidget {
  const WholesalerOrderDetails({super.key});

  @override
  State<WholesalerOrderDetails> createState() => _WholesalerOrderDetailsState();
}

class _WholesalerOrderDetailsState extends State<WholesalerOrderDetails> {
  @override
  Widget build(BuildContext context) {
    var cubit = BlocProvider.of<WholesalerOrdersCubit>(context);
    return Scaffold(
      appBar: customAppBar('تفاصيل الطلبية', context,
          showBack: true, foreground: AppColors.primary),
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                shrinkWrap: true,
                itemBuilder: (context, int index) => _orderItem(context, index),
                itemCount: cubit.state.order.orderItems.length,
              ),
            ),
            cubit.state.order.status == 'pending'
                ? wholesalerSubmitOrder(context)
                : const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }

  SizedBox _orderItem(BuildContext context, int index) {
    return SizedBox(
      // height: MediaQuery.sizeOf(context).height * 0.35,
      child: Card(
        color: AppColors.secondarySec.withOpacity(0.09),
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _itemImage(index),
              WholesalerItemInfo(index: index),
            ],
          ),
        ),
      ),
    );
  }

  Widget _itemImage(int index) {
    return BlocBuilder<WholesalerOrdersCubit, WholesalerOrdersState>(
      builder: (context, state) {
        print(
            'whole item image lin ++++ ${state.order.orderItems[index].product.images}');
        return Padding(
          padding: const EdgeInsets.all(15),
          child: SizedBox(
            height: 120,
            width: 120,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: Image.network(
                state.order.orderItems[index].product.images.isNotEmpty
                    ? state
                        .order.orderItems[index].product.images.first.attachment
                    : '',
                // 'order.orderItems![index].product!.images![0].attachment!',
                fit: BoxFit.cover,
              ),
            ),
          ),
        );
      },
    );
  }
}
