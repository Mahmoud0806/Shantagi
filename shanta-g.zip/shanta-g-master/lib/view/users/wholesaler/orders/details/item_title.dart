import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget wholesalerItemTitle(BuildContext context, title) => SizedBox(
    width:MediaQuery.sizeOf(context).width * 0.5 ,
      child: Text(
        title,
        overflow: TextOverflow.ellipsis,
        style: _textStyle(),
      ),
    );

TextStyle _textStyle() {
  return const TextStyle(
    color: AppColors.secondarySec,
    fontSize: 20,
  );
}
