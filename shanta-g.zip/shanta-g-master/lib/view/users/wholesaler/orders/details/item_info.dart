import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/cubits.dart';
import '/models/order/order_item.dart';
import 'item_spec.dart';
import 'item_title.dart';

class WholesalerItemInfo extends StatelessWidget {
  final int index;

  const WholesalerItemInfo({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    print('index :::::::::$index');
    return Expanded(
      child: BlocBuilder<WholesalerOrdersCubit, WholesalerOrdersState>(
        builder: (context, state) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _children(context, state.order.orderItems[index], index),
          );
        },
      ),
    );
  }
}

List<Widget> _children(BuildContext context, OrderItem item, int index) {
  return [
    wholesalerItemTitle(context, item.product.name),
    WholesalerItemSpec(title: 'القياس:', value: item.size),
    WholesalerItemSpec(
        title: 'العدد المطلوب:', value: '${item.requiredAmount}'),
    _acceptableAmount(item, index),
    item.notes != ''
        ? WholesalerItemSpec(title: 'ملاحظات:', value: item.notes)
        : const SizedBox.shrink(),

    // : const SizedBox.shrink(),
  ];
}

RenderObjectWidget _acceptableAmount(OrderItem item, int index) {
  return (item.size != '')
      ? Row(
          children: [
            const Text(
              'المتوفر:',
              style: TextStyle(
                fontSize: 16,
                fontFamily: 'Sukar',
              ),
            ),
            (item.acceptableAmount > 0)
                ? Text(
                    '${item.acceptableAmount}',
                    style: const TextStyle(
                      fontSize: 14,
                      fontFamily: 'Sukar',
                    ),
                  )
                : Padding(
                    padding: const EdgeInsets.all(10),
                    child: SizedBox(
                      width: 30,
                      height: 20,
                      child: BlocBuilder<WholesalerOrdersCubit,
                          WholesalerOrdersState>(
                        builder: (context, state) {
                          return TextFormField(
                            textAlign: TextAlign.center,
                            maxLength: 2,
                            controller: state.itemsFields[index],
                            cursorColor: AppColors.primary,
                            style: const TextStyle(color: AppColors.primary),
                            decoration: InputDecoration(
                              counterText: '',
                              contentPadding: EdgeInsets.zero,
                              focusedBorder: _focusBorder(),
                              enabledBorder: _outlineInputBorder(),
                              disabledBorder: _outlineInputBorder(),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
          ],
        )
      : const SizedBox.shrink();
}

OutlineInputBorder _focusBorder() => const OutlineInputBorder(
      borderSide: BorderSide(
        color: AppColors.primary,
        width: 1.5,
      ),
      borderRadius: BorderRadius.all(Radius.circular(3)),
    );

OutlineInputBorder _outlineInputBorder() => const OutlineInputBorder(
      borderSide: BorderSide(color: Colors.black),
      borderRadius: BorderRadius.all(
        Radius.circular(3),
      ),
    );
