import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/cubits.dart';
import '/view/users/wholesaler/orders/elements/orders_list.dart';
import '/view/global_elements/app_bar/app_bar.dart';

class WholesalerOrdersScreen extends StatefulWidget {
  const WholesalerOrdersScreen({super.key});

  @override
  State<WholesalerOrdersScreen> createState() => _WholesalerOrdersScreenState();
}

class _WholesalerOrdersScreenState extends State<WholesalerOrdersScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      await BlocProvider.of<WholesalerOrdersCubit>(context).getAll();
      print('${BlocProvider.of<WholesalerOrdersCubit>(context).state.orders}');
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('الطلبات', context),
      body: RefreshIndicator(
        onRefresh: BlocProvider.of<WholesalerOrdersCubit>(context).getAll,
        child: SizedBox(
          height: MediaQuery.sizeOf(context).height,
          child: wholesalerOrdersList(),
        ),
      ),
    );
  }
}
