import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/wholesaler/orders/orders_cubit.dart';
import '/view/global_elements/orders/order_item.dart';
import '/view/users/wholesaler/orders/details/details_screen.dart';

Widget wholesalerOrdersList() =>
    BlocBuilder<WholesalerOrdersCubit, WholesalerOrdersState>(
      builder: (context, state) {
        return state.status == WholesalerOrdersStatus.loading &&
                state.orders.isEmpty
            ? const Center(child: CircularProgressIndicator())
            : state.orders.isEmpty
                ? const Center(
                    child: Text('لا يوجد طلبات بعد'),
                  )
                : ListView.builder(
                    itemCount: state.orders.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index) =>
                        orderItem(state.orders[index], () {
                      var cubit =
                          BlocProvider.of<WholesalerOrdersCubit>(context);
                      cubit.setActive(index);
                      print(
                          'obj set : ${BlocProvider.of<WholesalerOrdersCubit>(context).state.order.orderItems.first.product.images}');
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const WholesalerOrderDetails(),
                        ),
                      );
                    }),
                  );
      },
    );
