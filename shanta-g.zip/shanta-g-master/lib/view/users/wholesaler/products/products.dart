import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/cubits.dart';
import '/logic/cubits/filters/filters_cubit.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/users/wholesaler/products/elements/products_view.dart';

class WholesalerProductsScreen extends StatefulWidget {
  const WholesalerProductsScreen({super.key});

  @override
  State<WholesalerProductsScreen> createState() =>
      _WholesalerProductsScreenState();
}

class _WholesalerProductsScreenState extends State<WholesalerProductsScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      var catCubit = BlocProvider.of<CategoriesCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      await BlocProvider.of<WholesalerProductsCubit>(context).getAll();
      await catCubit.getAll();
      filterCubit.fillCats(catCubit.state.categories);
      _scrollController.addListener(_loadMoreData);
      print(
          '${BlocProvider.of<WholesalerProductsCubit>(context).state.products}');
    });
    super.initState();
  }

  final _scrollController = ScrollController();

  void _loadMoreData() {
    if (_scrollController.position.pixels >=
        _scrollController.position.maxScrollExtent) {
      var cubit = BlocProvider.of<ClientProductsCubit>(context);
      var filterCubit = BlocProvider.of<FiltersCubit>(context);
      cubit.getAll(params: filterCubit.setSelectedParams(), saveOld: true, savePage: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('المنتجات', context),
      body: wholesalerProductsView(context),
    );
  }
}
