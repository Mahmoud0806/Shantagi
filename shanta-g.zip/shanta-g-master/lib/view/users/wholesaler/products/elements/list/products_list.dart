import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shantagi/view/users/wholesaler/products/elements/grid/details/wholesaler_product_details.dart';

import '/logic/cubits/wholesaler/products/products_cubit.dart';
import 'elements/product_item.dart';

Widget wholesalerProductsList() => Expanded(
      child: BlocBuilder<WholesalerProductsCubit, WholesalerProductsState>(
        builder: (context, state) {
          return state.products.isEmpty
              ? const Center(
                  child: Text('لا يوجد منتجات بعد'),
                )
              : PageView.builder(
                  itemCount: state.products.length,
                  pageSnapping: true,
                  scrollDirection: Axis.vertical,
                  itemBuilder: (context, pagePosition) {
                    // controller.createMyImages(controller.products[pagePosition].images!);
                    return productItem(context, state.products[pagePosition],
                        onTap: () {
                      var cubit =
                          BlocProvider.of<WholesalerProductsCubit>(context);
                      cubit.setActive(pagePosition);
                      print('pressed');
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => WholesalerProductDetails(
                            product: state.products[pagePosition],
                          ),
                        ),
                      );
                    });
                  },
                );
        },
      ),
    );
