import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/users/client/products/elements/grid/elements/item_image.dart';

import '../../../../../../global_elements/products/grid/elements/item_hold.dart';
import '/logic/cubits/cubits.dart';

Widget wholesalerGridItem(
    BuildContext context, bool isHold, int index, VoidCallback onTap) {
  return Padding(
    padding: const EdgeInsets.all(15),
    child: Stack(
      children: _children(context, isHold, index, onTap),
    ),
  );
}

List<Widget> _children(
    BuildContext context, bool isHold, index, VoidCallback onTap) {
  var cubit = BlocProvider.of<WholesalerProductsCubit>(context);
  return [
    InkWell(
      borderRadius: BorderRadius.circular(15),
      onTap: onTap,
      child:
          CashedImage(url: cubit.state.products[index].images.first.attachment),
    ),
    itemHold(cubit.state.products[index].hold, () {
      cubit.changeHold(cubit.state.products[index].id);
    }),
  ];
}
