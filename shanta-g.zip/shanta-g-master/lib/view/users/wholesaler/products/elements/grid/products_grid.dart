import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/users/wholesaler/products/elements/grid/details/wholesaler_product_details.dart';
import '/view/users/wholesaler/products/elements/grid/elements/grid_item.dart';
import '/logic/cubits/wholesaler/products/products_cubit.dart';

Widget wholesalerProductsGrid(BuildContext context) {
  var cubit = BlocProvider.of<WholesalerProductsCubit>(context);
  return Expanded(
      child: RefreshIndicator(
        onRefresh: () => cubit.getAll(),
        child: BlocBuilder<WholesalerProductsCubit, WholesalerProductsState>(
          builder: (context, state) {
            return state.products.isEmpty
                ? const Center(
                    child: Text('wholeلا يوجد منتجات بعد'),
                  )
                : GridView.builder(
                    shrinkWrap: true,
                    itemCount: state.products.length,
                    gridDelegate: _gridDelegate(),
                    itemBuilder: (context, index) => wholesalerGridItem(
                      context,
                      state.product.hold,
                      index,
                      () {
                        var cubit =
                            BlocProvider.of<WholesalerProductsCubit>(context);
                        cubit.setActive(index);
                        print('pressed');
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => WholesalerProductDetails(
                              product: state.products[index],
                            ),
                          ),
                        );
                      },
                    ),
                  );
          },
        ),
      ),
    );
}

SliverGridDelegateWithFixedCrossAxisCount _gridDelegate() =>
    const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2,
    );
