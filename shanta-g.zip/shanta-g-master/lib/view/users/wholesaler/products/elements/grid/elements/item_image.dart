// import 'package:fast_cached_network_image/fast_cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:path_provider/path_provider.dart';
//
// Future _initCashedImage() async {
//   String storageLocation = (await getApplicationDocumentsDirectory()).path;
//   await FastCachedImageConfig.init(
//     subDir: storageLocation,
//     clearCacheAfter: const Duration(days: 15),
//   );
// }
// class CachedImage extends StatefulWidget {
//   final String url;
//   const CachedImage({super.key, required this.url});
//
//   @override
//   State<CachedImage> createState() => _CachedImageState();
// }
//
// class _CachedImageState extends State<CachedImage> {
//   @override
//   Widget build(BuildContext context) {
//     return const Placeholder();
//   }
// }
//
//
// Widget _cachedImage(String url) => SizedBox(
//       child: FastCachedImage(
//         url: url,
//         errorBuilder: _errorBuilder,
//         loadingBuilder: _loadingBuilder,
//       ),
//     );
//
// Widget _errorBuilder(context, exception, stacktrace) {
//   return Text(stacktrace.toString());
// }
//
// Widget _loadingBuilder(context, progress) {
//   return SizedBox(
//     child: Stack(
//       alignment: Alignment.center,
//       children: [
//         if (progress.isDownloading && progress.totalBytes != null)
//           indicatorText(progress),
//         _loadingIndicator(progress),
//       ],
//     ),
//   );
// }
//
// Text indicatorText(progress) {
//   return Text(
//           '${progress.downloadedBytes ~/ 1024} / ${progress.totalBytes! ~/ 1024} kb',
//           style: const TextStyle(color: Colors.red),
//         );
// }
//
// SizedBox _loadingIndicator(progress) {
//   return SizedBox(
//     width: 120,
//     height: 120,
//     child: CircularProgressIndicator(
//         color: Colors.red, value: progress.progressPercentage.value),
//   );
// }
