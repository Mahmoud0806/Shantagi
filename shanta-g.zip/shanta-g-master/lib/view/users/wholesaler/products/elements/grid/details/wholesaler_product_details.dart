import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/data/constant/app_colors.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';

import '/models/product/product.dart';
import '/view/global_elements/app_bar/app_bar.dart';
import '/view/global_elements/products/details/product_details.dart';

class WholesalerProductDetails extends StatefulWidget {
  final Product product;

  const WholesalerProductDetails({super.key, required this.product});

  @override
  State<WholesalerProductDetails> createState() => _WholesalerProductDetailsState();
}

class _WholesalerProductDetailsState extends State<WholesalerProductDetails> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('تفاصيل المنتج', context, showBack: true, foreground: AppColors.primary),
      body: productDetails(context, widget.product),
    );
  }
}
