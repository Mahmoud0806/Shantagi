import 'package:flutter/material.dart';
import '/models/product/product.dart';
import '/models/product/product_image.dart';

import '../../../../../../admin/home/screens/orders/elements/item_spec.dart';
import '../../../../../../global_elements/products/list/elements/item_title.dart';
import 'carousel_indicator.dart';
import 'carousel_slider.dart';

Widget productItem(BuildContext context, Product product, {onTap}) => InkWell(
  onTap: onTap,
  child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 15),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: _children(context, product),
          ),
        ),
      ),
);

List<Widget> _children(BuildContext context, Product product) => [
      const SizedBox(height: 15),
      _itemImage(context, product.images),
      itemTitle(product.name),
      itemSpec('الوزن:', product.weight.toString()),
      itemSpec('عيار:', product.karat),
      // itemSpec('الوصف:', product.description),
      itemSpec('القياسات المتوفرة:', product.sizes.join(', ')),
      // itemSpec('الملاحظات: ', product.notes),
    ];

Stack _itemImage(BuildContext context, List<ProductImage> images) {
  return Stack(
    alignment: Alignment.bottomCenter,
    children: [
      carouselSlider(context, images),
      carouselIndicator(1, 0),
    ],
  );
}
