import 'package:flutter/material.dart';


class DealerEmail extends StatelessWidget {
  final String data;
  const DealerEmail({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: _email(),
    );
  }
  Widget _email() => Row(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      const Icon(Icons.email),
      const SizedBox(width: 10),
      const Text(
        'email',
        style: TextStyle(
          color: Colors.blue,
          fontSize: 16,
        ),
      ),
      const SizedBox(width: 10),
      Text(
        data,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 16,
        ),
      )
    ],
  );

}
