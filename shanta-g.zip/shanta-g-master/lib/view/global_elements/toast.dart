import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '/data/constant/app_colors.dart';

// void showToast({required String text, required ToastStates state, ToastGravity? gravity}) =>
//     Fluttertoast.showToast(
//         msg: text,
//         toastLength: Toast.LENGTH_LONG,
//         gravity: gravity ?? ToastGravity.BOTTOM,
//         timeInSecForIosWeb: 3,
//         backgroundColor: colorToastColor(state),
//         textColor: Colors.black,
//         fontSize: 16.0);
FToast fToast = FToast();

void showToast(
        {required String text,
        required ToastStates state,
        ToastGravity? gravity}) =>
    fToast.showToast(
        gravity: gravity ?? ToastGravity.BOTTOM,
        child: buildToastWidget(state, text));

enum ToastStates { success, error, warning }

Color colorToastColor(ToastStates state) {
  Color color;

  switch (state) {
    case ToastStates.success:
      color = Colors.green;
      break;
    case ToastStates.error:
      color = Colors.red;
      break;
    case ToastStates.warning:
      color = Colors.yellow;
      break;
  }
  return color;
}

IconData toastIcon(ToastStates state) {
  IconData icon;
  switch (state) {
    case ToastStates.success:
      icon = Icons.check_circle_outline;
      break;
    case ToastStates.error:
      icon = Icons.warning_amber_outlined;
      break;
    case ToastStates.warning:
      icon = Icons.warning_amber_outlined;
      break;
  }
  return icon;
}

Widget buildToastWidget(ToastStates state, String text) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
    // decoration: BoxDecoration(
    //   borderRadius: BorderRadius.circular(25.0),
    //   color: AppColors.primaryColor,
    // ),
    color: AppColors.primary,
    child: Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          toastIcon(state),
          color: colorToastColor(state),
        ),
        const SizedBox(width: 12.0),
        SizedBox(
          width: 220,
          child: Text(
            text,
            maxLines: 2,
            style: TextStyle(
              fontSize: 15.0,
              color: colorToastColor(state),
            ),
          ),
        ),
      ],
    ),
  );
}
