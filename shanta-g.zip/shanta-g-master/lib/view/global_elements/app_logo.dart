import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

Widget appLogo({EdgeInsets? padding}) => Padding(
  padding: padding ?? const EdgeInsets.symmetric(horizontal: 80.0, vertical: 110),
  child: SizedBox(
        height: 200,
        width: 200,
        child: SvgPicture.asset(
          'assets/icons/global/logo.svg',
          fit: BoxFit.contain,
        ),
      ),
);
