import 'package:carousel_indicator/carousel_indicator.dart';
import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget carouselIndicator(int imagesLen, int currentIndex) => Padding(
      padding: const EdgeInsets.only(bottom: 15.0),
      child: CarouselIndicator(
        count: imagesLen < 1 ? 1 : imagesLen,
        index: currentIndex < 0 ? 0 : currentIndex,
        color: Colors.grey,
        activeColor: AppColors.secondarySec,
      ),
    );
