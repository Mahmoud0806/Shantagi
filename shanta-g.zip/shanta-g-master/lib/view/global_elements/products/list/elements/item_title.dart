import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

Padding itemTitle(String data) => Padding(
  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 15),
  child: SizedBox(
        child: Text(
          data,
          style: _style(),
        ),
      ),
);

TextStyle _style() => TextStyle(
      fontSize: 22,
      height: 1,
      fontWeight: FontWeight.w600,
      color: AppColors.primary.withOpacity(0.87),
    );
