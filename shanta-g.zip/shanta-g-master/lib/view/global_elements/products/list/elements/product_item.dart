import 'package:flutter/material.dart';

import 'carousel_indicator.dart';
import 'carousel_slider.dart';
import 'item_specs.dart';
import 'item_title.dart';

Widget productItem(BuildContext context, product) => Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _children(context),
        ),
      ),
    );

List<Widget> _children(BuildContext context) => [
      const SizedBox(height: 15),
      _itemImage(context),
      itemTitle('data'),
      itemSpec('الوزن:', 'value'),
      itemSpec('عيار:', 'value'),
      itemSpec('الوصف:', 'value'),
      itemSpec('القياسات المتوفرة:', 'value.join(\', \')'),
    ];

Stack _itemImage(BuildContext context) {
  return Stack(
    alignment: Alignment.bottomCenter,
    children: [
      carouselSlider(context, []),
      carouselIndicator(1, 0),
    ],
  );
}
