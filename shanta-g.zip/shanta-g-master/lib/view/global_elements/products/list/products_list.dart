import 'package:flutter/material.dart';
import '/models/product/product.dart';

import 'elements/product_item.dart';

Widget productsList(List<Product> products) => Expanded(
      child: PageView.builder(
        itemCount: products.length,
        pageSnapping: true,
        scrollDirection: Axis.vertical,
        itemBuilder: (context, pagePosition) {
          // controller.createMyImages(controller.products[pagePosition].images!);
          return productItem(context, products[pagePosition]);
        },
      ),
    );
