import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/logic/cubits/global/toggle_view/toggle_cubit.dart';
import '/view/global_elements/products/elements/header/view_button.dart';

Widget productsViewHeader(BuildContext context) => SizedBox(
      child: BlocBuilder<ToggleCubit, ToggleState>(
        builder: (context, state) {
          return Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: _children(context, state),
          );
        },
      ),
    );

List<Widget> _children(BuildContext context, ToggleState state) => [
      viewButton(
        'assets/icons/global/list-view.svg',
        state.isListView ? Colors.black : Colors.grey,
        () => _onPressed(context),
      ),
      viewButton(
        'assets/icons/global/grid-view.svg',
        state.isListView ? Colors.grey : Colors.black,
        () => _onPressed(context),
      ),
    ];

_onPressed(BuildContext context) {
  var toggleCubit = BlocProvider.of<ToggleCubit>(context);
  toggleCubit.toggleView();
}
