import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

Widget viewButton(String imageLink, Color color, VoidCallback onPressed) =>
    SizedBox(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          // minimumSize: Size(20, 20),
          // fixedSize: Size(20, 20),
          padding: EdgeInsets.zero,
          fixedSize: const Size(30, 40),
          maximumSize: const Size(30, 40),
          minimumSize: const Size(30, 40),
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          surfaceTintColor: Colors.transparent,
        ),
        onPressed: onPressed,
        child: _buttonIcon(imageLink, color),
      ),
    );

Widget _buttonIcon(String imageLink, Color color) => SvgPicture.asset(
      height: 20,
      width: 8,
      imageLink,
      fit: BoxFit.cover,
      color: color,
    );
