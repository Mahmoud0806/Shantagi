import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/view/global_elements/search_bar.dart';

import '/logic/cubits/global/toggle_view/toggle_cubit.dart';
import '/view/global_elements/products/elements/header/header.dart';
import '/view/global_elements/products/grid/products_grid.dart';
import '/view/global_elements/products/list/products_list.dart';

SizedBox productsView(BuildContext context, products) => SizedBox(
      child: Column(
        children: _children(context, products),
      ),
    );

List<Widget> _children(BuildContext context, products) {
  var controller = TextEditingController();
  return [
      productsViewHeader(context),
      BlocBuilder<ToggleCubit, ToggleState>(
        builder: (context, state) {
          return state.isListView ? productsGrid(products) : productsList(products);
        },
      ),
    ];
}
