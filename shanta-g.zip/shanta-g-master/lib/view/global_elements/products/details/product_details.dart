import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/view/users/client/products/details/add_form.dart';

import '/models/product/product.dart';
import '/models/product/product_image.dart';
import '/view/global_elements/products/details/elements/add_to_cart_btn.dart';
import '/view/global_elements/products/list/elements/carousel_indicator.dart';
import '/view/global_elements/products/list/elements/carousel_slider.dart';
import 'elements/product_spec_item.dart';
import 'elements/product_title.dart';

Widget productDetails(BuildContext context, Product product,
        {bool? showCart}) =>
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _children(context, product, showCart: showCart),
        ),
      ),
    );

List<Widget> _children(BuildContext context, Product product,
    {bool? showCart}) {
  var cubit = BlocProvider.of<ClientCartCubit>(context);

  return [
    const SizedBox(height: 15),
    _itemImage(context, product.images),
    productTitle(product.name),
    productSpecItem(context, 'الوزن:', '${product.weight}'),
    productSpecItem(context, 'عيار:', product.karat),
    productSpecItem(context, 'الوصف:', product.description),
    productSpecItem(context, 'القياسات المتوفرة:', product.sizes.join(', ')),
    if(showCart != null)
    requirementForm(context, product.sizes),
    if(showCart != null)
         addToCartBtn(context, product, [],cubit.sizesControllers )

  ];
}

Stack _itemImage(BuildContext context, List<ProductImage> images) {
  print('image link :: :: ${images.isNotEmpty ? images.first.attachment : ''}');
  return Stack(
    alignment: Alignment.bottomCenter,
    children: [
      carouselSlider(context, images),
      carouselIndicator(images.length, 0),
    ],
  );
}
