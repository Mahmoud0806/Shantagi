import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';
import '/view/global_elements/widgets/styles.dart';

Padding itemNotes(state) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 25),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(
            'ملاحظات:',
            style: Styles.label1.copyWith(fontWeight: FontWeight.bold),
          ),
        ),
        const SizedBox(
          width: 15,
        ),
        Expanded(
          child: TextFormField(
            maxLines: 3,
            controller: state.notesController,
            // validator: (_) =>
            //     controller
            //         .numberValidator(),
            cursorColor: AppColors.primary,
            style: const TextStyle(color: AppColors.primary),
            decoration: const InputDecoration(
              counterText: '',
              contentPadding: EdgeInsets.symmetric(horizontal: 5),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: AppColors.primary,
                  width: 1.5,
                ),
                borderRadius: BorderRadius.all(
                  Radius.circular(3),
                ),
              ),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.black),
                borderRadius: BorderRadius.all(
                  Radius.circular(3),
                ),
              ),
            ),
          ),
        ),
      ],
    ),
  );
}
