import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

Padding productSpecItem(BuildContext context, String spec, String value) =>
    Padding(
      padding: const EdgeInsets.symmetric(vertical: 15),
      child: Row(
        children: [
          _text(
            spec,
            style: _specStyle().copyWith(fontWeight: FontWeight.w700),

          ),
          const SizedBox(width: 15),
          _text(
            value,
            style: _specStyle().copyWith(height: 1.5),
            width: MediaQuery.sizeOf(context).width * .5,
          ),
        ],
      ),
    );

Widget _text(String value, {TextStyle? style, double? width}) {
  return SizedBox(
    width: width,
    child: Text(
      value,
      maxLines: 3,
      style: style ?? _specStyle(),
    ),
  );
}

TextStyle _specStyle() => TextStyle(
      fontSize: 18,
      height: 1,
      // fontWeight: FontWeight.w900,
      overflow: TextOverflow.ellipsis,
      color: AppColors.primary.withOpacity(0.87),
    );
