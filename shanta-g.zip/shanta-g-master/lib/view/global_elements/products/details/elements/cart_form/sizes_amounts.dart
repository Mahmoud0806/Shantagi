import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';
import '/view/global_elements/widgets/styles.dart';

Expanded sizesAmountList(state, pagePosition) {
  return Expanded(
    child: ListView.builder(
      itemBuilder: (context, index) {
        if (state.sizesControllers.length <
            state.products[pagePosition].sizes.length) {}
        return Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                width: 30,
                height: 20,
                decoration: BoxDecoration(
                  border: Border.all(),
                  borderRadius: BorderRadius.circular(3),
                ),
                child: Center(
                    child: Text(
                  state.products[pagePosition].sizes[index],
                  style: Styles.label2.copyWith(height: 0),
                )),
              ),
              SizedBox(
                width: 30,
                height: 20,
                child: TextFormField(
                  textAlign: TextAlign.center,
                  maxLength: 2,
                  controller: state.sizesControllers.isNotEmpty
                      ? state.sizesControllers[index]
                      : null,
                  // validator: (_) => controller.numbersOnlyValidator(),
                  cursorColor: AppColors.primary,
                  style: const TextStyle(color: AppColors.primary),
                  decoration: const InputDecoration(
                    counterText: '',
                    contentPadding: EdgeInsets.zero,
                    focusedBorder: OutlineInputBorder(
                      borderSide: BorderSide(
                        color: AppColors.primary,
                        width: 1.5,
                      ),
                      borderRadius: BorderRadius.all(
                        Radius.circular(3),
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.black),
                      borderRadius: BorderRadius.all(
                        Radius.circular(3),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
      itemCount: state.products[pagePosition].sizes.length,
    ),
  );
}
