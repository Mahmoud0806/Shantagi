import 'package:flutter/material.dart';

Widget manageProduct() => SizedBox(
      child: Row(
        children: _children(),
      ),
    );

List<Widget> _children() => [
      _button(Icons.add, () {}),
      _button(Icons.edit_outlined, () {}),
      _button(Icons.delete_outline, () {}),
    ];

IconButton _button(IconData icon, VoidCallback onPressed) => IconButton(
      onPressed: onPressed,
      icon: Icon(icon),
    );
