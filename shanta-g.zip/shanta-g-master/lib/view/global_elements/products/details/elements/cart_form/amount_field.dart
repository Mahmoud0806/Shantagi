import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

TextFormField amountField(state) {
  return TextFormField(
    textAlign: TextAlign.center,
    maxLength: 2,
    controller: state.sizeController,
    // validator: (_) =>
    //     clientsProductsCubit
    //         .numberValidator(),
    cursorColor: AppColors.primary,
    style: const TextStyle(color: AppColors.primary),
    decoration: const InputDecoration(
      counterText: '',
      errorStyle: TextStyle(fontSize: 12),
      contentPadding: EdgeInsets.symmetric(vertical: 5),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: AppColors.primary,
          width: 1.5,
        ),
        borderRadius: BorderRadius.all(
          Radius.circular(3),
        ),
      ),
      errorBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.red),
        borderRadius: BorderRadius.all(
          Radius.circular(3),
        ),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.transparent),
      ),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: Colors.black),
        borderRadius: BorderRadius.all(
          Radius.circular(3),
        ),
      ),
    ),
  );
}
