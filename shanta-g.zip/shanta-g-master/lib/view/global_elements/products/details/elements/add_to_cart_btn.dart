import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '/view/global_elements/toast.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/client/cart/client_cart_cubit.dart';
import '/models/cart/cart_item.dart';
import '/models/product/product.dart';
import '/view/global_elements/widgets/styles.dart';

Widget addToCartBtn(
  BuildContext context,
  Product product,
  List<String> sizes,
  List amounts,
) =>
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 30),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          fixedSize: Size(
            MediaQuery.sizeOf(context).width * .85,
            MediaQuery.sizeOf(context).height * .06,
          ),
        ),
        onPressed: () {
          // List<String> newAmounts = [];
          bool hasAmounts = false;
          for (int i = 0; i < amounts.length; i++) {
            // newAmounts.add(amounts[i].text);
            if (amounts[i].text != '') {
              hasAmounts = true;
              print(amounts[i].text);
              BlocProvider.of<ClientCartCubit>(context).addToCart(
                CartItem.fromProduct(
                  product,
                  amounts[i].text,
                  product.sizes[i],
                  'notes',
                ),
              );
              amounts[i].clear();
            }
          }

          if (hasAmounts) {
            showToast(
                text: 'تم الاضافة للسلة',
                state: ToastStates.success,
                gravity: ToastGravity.TOP);
          } else {
            showToast(
                text: 'الرجاء إضافة قياسات',
                state: ToastStates.warning,
                gravity: ToastGravity.TOP);
          }
        },
        child: _btnTitle(),
      ),
    );

Text _btnTitle() {
  return Text(
    'إضافة إلى السلة',
    style: Styles.buttonText.copyWith(color: AppColors.background),
  );
}
