import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';
import '/view/global_elements/widgets/styles.dart';
import 'amount_field.dart';
import 'item_notes.dart';
import 'sizes_amounts.dart';

Widget addToCartForm(BuildContext context, Key formKey, state, pagePosition) =>
    Center(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: GestureDetector(
          onTap: () {
            showDialog(
                context: context,
                builder: (BuildContext context) {
                  return alertDialog(formKey, state, pagePosition, context);
                });
          },
          child: Padding(
            padding: const EdgeInsets.only(top: 10),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.8,
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(5),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 10,
                ),
                child: Center(
                  child: Text(
                    'إضافة إلى السلة',
                    style:
                        Styles.buttonText.copyWith(color: AppColors.background),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );

AlertDialog alertDialog(
    Key formKey, state, pagePosition, BuildContext context) {
  return AlertDialog(
    title: Text('التصنيفات',
        style: Styles.label0.copyWith(color: AppColors.primaryText)),
    content: Form(
      key: formKey,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                (state.products[pagePosition].sizes.isNotEmpty)
                    ? Center(
                        child: SizedBox(
                          height: 160,
                          width: MediaQuery.of(context).size.width * 0.6,
                          // decoration: BoxDecoration(
                          //   border: Border.all(width: 1),
                          //   borderRadius: BorderRadius.circular(5),
                          // ),
                          // color: Colors.green,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    Text(
                                      'القياسات المتوفرة',
                                      style:
                                          Styles.label1.copyWith(height: 1.5),
                                    ),
                                    Text(
                                      'العدد',
                                      style:
                                          Styles.label1.copyWith(height: 1.5),
                                    ),
                                  ],
                                ),
                              ),
                              sizesAmountList(state, pagePosition),
                              const Padding(
                                padding: EdgeInsets.all(5),
                                child: Text(
                                  'الرجاء إدخال أرقام فقط',
                                  style: TextStyle(
                                    fontFamily: 'Sukar',
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(
                          children: [
                            Text(
                              'العدد المطلوب:',
                              style: Styles.label1
                                  .copyWith(fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(
                              width: 15,
                            ),
                            SizedBox(
                              width: 70,
                              height: 45,
                              child: amountField(state),
                            ),
                          ],
                        ),
                      ),
                itemNotes(state),
              ],
            ),
          ),
          GestureDetector(
            onTap: () async {
              print(state.sizesControllers.length);
            },
            child: Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.8,
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  border: Border.all(
                    color: Colors.white,
                  ),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    vertical: 10,
                  ),
                  child: Center(
                    child: Text(
                      'حفظ',
                      style: Styles.buttonText,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}
