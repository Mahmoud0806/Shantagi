import 'package:flutter/material.dart';

import '/models/product/product.dart';

Widget productsGrid(List<Product> products) => Expanded(
      child: GridView.builder(
        shrinkWrap: true,
        itemCount: products.length,
        gridDelegate: _gridDelegate(),
        itemBuilder: (context, index) => Card(),
      ),
    );

SliverGridDelegateWithFixedCrossAxisCount _gridDelegate() =>
    const SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: 2,
    );
