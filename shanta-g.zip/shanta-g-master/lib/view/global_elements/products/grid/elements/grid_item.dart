import 'package:flutter/material.dart';

import 'item_hold.dart';
import 'item_image.dart';

Widget gridItem(BuildContext context, bool isHold, VoidCallback onTap) =>
    SizedBox(
      child: Stack(
        children: _children(context, isHold, onTap),
      ),
    );

List<Widget> _children(BuildContext context, bool isHold, VoidCallback onTap) =>
    [
      _gestureDetector(context, onTap),
      cashedImage('url'),
      itemHold(isHold, (){}),
    ];

GestureDetector _gestureDetector(BuildContext context, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
  );
}
