import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import '/data/constant/app_colors.dart';

Widget itemHold(bool isHold, VoidCallback onTap) => Padding(
      padding: const EdgeInsets.all(5),
      child: IconButton(
        onPressed: onTap,
        icon: Icon(
          _icon(isHold),
          color: AppColors.secondarySec,
        ),
      ),
    );

IconData _icon(bool isHold) => isHold ? Icons.visibility_off : Icons.visibility;
