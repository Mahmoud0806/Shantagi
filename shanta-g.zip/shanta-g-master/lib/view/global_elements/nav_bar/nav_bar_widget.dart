import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

import '/data/constant/app_colors.dart';
import '/logic/cubits/home/home_cubit.dart';

Widget navBar(BuildContext context) => Padding(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 18),
      child: BlocBuilder<HomeCubit, HomeState>(
        builder: (context, state) {
          return GNav(
            haptic: true,
            tabBorderRadius: 15,
            tabShadow: _tabShadow(),
            curve: Curves.easeOutExpo,
            duration: const Duration(milliseconds: 900),
            gap: 8,
            color: AppColors.primary.withOpacity(0.8),
            activeColor: AppColors.primary,
            iconSize: 34,
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
            tabs: _barIcons(),
            selectedIndex: state.index,
            onTabChange: (index) {
              var homeCubit = BlocProvider.of<HomeCubit>(context);
              homeCubit.changeIndex(index);
            },
          );
        },
      ),
    );

List<BoxShadow> _tabShadow() =>
    [BoxShadow(color: Colors.white.withOpacity(0), blurRadius: 8)];

List<GButton> _barIcons() => const [
      GButton(
        icon: Icons.person_2_outlined,
        text: 'الحساب',
      ),
      GButton(
        icon: Icons.home_filled,
        text: 'الرئيسية',
      ),
      GButton(
        icon: Icons.shopping_bag_outlined,
        text: 'الطلبات',
      ),
    ];
