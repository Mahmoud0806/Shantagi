import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/profile/profile_cubit.dart';
import '/view/global_elements/profile/elements/user_info.dart';
import '/view/global_elements/app_bar/app_bar.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      print('start');
      await BlocProvider.of<ProfileCubit>(context).get();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: customAppBar('الحساب الشخصي', context),
      body: BlocBuilder<ProfileCubit, ProfileState>(
        builder: (context, state) {
          return userInfo(context, state.profile);
        },
      ),
    );
  }
}
