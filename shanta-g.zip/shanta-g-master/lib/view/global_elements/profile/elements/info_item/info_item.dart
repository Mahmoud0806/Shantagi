import 'package:flutter/material.dart';

import 'item_icon.dart';
import 'item_text.dart';

Widget infoItem(
        BuildContext context, IconData icon, String title, String value) =>
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 6),
      child: SizedBox(
        child: Row(
          children: _children(context, icon, title, value),
        ),
      ),
    );

List<Widget> _children(
        BuildContext context, IconData icon, String title, String value) =>
    [
      itemIcon(icon),
      itemTitle(context, title),
      itemText(context, value),
    ];
