import 'package:flutter/material.dart';

Widget itemText(BuildContext context, String data) => Padding(
  padding: const EdgeInsets.only(left: 8.0),
  child: SizedBox(
    width: MediaQuery.sizeOf(context).width * 0.5,
        child: Text(
          data,
          maxLines: 5,
          style: _style(),
        ),
      ),
);
Widget itemTitle(BuildContext context, String data) => Padding(
  padding: const EdgeInsets.only(left: 8.0),
  child: SizedBox(
    width: MediaQuery.sizeOf(context).width * 0.25,
        child: Text(
          data,
          style: _style(),
        ),
      ),
);


TextStyle _style() {
  return const TextStyle(
    overflow: TextOverflow.ellipsis,
    fontSize: 22,
    color: Colors.black,
  );
}
