import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Padding itemIcon(IconData icon) => Padding(
  padding: const EdgeInsets.all(4.0),
  child: SizedBox(
        child: Icon(
          icon,
          color: AppColors.secondarySec,
        ),
      ),
);
