import 'package:flutter/material.dart';
import '/models/profile.dart';
import 'log_out_btn.dart';
import '../../app_logo.dart';
import 'info_item/info_item.dart';
import 'user_name.dart';

SizedBox userInfo(BuildContext context, Profile profile) => SizedBox(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: _children(context, profile),
        ),
      ),
    );

List<Widget> _children(BuildContext context, Profile profile) => [
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          appLogo(padding: const EdgeInsets.symmetric(horizontal: 80.0, vertical: 40)),
        ],
      ),
      userName(profile.name),
      infoItem(
          context, Icons.location_on_outlined, 'العنوان: ', profile.address),
      infoItem(context, Icons.phone_outlined, 'رقم الهاتف: ', profile.phone),
      logoutBtn(context),
    ];
