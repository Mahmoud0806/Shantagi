import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

Widget userName(String data) => Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: SizedBox(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              data,
              style: _style(),
            ),
          ],
        ),
      ),
    );

TextStyle _style() => const TextStyle(
      fontSize: 26,
      fontWeight: FontWeight.bold,
      color: AppColors.primary,
    );
