import 'package:flutter/material.dart';

import '/data/constant/storage/local_storage_services.dart';
import '/data/constant/storage/secure_storage.dart';
import '/view/auth/login/login.dart';

Widget logoutBtn(BuildContext context) => Padding(
      padding: const EdgeInsets.all(20),
      child: TextButton(
        onPressed: () {
          SecureStorage.removeToken();
          LocalStorage.removeType();
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (_) => const LoginScreen(),
            ),
            (route) => false,
          );
        },
        child: _btnTitle(),
      ),
    );

Text _btnTitle() => Text(
      'تسجيل الخروج',
      style: _style(),
    );

TextStyle _style() {
  return const TextStyle(
    fontSize: 24,
    fontWeight: FontWeight.bold,
    color: Colors.red,
  );
}
