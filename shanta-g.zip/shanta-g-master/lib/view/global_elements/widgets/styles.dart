import 'package:flutter/material.dart';
import 'colors.dart';

class Styles {
  static String fontFamily = "Sukar";

  static TextStyle get headTitle => TextStyle(
      fontFamily: fontFamily,
      fontSize: 25,
      color: ColorManager.primaryColor.withOpacity(0.87));

  static TextStyle get buttonText => TextStyle(
      fontFamily: fontFamily,
      fontSize: 20,
      fontWeight: FontWeight.bold,
      color: ColorManager.backgroundColor.withOpacity(0.87));

  static TextStyle get label0 => TextStyle(
      fontFamily: fontFamily,
      fontSize: 22,
      height: 1,
      fontWeight: FontWeight.w600,
      color: ColorManager.primaryColor.withOpacity(0.87));

  static TextStyle get label1 => TextStyle(
      fontFamily: fontFamily,
      fontSize: 18,
      height: 1,
      color: ColorManager.primaryText.withOpacity(0.87));

  static TextStyle get label2 => TextStyle(
      fontFamily: fontFamily,
      fontSize: 18,
      height: 1,
      color: ColorManager.primaryText.withOpacity(0.87));

  static TextStyle get label3 => TextStyle(
      fontFamily: fontFamily,
      fontSize: 14,
      height: 1,
      color: ColorManager.primaryColor.withOpacity(0.87));

  static TextStyle get label4 => TextStyle(
      fontFamily: fontFamily,
      fontSize: 20,
      height: 1,
      color: ColorManager.primaryColor.withOpacity(0.87));

  static TextStyle get label5 => TextStyle(
      fontFamily: fontFamily,
      fontSize: 12,
      height: 1,
      fontWeight: FontWeight.w500,
      color: ColorManager.primaryColor.withOpacity(0.87));

  static TextStyle get label6 => TextStyle(
      fontFamily: fontFamily,
      fontSize: 12,
      height: 1,
      fontWeight: FontWeight.w400,
      color: ColorManager.primaryColor.withOpacity(0.87));
}