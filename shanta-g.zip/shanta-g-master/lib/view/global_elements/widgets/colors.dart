import 'package:flutter/material.dart';

class ColorManager {

  static const Color backgroundColor = Color(0xFFFFFFFF);
  static const Color primaryColor = Color(0xFF151E46);
  static const Color secondaryColor = Color(0xFF151E46);
  static const Color secondarySec = Color(0xFFFFD049);
  static const Color primaryText = Color(0xFF151515);
  static const Color secondary = Color(0xFFe8e8e8);
  static const Color red = Color(0xFFFF4955);
  static const Color listTile = Color(0xFFD3D9EB);

}