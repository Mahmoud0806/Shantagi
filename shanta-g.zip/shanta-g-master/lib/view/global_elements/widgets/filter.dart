import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'colors.dart';
import 'styles.dart';

class FilterScreen extends StatefulWidget {
  FilterScreen({
    Key? key,
  }) : super(key: key);

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  final List<String> myList = [
    'المجموعات',
    'قلائد',
    'أقراط',
    'أساور',
    'خواتم',
    'ليرات',
    'أونصات',
  ];

  final List<String> selectedUserList = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return StatefulBuilder(
                  builder: (BuildContext context,
                      void Function(void Function()) setState) {
                    return AlertDialog(
                      title: Text('التصنيفات',
                          style: Styles.label0
                              .copyWith(color: ColorManager.primaryText)),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text('المنتجات',
                              style: Styles.label1.copyWith(fontSize: 20)),
                          Wrap(
                            children: myList.map(
                                  (hobby) {
                                bool isSelected = false;
                                if (selectedUserList.contains(hobby)) {
                                  isSelected = true;
                                }
                                return GestureDetector(
                                  onTap: () {
                                    if (!selectedUserList.contains(hobby)) {
                                      if (selectedUserList.length < 5) {
                                        setState(() {
                                          selectedUserList.add(hobby);
                                          isSelected = true;
                                        });
                                        print(selectedUserList);
                                      }
                                    } else {
                                      selectedUserList.removeWhere(
                                              (element) => element == hobby);
                                      setState(() {});
                                      print(selectedUserList);
                                    }
                                  },
                                  child: Container(
                                      margin: EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 4),
                                      child: Container(
                                        padding: EdgeInsets.symmetric(
                                            vertical: 5, horizontal: 12),
                                        decoration: BoxDecoration(
                                            color: isSelected
                                                ? ColorManager.primaryColor
                                                : Colors.white,
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            border: Border.all(
                                              color: ColorManager.primaryColor,
                                              width: 2,
                                            )),
                                        child: Text(hobby,
                                            style: Styles.label3.copyWith(
                                              color: isSelected
                                                  ? ColorManager.backgroundColor
                                                  : ColorManager.primaryColor,
                                            )),
                                      )),
                                );
                              },
                            ).toList(),
                          ),
                          SizedBox(
                            height: 15.h,
                          ),
                          Text('غرام الذهب',
                              style: Styles.label1.copyWith(fontSize: 20)),
                          Wrap(
                            children: myList.map(
                                  (hobby) {
                                bool isSelected = false;
                                if (selectedUserList.contains(hobby)) {
                                  isSelected = true;
                                }
                                return GestureDetector(
                                  onTap: () {
                                    if (!selectedUserList.contains(hobby)) {
                                      if (selectedUserList.length < 5) {
                                        setState(() {
                                          selectedUserList.add(hobby);
                                          isSelected = true;
                                        });
                                        print(selectedUserList);
                                      }
                                    } else {
                                      selectedUserList.removeWhere(
                                              (element) => element == hobby);
                                      setState(() {});
                                      print(selectedUserList);
                                    }
                                  },
                                  child: Container(
                                      margin: EdgeInsets.symmetric(
                                          horizontal: 5, vertical: 4),
                                      child: Container(
                                        padding: EdgeInsets.symmetric(
                                            vertical: 5, horizontal: 12),
                                        decoration: BoxDecoration(
                                            color: isSelected
                                                ? ColorManager.primaryColor
                                                : Colors.white,
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            border: Border.all(
                                              color: ColorManager.primaryColor,
                                              width: 2,
                                            )),
                                        child: Text(
                                          hobby,
                                          style: TextStyle(
                                              color: isSelected
                                                  ? Colors.white
                                                  : ColorManager.primaryColor,
                                              fontSize: 16,
                                              fontFamily: 'Sukar'),
                                        ),
                                      )),
                                );
                              },
                            ).toList(),
                          ),
                        ],
                      ),
                    );
                  },
                );
              });
        },
      ),
    );
  }
}