import 'package:flutter/material.dart';

import '/view/global_elements/fields/custom_text_field.dart';

SizedBox searchBar(
  String label,
  TextEditingController controller,
    onChanged,
) =>
    SizedBox(
      height: 90,
      child: customTextField(
        controller: controller,
        label: label,
        change: onChanged,
      ),
    );
