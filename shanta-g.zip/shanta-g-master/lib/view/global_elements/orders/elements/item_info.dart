import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

SizedBox itemInfo(String data) => SizedBox(
      child: Text(
        data,
        style: _style().copyWith(color: AppColors.primaryText),
      ),
    );

TextStyle _style() => TextStyle(
// fontFamily: fontFamily,
      fontSize: 14,
      height: 1,
// fontWeight: FontWeight.w900,
      color: AppColors.primary.withOpacity(0.87),
    );
