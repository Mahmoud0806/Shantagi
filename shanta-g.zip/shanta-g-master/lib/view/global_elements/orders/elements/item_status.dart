import 'package:flutter/material.dart';

Widget itemStatus({status}) => SizedBox(
      child: Row(
        children: [
          _statusTitle(status),
          _statusDot(
            status == 'done'
                ? Colors.black
                : status == 'ready'
                    ? Colors.yellow
                    : status == 'answered'
                        ? Colors.green
                        : status == 'cancelled'
                            ? Colors.red
                            : Colors.grey,
          ),
        ],
      ),
    );

Widget _statusTitle(String status) => SizedBox(
      child: Text(
        status == 'done'
            ? 'منفذ'
            : status == 'ready'
                ? 'جاهز'
                : status == 'answered'
                    ? 'تم الرد'
                    : status == 'cancelled'
                        ? 'ملغى'
                        : 'قيد الإنتظار',
        style: _style(status == 'done'
            ? Colors.black
            : status == 'ready'
                ? Colors.yellow
                : status == 'answered'
                    ? Colors.green
                    : status == 'cancelled'
                        ? Colors.red
                        : Colors.grey),
      ),
    );

TextStyle _style(Color? color) => TextStyle(fontSize: 18, color: color);

Container _statusDot(Color? color) => Container(
      height: 12,
      width: 12,
      decoration: _decoration(color),
    );

BoxDecoration _decoration(Color? color) => BoxDecoration(
      color: color ?? Colors.grey,
      borderRadius: BorderRadius.circular(25),
    );
