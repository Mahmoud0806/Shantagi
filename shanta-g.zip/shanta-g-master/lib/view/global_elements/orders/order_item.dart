import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '/data/constant/app_colors.dart';
import '/models/order/order.dart';
import 'elements/item_info.dart';
import 'elements/item_status.dart';

InkWell orderItem(Order order, VoidCallback onTap,
        {Color? color, bool? showStatus}) =>
    InkWell(
      onTap: onTap,
      child: Card(
        color: color ?? AppColors.background,
        elevation: 3,
        shape: _shape(),
        margin: const EdgeInsets.all(15.0),
        child: _itemElements(order),
      ),
    );

Widget _itemElements(Order order, {bool? showStatus = true}) => Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        children: _columnChildren(order, showStatus),
      ),
    );

List<Widget> _columnChildren(Order order, bool? showStatus) => [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: _rowChildren(order),
      ),
      const SizedBox(height: 50),
      showStatus != false ? itemStatus(status: order.status) : const SizedBox.shrink(),
    ];

List<Widget> _rowChildren(Order order) => [
      itemInfo(
          DateFormat('yyyy/MM/dd').format(DateTime.parse(order.createdAt))),
      itemInfo(order.number),
    ];

RoundedRectangleBorder _shape() {
  return RoundedRectangleBorder(
    side: const BorderSide(color: AppColors.primaryText),
    borderRadius: BorderRadius.circular(5),
  );
}
