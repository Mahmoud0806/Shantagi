import 'package:flutter/material.dart';

import '/data/constant/app_colors.dart';

Widget customTextField({
  required TextEditingController controller,
  TextInputType? keyboard,
  String? Function(String? value)? validate,
  Function(String s)? submit,
  Function(String a)? change,
  Function()? onTap,
  bool enabled = true,
  required String label,
  IconData? prefix,
  IconData? suffix,
  Function()? suffixPressed,
  bool obSecure = false,
}) =>
    Padding(
      padding: const EdgeInsets.all(15),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboard,
        obscureText: obSecure,
        onFieldSubmitted: submit,
        onChanged: change,
        onTap: onTap,
        enabled: enabled,
        validator: validate,
        cursorColor: AppColors.primary,
        decoration: _decoration(label, prefix, suffixPressed, suffix),
      ),
    );

InputDecoration _decoration(String label, IconData? prefix,
    Function()? suffixPressed, IconData? suffix) {
  return InputDecoration(
    labelText: label,
    filled: true,
    fillColor: Colors.white,
    labelStyle: const TextStyle(color: AppColors.primary),
    border: InputBorder.none,
    prefixIcon: prefix != null ? _prefixIcon(prefix) : null,
    suffixIcon: _suffixIcon(suffixPressed, suffix),
  );
}

IconButton _suffixIcon(Function()? suffixPressed, IconData? suffix) {
  return IconButton(
    onPressed: suffixPressed,
    icon: Icon(
      suffix,
      color: AppColors.secondarySec,
    ),
  );
}

Icon _prefixIcon(IconData prefix) {
  return Icon(
    prefix,
    color: AppColors.primary,
  );
}
