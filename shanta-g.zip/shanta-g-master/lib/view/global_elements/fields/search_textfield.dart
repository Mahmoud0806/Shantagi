import 'package:flutter/material.dart';
import '../widgets/colors.dart';

class SearchTextField extends StatelessWidget {
  final bool? autofocus;
  final Function(String value)? onChanged;
  final TextEditingController? controller;
  final String? hintText;
  final TextStyle? hintStyle;
  final InputBorder? border;
  final InputBorder? focusedBorder;
  final Widget? suffixIcon;
  final Widget? prefixIcon;

  const SearchTextField({
    Key? key,
    this.autofocus,
    this.hintText,
    this.hintStyle,
    this.border,
    this.focusedBorder,
    this.controller,
    this.suffixIcon,
    this.onChanged,
    this.prefixIcon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      autofocus: autofocus ?? false,
      onChanged: onChanged,
      controller: controller,
      cursorColor: ColorManager.primaryColor,
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor: Colors.grey.shade300,
        hintStyle: const TextStyle(
          fontFamily: 'Sukar',
          fontSize: 16,
        ),
        border: const OutlineInputBorder(
          // borderSide: BorderSide.(width: 2),
          borderSide: BorderSide.none,borderRadius: BorderRadius.all(Radius.circular(25.0)),
        ),
        suffixIcon: suffixIcon,
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(width: 2, color: ColorManager.primaryColor),
        ),
        prefixIcon: prefixIcon,
        // prefixIcon: IconButton(
        //   onPressed: () {
        //     Navigator.pop(context);
        //   },
        //   icon: Icon(Icons.arrow_back),
        // ),
        prefixIconColor: MaterialStateColor.resolveWith((states) =>
        states.contains(MaterialState.focused)
            ? ColorManager.primaryColor
            : Colors.grey),
        suffixIconColor: MaterialStateColor.resolveWith((states) =>
        states.contains(MaterialState.focused)
            ? ColorManager.primaryColor
            : Colors.grey),
      ),
    );
  }
}
