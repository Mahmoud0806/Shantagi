import 'package:flutter/material.dart';
import '/view/global_elements/app_bar/title.dart';

AppBar customAppBar(
  String title,
  BuildContext context, {
  bool? showBack,
  Widget? leading,
  Color? background,
  Color? foreground,
}) =>
    AppBar(
      leading: leading ??
          (showBack == null ? const SizedBox.shrink() : _backButton(context)),
      backgroundColor: background,
      surfaceTintColor: background,
      foregroundColor: foreground,
      title: barTitle(title),
    );

IconButton _backButton(BuildContext context) => IconButton(
      onPressed: () {
        Navigator.maybePop(context);
      },
      icon: const Icon(Icons.arrow_back_ios_new_rounded),
    );
