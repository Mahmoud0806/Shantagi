import 'package:flutter/material.dart';
import '/data/constant/app_colors.dart';

Widget barTitle(String data) => SizedBox(
      child: Text(
        data,
        style: _style(),
      ),
    );

TextStyle _style() {
  return const TextStyle(
        fontSize: 22,
        color: AppColors.primary
      );
}
