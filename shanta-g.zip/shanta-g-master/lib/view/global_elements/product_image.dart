import 'package:flutter/material.dart';

class ProductImageScreen extends StatefulWidget {
  final Widget image;

  const ProductImageScreen({super.key, required this.image});

  @override
  State<ProductImageScreen> createState() => _ProductImageScreenState();
}

class _ProductImageScreenState extends State<ProductImageScreen> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: MediaQuery.sizeOf(context).height,
      width: double.infinity,
      child: InteractiveViewer(
        panEnabled: false,
        boundaryMargin: const EdgeInsets.all(100),
        minScale: 1,
        maxScale: 3.5,
        child: widget.image,
      ),
    );
  }
}
