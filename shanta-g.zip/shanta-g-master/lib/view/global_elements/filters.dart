import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '/logic/cubits/admin/products/products_cubit.dart';
import '/logic/cubits/categories/categories_cubit.dart';
import '/logic/cubits/filters/filters_cubit.dart';

import '/data/constant/app_colors.dart';
import 'widgets/styles.dart';

AlertDialog dialog(BuildContext context,
    {bool showDealers = false, VoidCallback? onPressed}) {
  var filterCubit = BlocProvider.of<FiltersCubit>(context);
  int karatIndex = 0;
  int dealerIndex = 0;
  int catIndex = 0;
  return AlertDialog(
    title: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          'الفلاتر',
          style: Styles.label0.copyWith(color: AppColors.primary),
        ),
        TextButton(
          onPressed: () {
            filterCubit.resetFilters();
          },
          child: Text(
            'حذف الكل',
            style: Styles.label3.copyWith(color: Colors.red),
          ),
        )
      ],
    ),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('التصنيفات',
                  style: Styles.label1.copyWith(fontSize: 20, height: 2)),
              BlocBuilder<FiltersCubit, FiltersState>(
                builder: (context, filterState) {
                  return BlocBuilder<CategoriesCubit, CategoriesState>(
                    builder: (context, state) {
                      return Wrap(
                        children: state.categories.map(
                          (hobby) {
                            if (catIndex >= state.categories.length) {
                              catIndex = 0;
                            }
                            return _filterItem(hobby.name, () {
                              filterCubit.selectCat(state.categories, hobby);
                            }, filterState.selectedCategories[catIndex++]);
                          },
                        ).toList(),
                      );
                    },
                  );
                },
              ),
              const SizedBox(
                height: 15,
              ),
              showDealers == true
                  ? Text(
                      'التجار',
                      style: Styles.label1.copyWith(fontSize: 20, height: 2),
                    )
                  : const SizedBox.shrink(),
              showDealers == true
                  ? BlocBuilder<FiltersCubit, FiltersState>(
                      builder: (context, filterState) {
                        return Wrap(
                          children: filterState.dealers.map(
                            (dealer) {
                              print('------- :: ${dealer.toString()}');
                              if (dealerIndex >=
                                  filterState.selectedDealers.length) {
                                dealerIndex = 0;
                              }
                              return _filterItem(dealer.name, () {
                                print(
                                    'filter : start dealer ${dealer.id} , ${dealer.name}');
                                filterCubit.selectDealer(filterState.dealers,
                                    dealer.id, dealer.name);
                              }, filterState.selectedDealers[dealerIndex++]);
                            },
                          ).toList(),
                        );
                      },
                    )
                  : const SizedBox.shrink(),
              Text('غرام الذهب',
                  style: Styles.label1.copyWith(fontSize: 20, height: 2)),
              BlocBuilder<FiltersCubit, FiltersState>(
                builder: (context, filterState) {
                  return Wrap(
                    children: filterState.karat.map(
                      (karat) {
                        if (karatIndex >= filterState.karat.length) {
                          karatIndex = 0;
                        }
                        return _filterItem('$karat', () {
                          filterCubit.selectKarat(karat);
                        }, filterState.selectedKarat[karatIndex++]);
                      },
                    ).toList(),
                  );
                },
              ),
            ],
          ),
          InkWell(
            onTap: onPressed ?? () {
              var cubit = BlocProvider.of<ProductsCubit>(context);
              cubit.getAll(params: filterCubit.setSelectedParams());
              Navigator.maybePop(context);
            },
            child: Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Container(
                width: MediaQuery.of(context).size.width * 0.8,
                decoration: BoxDecoration(
                  color: AppColors.primary,
                  border: Border.all(
                    color: Colors.white,
                  ),
                  borderRadius: BorderRadius.circular(5),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Center(
                    child: Text(
                      'حفظ',
                      style: Styles.buttonText,
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

GestureDetector _filterItem(hobby, VoidCallback onPressed, bool isSelected) {
  return GestureDetector(
    onTap: onPressed,
    child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 12),
          decoration: BoxDecoration(
              color: isSelected ? AppColors.secondarySec : Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: isSelected ? AppColors.secondarySec : AppColors.primary,
                width: 2,
              )),
          child: Text(hobby,
              style: Styles.label3.copyWith(
                color: AppColors.primary,
              )),
        )),
  );
}
