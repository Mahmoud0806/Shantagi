import 'package:fluro/fluro.dart';
import 'package:flutter/material.dart';

import '/view/users/shanta/home/shanta_home.dart';
import '/view/users/wholesaler/home/wholesaler_home.dart';
import '/view/auth/login/login.dart';
import '/view/users/client/home/client_home.dart';
import '/view/users/retailer/home/retailer_home.dart';

class FRouter {
  static final FluroRouter router = FluroRouter();

  static Handler login = Handler(
      handlerFunc: (BuildContext? context, Map<String, dynamic> params) {
    return const LoginScreen();
  });

  static Handler adminHome = Handler(
      handlerFunc: (BuildContext? context, Map<String, dynamic> params) {
    // return const AdminHome();
  });
  static Handler adminOrderDetails = Handler(
      handlerFunc: (BuildContext? context, Map<String, dynamic> params) {
    // return ();
  });

  static Handler wholesalerHome = Handler(
      handlerFunc: (BuildContext? context, Map<String, dynamic> params) {
    return const WholesalerHome();
  });

  static Handler retailerHome = Handler(
      handlerFunc: (BuildContext? context, Map<String, dynamic> params) {
    return const RetailerHome();
  });

  static Handler clientHome = Handler(
      handlerFunc: (BuildContext? context, Map<String, dynamic> params) {
    return const ClientHome();
  });

  static Handler subAdminHome = Handler(
      handlerFunc: (BuildContext? context, Map<String, dynamic> params) {
    return const ShantaHome();
  });

  static void defineRoutes() {
    router.define('/adminHome', handler: adminHome);

    router.define('/wholesalerHome', handler: wholesalerHome);

    router.define('/retailerHome', handler: retailerHome);

    router.define('/clientHome', handler: clientHome);

    router.define('/shantaHome', handler: subAdminHome);
  }
}
