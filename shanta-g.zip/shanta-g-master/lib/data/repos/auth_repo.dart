import '/data/constant/constant.dart';

import '/data/apis/auth_api.dart';
import '/data/constant/body_decode.dart';
import '../constant/storage/local_storage_services.dart';
import '/models/user.dart';

class AuthRepo {
  final _api = AuthApi();

  Future<User> login(String url, var bodyData) async {
    try {
      var data = await decodeResponse(_api.login(url, bodyData));
      token = data['token'];
      print('init token: $token');
      await LocalStorage.saveToLocal(data);
      return User.fromMap(data['user']);
    } catch (error) {
      rethrow;
    }
  }

  Future logout(String url) async {
    try {
      await decodeResponse(_api.logout(url));
      await LocalStorage.removeAllLocal();
    } catch (error) {
      rethrow;
    }
  }

  Future changePassword(String url, var bodyData) async {
    try {
      await decodeResponse(_api.changePassword(url, bodyData));
    } catch (error) {
      rethrow;
    }
  }

  Future fcmToken(String url, var bodyData) async {
    try {
      await decodeResponse(_api.fcmToken(url, bodyData));
    } catch (error) {
      rethrow;
    }
  }

  Future forgotPassword(String url, var bodyData) async {
    try {
      await decodeResponse(_api.forgotPassword(url, bodyData));
    } catch (error) {
      rethrow;
    }
  }

  Future resetPassword(String url, var bodyData) async {
    try {
      await decodeResponse(_api.resetPassword(url, bodyData));
    } catch (error) {
      rethrow;
    }
  }
}
