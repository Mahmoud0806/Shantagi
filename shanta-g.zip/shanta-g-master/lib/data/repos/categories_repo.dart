import 'dart:convert';

import '/data/apis/categories.dart';
import '/data/constant/body_decode.dart';
import '/models/category.dart';

class CategoriesRepo {
  final _api = CategoriesApi();

  Future<List<Category>> getAll(String url) async {
    try {
      var response = await decodeResponse(_api.getAll(url));
      print(response);
      return Category.fromListOfMaps(response['data']['categories'] ?? {});
    } catch (error) {
      rethrow;
    }
  }

  Future<Category> create(String url, String name) async {
    try {
      print('cat name $name');
      var response = await decodeResponse(_api.add(url, json.encode(setBody(name))));
      return Category.fromMap(response['data']['category']);
    } catch (error) {
      rethrow;
    }
  }

  Future<List<Category>> update(String url, String name) async {
    try {
      var body = json.encode({"name": name});
      var response = await decodeResponse(_api.update(url, body));
      return Category.fromListOfMaps(response['data']['category']);
    } catch (error) {
      rethrow;
    }
  }

  Future<List<Category>> delete(String url) async {
    try {
      var response = await decodeResponse(_api.deleteById(url));
      return Category.fromListOfMaps(response['data']['category']);
    } catch (error) {
      rethrow;
    }
  }

  setBody(String name) => {
        'name': name,
      };
}
