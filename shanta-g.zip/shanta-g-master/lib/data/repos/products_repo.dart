import 'dart:convert';

import '/data/apis/products_api.dart';
import '/data/constant/body_decode.dart';
import '/models/product/product.dart';

class ProductsRepo {
  final _api = ProductsApi();

  Future<Product> createProduct(
      String url, Product product, String path) async {
    try {
      var response = await _api.create(url, product, path);
      print(json.decode(response));
      // var products = Product.fromListOfMaps(response['data']['product'] ?? {});
      // print(products.length);
      return Product.initial();
    } catch (error) {
      rethrow;
    }
  }

  Future<List<Product>> getAll(String url) async {
    try {
      var response = await decodeResponse(_api.getAll(url));
      print('--- prod res $response');

      var products = Product.fromListOfMaps(response['data']['products'] ?? []);
      print('products.length\$\$ ${products.length}');
      return products;
    } catch (error) {
      rethrow;
    }
  }

  Future<List<Product>> getAllProducts(String url) async {
    try {
      print(' ------------- response  prod ');
      var response = await decodeResponse(_api.getAll(url));
      print(' ------------- response  prod $response');
      List<Product> products =
          Product.fromListOfMaps(response['data'][0]['products'] ?? []);
      print('products.length\$\$ ${products.length}');
      return products;
    } catch (error) {
      rethrow;
    }
  }

  Future<Product> getById(String url) async {
    try {
      var response = await decodeResponse(_api.getById(url));
      return _productModeling(response);
    } catch (error) {
      rethrow;
    }
  }

  // Future<Product> create(String url, var bodyData) async {
  //   try {
  //     var response = await decodeResponse(_api.create(url, bodyData));
  //     return _productModeling(response);
  //   } catch (error) {
  //     rethrow;
  //   }
  // }

  Future<Product> update(String url, Product product) async {
    try {
      var response = await decodeResponse(_api.update(url, product.toMap()));
      return _productModeling(response);
    } catch (error) {
      rethrow;
    }
  }

  Future<Product> deleteById(String url) async {
    try {
      var response = await decodeResponse(_api.deleteById(url));
      return _productModeling(response);
    } catch (error) {
      rethrow;
    }
  }

  Product _productModeling(response) => Product.fromMap(response);

  Future<Product> addImage(String url, var image) async {
    try {
      var response = await decodeResponse(_api.addImage(url, image));
      return Product.fromMap(response['data']['product']);
    } catch (error) {
      rethrow;
    }
  }

  Future<Product> removeImage(String url) async {
    try {
      var response = await decodeResponse(_api.removeImage(url));
      return Product.fromMap(response['data']['product']);
    } catch (error) {
      rethrow;
    }
  }

  Future<Product> changeHoldStatus(String url) async {
    try {
      var response = await decodeResponse(_api.changeHoldStatus(url));
      print(response);
      return Product.fromMap(response['data']['product']);
    } catch (error) {
      rethrow;
    }
  }
}
