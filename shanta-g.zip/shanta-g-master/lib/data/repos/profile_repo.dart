import '/data/constant/constant.dart';
import '/data/constant/storage/local_storage_services.dart';

import '/data/constant/body_decode.dart';

import '/data/apis/profile_api.dart';
import '/models/profile.dart';

class ProfileRepo {
  final _api = ProfileApi();

  Future<Profile> getProfile() async {
    try {
      String url = '$baseURL/user/profile';
      var response = await decodeResponse(_api.getProfile(url));
      LocalStorage.storeUserData(LocalStorage.modelUserData(response['data']));
      return Profile.fromMap(response['data']);
    } catch (error) {
      rethrow;
    }
  }
}
