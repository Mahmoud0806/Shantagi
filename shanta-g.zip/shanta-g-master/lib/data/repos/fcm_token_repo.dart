import 'dart:convert';

import '/data/apis/fcm_token_apis.dart';


class FCMTokenRepo {
  var fcmTokenApis = FCMTokenApis();
  Future<void> postFCMToken(String fcmToken)async {
    try {
      print('start repo ==================================');
      var response = await fcmTokenApis.postFCMToken(fcmToken);
      var responseBody = json.decode(response.body);
    }catch (error) {
      rethrow;
    }
  }
}