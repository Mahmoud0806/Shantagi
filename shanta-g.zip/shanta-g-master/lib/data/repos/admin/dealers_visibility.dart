import 'dart:convert';

import '/data/apis/admin/dealers_visibility.dart';
import '/data/constant/body_decode.dart';

class DealersVisibilityRepo {
  final _api = DealersVisibilityApi();

  Future changeVisibility(String url, bool wholesaler, bool shanta) async {
    try {
      var body = await decodeResponse(
        _api.change(url, {
          'wholesaler': wholesaler ? 1 : 0,
          'shanta_trader': shanta ? 1 : 0,
        }),
      );
      print('finish repo ');
      return body;
    } catch (error) {
      rethrow;
    }
  }

  Future getVisibility(String url) async {
    try {
      var response = await _api.getAppearance(url);
      print('res :: ${response.body}');
      return json.decode(response.body);
    } catch (error) {
      rethrow;
    }
  }
}
