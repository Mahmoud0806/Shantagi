import 'dart:io';

import '/data/apis/admin/report.dart';
import '/data/constant/body_decode.dart';

class ReportRepo {
  final _api = ReportApi();

  Future<File> getReport(String url) async {
    try {
      return await decodeResponse(_api.getReport(url));
    } catch (e) {
      rethrow;
    }
  }
}
