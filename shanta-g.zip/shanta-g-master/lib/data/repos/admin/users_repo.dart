import 'package:shantagi/data/constant/constant.dart';
import 'package:shantagi/data/constant/headers.dart';

import '/data/apis/admin/users_api.dart';
import '/data/constant/body_decode.dart';
import '/models/user.dart';

class UsersRepo {
  final _api = UsersApi();

  Future<List<User>> getAll(String url, String type) async {
    try {
      var response = await decodeResponse(_api.getAll(url));
      // print("repose ::: ${response['data'][0]['shanta_traders']}");
      var dealers =
          await User.fromMapsList(response['data'][0][type] ?? []);
      print(dealers.length);
      return dealers;
    } catch (e) {
      rethrow;
    }
  }

  Future<User> getById(String url) async {
    try {
      return await decodeResponse(_api.getById(url));
    } catch (e) {
      rethrow;
    }
  }

  Future<User> getUserClients(String url) async {
    try {
      return await decodeResponse(_api.getUserClients(url));
    } catch (e) {
      rethrow;
    }
  }

  Future create(String url, User user) async {
    try {
      print('start Api');
      var response =  await decodeResponse(_api.create(url, user.toMap()));
      print('print res ::: $response');
      print('end  Api');

      return response;
    } catch (e) {
      rethrow;
    }
  }

  Future<User> update(String url, User user) async {
    try {
      print('start send repo');
      return await decodeResponse(_api.update(url, user.toMap(),headers: {
        'Accept' : 'application/json',
        'Authorization' : 'Bearer $token',
      }));
    } catch (e) {
      rethrow;
    }
  }
  Future<User> changeType(String url) async {
    try {
      print('start send repo');
      return await decodeResponse(_api.changeType(url));
    } catch (e) {
      rethrow;
    }
  }

  Future<User> delete(String url) async {
    try {
      return await decodeResponse(_api.deleteUser(url));
    } catch (e) {
      rethrow;
    }
  }
}
