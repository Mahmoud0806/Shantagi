import '/data/apis/admin/dealer_access.dart';
import '/data/constant/body_decode.dart';
import '/models/user.dart';

class DealerAccessRepo {
  final _api = DealerAccessApi();

  Future<Map<String, List>> getDealers(String url) async {
    try {
      var response = await decodeResponse(_api.getDealers(url));
      List<User> shanta = User.fromMapsList(response['data']['shanta_traders']);
      List<User> wholesalers =
          User.fromMapsList(response['data']['wholesalers']);
      List<User> retailers = User.fromMapsList(response['data']['retailers']);
      List<bool> selectedWholesalers = fillSelectedDealers(wholesalers.length);
      List<bool> selectedShanta = fillSelectedDealers(shanta.length);
      List<bool> selectedRetailers = fillSelectedDealers(retailers.length);
      List<bool> selectedShantaRetailers =
          fillSelectedDealers(retailers.length);

      Map<String, List> allDealers = {
        'shanta': shanta,
        'wholesalers': wholesalers,
        'retailers': retailers,
        'selectedWholesalers': selectedWholesalers,
        'selectedShanta': selectedShanta,
        'selectedRetailers': selectedRetailers,
        'selectedShantaRetailers': selectedShantaRetailers,
      };
      return allDealers;
    } catch (e) {
      rethrow;
    }
  }

  List<bool> fillSelectedDealers(length) {
    return List.filled(length, false);
  }

  Future<List<User>> getAccess(String url) async {
    try {
      var response = await decodeResponse(_api.getAccess(url));
      List<User> retailers = User.fromMapsList(response['data']['retailers']);
      return retailers;
    } catch (e) {
      rethrow;
    }
  }

  Future<Map<String, List>> getRetailerAccess(String url) async {
    try {
      var usersMaps = await decodeResponse(_api.getAccess(url));
      print(usersMaps);
      List<User> wholesalers = [];
      wholesalers
          .addAll(User.fromAccessMapsList(usersMaps['data']['wholesalers']));
      print('whole lase LL LL : $wholesalers');
      List<User> shanta = [];
      shanta
          .addAll(User.fromAccessMapsList(usersMaps['data']['shanta_traders']));
      Map<String, List> users = {
        'wholesalers': wholesalers,
        'shanta': shanta,
      };
      print('send users');
      return users;
    } catch (e) {
      rethrow;
    }
  }

  Future<List<User>> getDealerAccess(String url) async {
    try {
      var usersMaps = await decodeResponse(_api.getAccess(url));
      List<User> users = User.fromMapsList(usersMaps['data']['retailers']);
      return users;
    } catch (e) {
      rethrow;
    }
  }


  Future<List<User>> setAccess(String url, int id, List<int> ids) async {
    try {
      var body = {
        "wholesaler_id": id,
        "retailer_ids": ids,
      };
      return await decodeResponse(_api.setAccess(url, body));
    } catch (e) {
      rethrow;
    }
  }

  Future<List<User>> setRetailerAccess(
      String url, int id, List<int> ids) async {
    try {

      print('selectd ID in api :: ::: :: $ids');
      var body = {
        "retailer_id": id,
        "wholesaler_ids": ids,
      };
      return await decodeResponse(_api.setAccess(url, body));
    } catch (e) {
      rethrow;
    }
  }

  Future<List<List<User>>> setDealers(String url, List<int> body) async {
    try {
      return await decodeResponse(_api.setAccess(url, body));
    } catch (e) {
      rethrow;
    }
  }
}
