import '/data/apis/retailer_dealers_api.dart';
import '/data/constant/body_decode.dart';
import '/models/user.dart';

class RetailerDealersRepo {
  final _api = RetailerDealersApi();

  Future<List<User>> getAll(String url) async {
    try {
      var response = await decodeResponse(_api.getAll(url));
      // print("repose ::: ${response['data'][0]['shanta_traders']}");
      var dealers =
      await User.fromMapsList(response['data']['wholesalers'] ?? []);
      print(dealers.length);
      return dealers;
    } catch (e) {
      rethrow;
    }
  }
}