import 'dart:convert';

import 'package:http/http.dart' as http;
import '/data/constant/urls/clients.dart';

import '../constant/constant.dart';
import '/data/apis/orders_api.dart';
import '/data/constant/body_decode.dart';
import '/models/order/order.dart';

class OrdersRepo {
  final _api = OrdersApi();

  Future getAll(String url) async {
    try {
      var response = await decodeResponse(_api.getAll(url));
      return Order.fromListOfMaps(response['data']['orders']);
    } catch (error) {
      rethrow;
    }
  }
  Future getUserOrders(String url) async {
    try {
      var response = await decodeResponse(_api.getAll(url));
       return Order.fromListOfMaps(response['data'][0]['orders']);
    } catch (error) {
      rethrow;
    }
  }


  Future getById(String url) async {
    try {
      var response = await decodeResponse(_api.getById(url));
      return Order.fromListOfMaps(response['data']['order']);
    } catch (error) {
      rethrow;
    }
  }

  Future changeStatus(String url, var status) async {
    try {
      var response = await decodeResponse(_api.changeStatus(url, status));
      return Order.fromMap(response['data']['order']);
    } catch (error) {
      rethrow;
    }
  }

  Future changeItemStatus(String url, String status) async {
    try {
      var response = await decodeResponse(_api.changeItemStatus(url, status));
      return Order.fromMap(response['data']['order']);
    } catch (error) {
      rethrow;
    }
  }

  Future confirm(String url, List items) async {
    try {
      print('start repo');
      print(items.first.toString());
      print(items.toString());
      // String url = ClientURLs.confirmOrder;
      Uri uri = Uri.parse(url);
      print('start');
      Map<String, String> headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };
      print(items);
      var response = await http.post(
        uri,
        headers: headers,
        body: json.encode({
          'items' : items,
        }),
      );
      print(response.statusCode);
      print(json.decode(response.body));
      if (response.statusCode != 200) {
        throw Exception();
      }
      return response;
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> confirmOrder(String url, Map<String, dynamic> body) async {
    // String url = ClientURLs.confirmOrder;
    Uri uri = Uri.parse(url);
    print('start');
    Map<String, String> headers = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    };
    var response = await http.post(
      uri,
      headers: headers,
      body: json.encode(body),
    );
    print('===========================================================');
    print(response.statusCode);
    print(json.decode(response.body));
    print('===========================================================');
    if (response.statusCode != 200) {
      throw Exception();
    }
    return response;
  }

  Future changeOrderStatus(int id) async {
    try {
      print('ressss value to sentttt ::: ');
      var response = await _api.changeOrderStatus(id);
      var responseBody = json.decode(response.body);
      print(responseBody['data']);
      // return responseBody['data'] == true;
    } catch (error) {
      rethrow;
    }
  }

  Future<String> changeOrderItemStatus(int id, String status) async {
    try {
      print('ressss value to sentttt ::: ');
      var response = await _api.changeOrderItemStatus(id, status);
      var responseBody = json.decode(response.body);
      print(responseBody['data']);
      return responseBody['data']['status'];
    } catch (error) {
      rethrow;
    }
  }
}
