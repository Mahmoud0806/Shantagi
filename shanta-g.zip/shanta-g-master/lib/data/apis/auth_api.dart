import 'dart:convert';

import 'package:http/http.dart' as http;

import '/data/constant/http_methods.dart';

class AuthApi {
  Future<http.Response> login(String url, var bodyData) async {
    try {
      return await post(url: url, body: bodyData);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> logout(String url) async {
    try {
      return await post(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> changePassword(String url, var bodyData) async {
    try {
      return await post(url: url, body: bodyData);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> fcmToken(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> forgotPassword(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> resetPassword(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }
}
