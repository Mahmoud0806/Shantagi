import 'dart:convert';

import 'package:http/http.dart' as http;
import '/models/product/product.dart';
import '/data/constant/headers.dart';

import '/data/constant/http_methods.dart';

class ProductsApi {
  Future<http.Response> getAll(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> getById(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<String> create(String url, Product bodyData, String path) async {
    try {
      // var body = json.encode(bodyData);
      return await postProduct(url: url, body: bodyData, filePath: path);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> update(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> deleteById(String url) async {
    try {
      return await delete(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> addImage(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> removeImage(String url) async {
    try {
      // var body = json.encode(bodyData);
      return await post(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> changeHoldStatus(String url) async {
    try {
      print('start api');
      return await post(url: url);
    } catch (error) {
      rethrow;
    }
  }

}
