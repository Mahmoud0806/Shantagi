import 'dart:convert';

import 'package:http/http.dart' as http;
import '/data/constant/constant.dart';
import '/data/constant/urls/admin.dart';

import '/data/constant/headers.dart';
import '/data/constant/http_methods.dart';

class OrdersApi {
  Future<http.Response> getAll(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> getById(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> changeStatus(String url, var status) async {
    try {
      // var body = json.encode({"status": 'new'});
      var body = json.encode({"status": status});
      return await post(url: url, body: body, headers: {
        ...headersWithContent
      });
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> changeItemStatus(String url, var status) async {
    try {
      var body = json.encode({"status": status});
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> confirm(String url, List items) async {
    try {
      // var body = json.encode({"items": items});
      print('body encoded:: ;:: ${json.encode({"items": items})}');
      return await post(
          url: url,
          headers: headersWithContent,
          body: json.encode({"items": items}));
    } catch (error) {
      rethrow;
    }
  }

  Future changeOrderStatus(int id) async {
    try {
      Map<String, String> headers = {
        'Accept': 'application/json',
        // 'content-type': 'application/json',
        'Authorization': 'Bearer $token',
      };
      final Uri url = Uri.parse('${AdminURLs.changeClientOrderStatus}/$id');
      var response = await http.post(url, headers: headers);
      print('order ;;;;;;; ${response.body}');
      if (response.statusCode != 200) {
        throw Exception('error: ${response.statusCode}');
      }
      return response;
    } catch (error) {
      rethrow;
    }
  }

  Future changeOrderItemStatus(int id, String status) async {
    try {
      Map<String, String> headers = {
        'Accept': 'application/json',
        // 'content-type': 'application/json',
        'Authorization': 'Bearer $token',
      };
      Map<String, dynamic> body = {
        'status': status,
      };
      print('item status::::: :::: :::: $status');
      final Uri url = Uri.parse('${AdminURLs.changeItemStatus}/$id');
      var response = await http.post(url, headers: headers, body: body);
      print('orderItem status ;;;;;;; ${response.body}');
      if (response.statusCode != 200) {
        throw Exception('error: ${response.statusCode}');
      }
      return response;
    } catch (error) {
      rethrow;
    }
  }
}
