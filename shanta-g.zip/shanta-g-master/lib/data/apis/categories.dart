import 'dart:convert';

import 'package:http/http.dart' as http;

import '/data/constant/http_methods.dart';

class CategoriesApi {
  Future<http.Response> getAll(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> getById(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> add(String url, body) async {
    try {
      // var body = json.encode({"name": catName});
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> update(String url, body) async {
    try {
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> deleteById(String url) async {
    try {
      return await delete(url: url);
    } catch (error) {
      rethrow;
    }
  }
}
