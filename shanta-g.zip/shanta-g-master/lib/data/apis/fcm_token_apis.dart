import 'dart:convert';

import 'package:http/http.dart' as http;
import '/data/constant/constant.dart';

import '/data/constant/storage/secure_storage.dart';


class FCMTokenApis {


  Future<http.Response> postFCMToken(String fcmToken) async {
    try {
      Map<String, String> headers = {
        'accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      };
      Map<String, dynamic> body = {
        'token': fcmToken,
      };
      print('start api ==================================$fcmToken');
      Uri url = Uri.parse('$baseURL/fcm-token');
      var response = await http.post(url, headers: headers, body: json.encode(body));
      print('-----------------------------------------');
      print(response.statusCode);
      print('-----------------------------------------');
      if (response.statusCode != 200) {
        throw Exception('error : ${response.statusCode}');
      }
      return response;
    } catch (error) {
      rethrow;
    }
  }
}
