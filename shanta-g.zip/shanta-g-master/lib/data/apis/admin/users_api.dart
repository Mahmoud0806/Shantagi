import 'dart:convert';

import 'package:http/http.dart' as http;
import '/data/constant/headers.dart';

import '/data/constant/http_methods.dart';

class UsersApi {
  Future<http.Response> getAll(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> getById(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> create(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body, headers: {...headersWithContent});
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> update(String url, var bodyData , {Map<String , String>? headers}) async {
    try {
      // var body = json.encode(bodyData);
      var response =  await post(url: url, body: bodyData, headers: headers);
      print('res : :  : ${response.body}');
      return response;
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> changeType(String url) async {
    try {
      // var body = json.encode(bodyData);
      var response =  await post(url: url);
      print('res : :  : ${response.body}');
      return response;
    } catch (error) {
      rethrow;
    }
  }



  Future<http.Response> deleteUser(String url) async {
    try {
      return await delete(
        url: url,
      );
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> switchUser(String url) async {
    try {
      return await post(url: url);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> addUserClients(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> getUserClients(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }
}
