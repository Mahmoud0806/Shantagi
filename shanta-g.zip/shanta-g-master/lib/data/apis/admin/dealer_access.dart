import 'dart:convert';

import 'package:http/http.dart' as http;

import '/data/constant/constant.dart';
import '/data/constant/http_methods.dart';

class DealerAccessApi {
  Future<http.Response> setAccess(String url, var body) async {
    try {
      return await post(url: url, body: json.encode(body), headers: {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      });
    } catch (e) {
      rethrow;
    }
  }

  Future<http.Response> getAccess(String url) async {
    try {
      return await get(url: url);
    } catch (e) {
      rethrow;
    }
  }

  Future<http.Response> getDealers(String url) async {
    try {
      return await get(url: url);
    } catch (e) {
      rethrow;
    }
  }


// Future<http.Response> setDealerRetailers (String url, var body) async {
//   try {
//     return await post(url: url, body: json.encode(body));
//   } catch (e) {
//     rethrow;
//   }
// }
// Future<http.Response> getDealerRetailers (String url) async {
//   try {
//     return await get(url: url);
//   } catch (e) {
//     rethrow;
//   }
// }
}
