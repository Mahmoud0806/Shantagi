import 'package:http/http.dart' as http;

import '/data/constant/http_methods.dart';

class ReportApi {
  Future<http.Response> getReport(String url) async {
    try {
      return await get(url: url);
    } catch (e) {
      rethrow;
    }
  }
}
