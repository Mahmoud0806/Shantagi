import 'dart:convert';

import 'package:http/http.dart' as http;

import '/data/constant/http_methods.dart';

class DealersVisibilityApi {
  Future<http.Response> change(String url, var bodyData) async {
    try {
      var body = json.encode(bodyData);
      return await post(url: url, body: body);
    } catch (error) {
      rethrow;
    }
  }

  Future<http.Response> getAppearance(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }
}
