import 'package:http/http.dart' as http;
import '../constant/http_methods.dart';

class RetailerDealersApi {
  Future<http.Response> getAll(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }
}