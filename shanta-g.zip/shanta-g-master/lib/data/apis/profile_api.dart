import 'package:http/http.dart' as http;

import '/data/constant/http_methods.dart';

class ProfileApi {
  Future<http.Response> getProfile(String url) async {
    try {
      return await get(url: url);
    } catch (error) {
      rethrow;
    }
  }
}
