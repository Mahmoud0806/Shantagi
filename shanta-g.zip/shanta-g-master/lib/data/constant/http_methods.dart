import 'dart:convert';

import 'package:http/http.dart' as http;

import '/data/constant/constant.dart';
import '/data/exceptions/http_exception.dart';
import '/models/product/product.dart';

// Future<http.Response> postWithOutAuth({required String url, required var body,Map<String, String>? headers}) async {
//   try {
//     final Uri uri = Uri.parse(url);
//     var response = await http.post(uri, headers: headers, body: body);
//     print(response.statusCode);
//     checkResponseStatus(response);
//     return response;
//   } catch (error) {
//     rethrow;
//   }
// }

Future<String> postProduct(
    {required String url,
    required Product body,
    required String filePath}) async {
  try {
    final Uri uri = Uri.parse(url);
    var request = http.MultipartRequest("POST", uri);
    var img = await http.MultipartFile.fromPath("image", filePath);
    request.files.add(img);
    // request.fields.addAll({
    //   'image': filePath,
    // });
    request.headers.addAll({
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token',
    });
    String result = body.sizes.join(',');
    print('cat to send ${body.category}');
    print('kar to send ${body.karat}');
    print('dealer to send ${body.user.id}');
    print('file to send ${filePath}');
    request.fields.addAll({
      'name': body.name,
      'description': body.description,
      'karat': body.karat.toString(),
      'weight': body.weight.toString(),
      'category_id': body.category,
      'wholesaler_id': body.user.id.toString(),
      'size': result,
    });
    var response = await request.send();
    var responseData = await http.Response.fromStream(response);
    var responseString = const Utf8Decoder().convert(responseData.bodyBytes);
    return responseString;
  } catch (error) {
    rethrow;
  }
}

Future<http.Response> post(
    {required String url, var body, Map<String, String>? headers}) async {
  try {
    final Uri uri = Uri.parse(url);
    var response = await http.post(uri,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: body);
    print(response.statusCode);
    print(json.decode(response.body));
    checkResponseStatus(response);
    return response;
  } catch (error) {
    rethrow;
  }
}

Future<http.Response> get(
    {required String url, Map<String, String>? headers}) async {
  try {
    final Uri uri = Uri.parse(url);
    print(url);
    var response = await http.get(uri,
        headers: headers ??
            {
              'Accept': 'application/json',
              'Authorization': 'bearer $token',
            });
    print(response.body);
    print(response.statusCode);
    checkResponseStatus(response);
    return response;
  } catch (error) {
    rethrow;
  }
}

Future<http.Response> delete({required String url}) async {
  try {
    final Uri uri = Uri.parse(url);
    var response = await http.delete(uri, headers: {
      'Accept': 'application/json',
      'Authorization': 'Bearer $token',
    });
    print(response.statusCode);
    checkResponseStatus(response);
    return response;
  } catch (error) {
    rethrow;
  }
}
