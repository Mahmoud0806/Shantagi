


import 'constant.dart';

class EndPoints {
  static  String login = '$baseURL/login';
  static  String logOut ='$baseURL/logout';

  static  String allCategories = '$baseURL/categories';
  static  String deleteCategory ='$baseURL/admin/categories/destroy/';
  static  String updateCategory ='$baseURL/admin/categories/update/';
  static  String addCategory =   '$baseURL/admin/categories';

  // static  String searchWholesalers = '/admin/search/wholesalers';
  // static  String searchRetailer = '/admin/search/retailers';
  static  String searchProducts = '$baseURL/admin/search/products';

  static  String allWholesalers = '$baseURL/admin/wholesalers';
  static  String deleteWholesalers = '$baseURL/admin/wholesalers/destroy/';
  static  String updateWholesalers = '$baseURL/admin/wholesalers/update/';
  static  String addWholesalers = '$baseURL/admin/wholesalers';

  static  String allRetailers = '$baseURL/admin/retailers';
  static  String deleteRetailers = '$baseURL/admin/retailers/destroy/';
  static  String updateRetailers = '$baseURL/admin/retailers/update/';
  static  String addRetailers = '$baseURL/admin/retailers';

  static  String adminAllProducts = '$baseURL/admin/products';
  static  String adminDeleteProducts = '$baseURL/admin/products/destroy/';
  static  String adminUpdateProducts = '$baseURL/admin/products/update/';
  static  String addProduct = '$baseURL/admin/products';
  static  String showProduct ='$baseURL/admin/products/';
  static  String addImage =   '$baseURL/admin/products/icons/add/';
  static  String deleteImage ='$baseURL/admin/products/icons/delete/';

  static  String adminAllOrders = '$baseURL/admin/orders';
  static  String adminChangeOrderStatus = '$baseURL/admin/orders/change_status/';
  static  String adminChangeShowWholesalerStatus =
      '$baseURL/admin/settings/change_wholesaler_appearance';
  static  String adminGetShowWholesalerStatus =
      '$baseURL/admin/settings/wholesaler_appearance';
  static  String adminAddUserPermissions =
      '$baseURL/admin/retailers/add-wholesalers';

  static  String adminAddClient = '$baseURL/admin/users';
  static  String showAllClient = '$baseURL/admin/users';

  static  String wholesalerProfile = '$baseURL/wholesalers/profile';
  static  String wholesalerAllProducts = '$baseURL/wholesalers/products/all';
  static  String wholesalerDeleteProducts = '$baseURL/admin/products/destroy/';
  static  String wholesalerUpdateProducts = '$baseURL/admin/products/update/';

  static  String holdProduct = '$baseURL/wholesalers/products/hold/';
  static  String releaseProduct = '$baseURL/wholesalers/products/release/';

  static  String wholesalerAllOrders = '$baseURL/wholesalers/orders/all';
  static  String wholesalerAcceptOrRefuseOrderStatus =
      '$baseURL/wholesalers/orders/accept_refuse_order_details/';

  static  String retailerProfile = '$baseURL/retailer/profile';
  static  String retailerAllWholesalers = '$baseURL/retailer/wholesalers_list';
  static  String retailerAllOrders = '$baseURL/retailer/orders/all';
  static  String retailerAllProducts = '$baseURL/retailer/products/all';
  static  String confirmOrder = '$baseURL/retailer/orders/confirm_order';
}