import 'package:flutter/material.dart';

class AppColors {
  static const Color background = Color(0xFFFFFFFF);
  static const Color primary = Color(0xFF151E46);
  static const Color secondary = Color(0xFF151E46);
  static const Color secondarySec = Color(0xFFFFD049);
  static const Color primaryText = Color(0xFF151515);
  static const Color secondaryText = Color(0xFFe8e8e8);
  static const Color error = Color(0xFFFF4955);
  static const Color listTile = Color(0xFFD3D9EB);
}