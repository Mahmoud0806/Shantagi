import '/view/admin/home/screens/home/home.dart';
import '/view/users/client/home/client_home.dart';
import '/view/users/retailer/home/retailer_home.dart';
import '/view/users/shanta/home/shanta_home.dart';
import '/view/users/wholesaler/home/wholesaler_home.dart';

// const String baseURL = 'http://shntgi.aldrtest.sy/api';
// const String baseURL = 'http://192.168.1.171:8003/api';
const String baseURL = 'https://shanta-g.com/api';
late String token;
String userType = '';
Map<String, dynamic> types = {
  'admin': const AdminHome(),
  'shanta_trader': const ShantaHome(),
  'wholesaler': const WholesalerHome(),
  'retailer': const RetailerHome(),
  'client': const ClientHome(),
};
