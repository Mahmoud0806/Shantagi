import 'constant.dart';

Map<String, String> headersWithContent ={
  ...headersWithAuth,
  'Content-Type':'application/json',
};

Map<String, String> headersWithAuth ={
  'Accept':'application/json',
  'Authorization': 'Bearer $token',
};

Map<String, String> headers ={
  'Accept':'application/json',
};

