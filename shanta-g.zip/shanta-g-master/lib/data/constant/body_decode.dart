import 'dart:convert';

import 'package:http/http.dart' as http;

decodeResponse(Future<http.Response> response) async {
  var responseData = await response;
  return json.decode(responseData.body);
}
