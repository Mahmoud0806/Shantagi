import 'package:flutter_secure_storage/flutter_secure_storage.dart';

import '/data/constant/constant.dart';

class SecureStorage {
  static const FlutterSecureStorage _storage = FlutterSecureStorage();

  static storeToken(String userToken) async {
    token = userToken;
    await _storage.write(key: 'token', value: userToken);
  }

  static getToken() async {
    return await _storage.read(key: 'token') ?? '';
  }

  static removeToken() async {
    token = '';
    await _storage.delete(key: 'token');
  }

  static storeFCMToken(String fCMToken) async {
    await _storage.write(key: 'fCMToken', value: fCMToken);
  }

  static getFCMToken() async {
    await _storage.read(key: 'fCMToken');
  }

  static removeFCMToken() async {
    await _storage.delete(key: 'fCMToken');
  }

  static saveToLocal(Map<String, dynamic> data) async {
    SecureStorage.storeToken(data['token'] ?? '');
    SecureStorage.storeFCMToken(data['user']['fcm_token'] ?? '');
  }
}
