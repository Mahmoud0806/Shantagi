import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import '/models/product/product.dart';
import '/data/constant/storage/secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '/data/constant/constant.dart';

class LocalStorage {
  static const FlutterSecureStorage _storage = FlutterSecureStorage();
  static late SharedPreferences _prefs;

  static Future<SharedPreferences> init() async {
    _prefs = await SharedPreferences.getInstance();
    return _prefs;
  }

  static storeType(String type) async {
    await _prefs.setString('type', type);
  }

  static getType() async {
    return _prefs.get('type');
  }

  static removeType() async {
    await _prefs.remove('type');
  }

  static storeUserData(List<String> userData) async {
    await _prefs.setStringList('userData', userData);
  }

  static getUserData() async {
    return _prefs.getStringList('userData');
  }

  static removeUserData() async {
    await _prefs.remove('userData');
  }

  static saveToLocal(Map<String, dynamic> data) async {
    await SecureStorage.storeToken(data['token'] ?? '');
    await SecureStorage.storeFCMToken(data['user']['fcm_token'] ?? '');
    await LocalStorage.storeType(data['user']['type'] ?? '');
    await LocalStorage.storeUserData(modelUserData(data['user'] ?? ''));
    print('dta: $data');
  }

  static modelUserData(Map<String, dynamic> userData) {
    List<String> userDataList = [];
    userDataList.add(userData['name']);
    userDataList.add(userData['email']);
    userDataList.add(userData['phone'] ?? '');
    userDataList.add(userData['address'] ?? '');

    return userDataList;
  }

  static removeAllLocal() async {
    await SecureStorage.removeFCMToken();
    await SecureStorage.removeToken();
    await LocalStorage.removeType();
    await LocalStorage.removeUserData();
  }


// static storeName(String name) async {
//    await _prefs.setString('name', name);
//  }
//
//  static getName() async {
//    _prefs.get('name');
//  }
//
//  static removeName() async {
//    await _prefs.remove('name');
//  }
//
//  static storeEmail(String email) async {
//    await _prefs.setString('email', email);
//  }
//
//  static getEmail() async {
//    _prefs.get('email');
//  }
//
//  static removeEmail() async {
//    await _prefs.remove('email');
//  }
//
//  static storePhone(String phone) async {
//    await _prefs.setString('phone', phone);
//  }
//
//  static getPhone() async {
//    _prefs.get('phone');
//  }
//
//  static removePhone() async {
//    await _prefs.remove('phone');
//  }
//
//  static storeAddress(String address) async {
//    await _prefs.setString('address', address);
//  }
//
//  static getAddress() async {
//    _prefs.get('address');
//  }
//
//  static removeAddress() async {
//    await _prefs.remove('address');
//  }
}
