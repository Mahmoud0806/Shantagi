import 'package:shared_preferences/shared_preferences.dart';

import '/models/cart/cart_item.dart';

class CartStorage {
  static late SharedPreferences prefs;

  static addToCart(CartItem cartItem) async {
    var oldKeys = await _getProductsKeys() ?? [];
    List<String> keys = [...oldKeys, cartItem.id.toString()];
    _setProductsKeys(keys);
    _storeItemData(cartItem.id.toString(), cartItem);
  }

  static getCart() async {
    List<String> keys = await _getProductsKeys();
    List products = [];
    for (String key in keys) {
      products.add(await _getItemData(key));
    }
    print(products);
    return products;
  }

  static removeFromCart(id) async {
    List<String> keys = await _getProductsKeys();
    for (String key in keys) {
      if (key == id.toString()) {
        keys.remove(key);
        _removeProductData(key);
      }
    }
    _setProductsKeys(keys);
  }

  static _removeProductData(key) async {
    await prefs.remove(key);
  }

  static _setProductsKeys(List<String> productsKeys) async {
    await prefs.setStringList('cart', productsKeys);
  }

  static Future<List<String>> _getProductsKeys() async {
    // return [];
    return prefs.getStringList('cart') ?? [];
  }

  static _getItemData(key) async {
    return prefs.getStringList(key);
  }

  static _storeItemData(id, CartItem cartItem) async {
    await prefs.setStringList(
      id,
      _modelItemData(cartItem.toMap()),
    );
  }

  static _modelItemData(Map<String, dynamic> productData) {
    List<String> productDataList = [];
    productDataList.add(productData['name']);
    productDataList.add(productData['size']);
    productDataList.add(productData['amount'] ?? '');
    productDataList.add(productData['imageLink'] ?? '');
    productDataList.add(productData['itemNotes'] ?? '');

    return productDataList;
  }
}
