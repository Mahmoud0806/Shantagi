import '/view/global_elements/profile/profile_screen.dart';
import '/view/users/client/home/client_home.dart';
import '/view/users/client/orders/client_orders.dart';
import '/view/users/client/products/products.dart';
import '/view/users/retailer/orders/orders_screen.dart';
import '/view/users/retailer/products/products.dart';
import '/view/users/shanta/orders/shanta_orders.dart';
import '/view/users/shanta/products/products.dart';
import '/view/users/wholesaler/orders/wholesaler_orders.dart';
import '/view/users/wholesaler/products/products.dart';

var usersScreens =  {
  // 'admin': ClientHome(),
  'shanta': const ClientHome(),
  'wholesaler': const ClientHome(),
  'retailer': const ClientHome(),
  'client': const ClientHome(),
};

List _adminScreens = const [
  ProfileScreen(),
];
List _shantaScreens = const [
  ShantaOrdersScreen(),
  ProfileScreen(),
  ShantaProductsScreen(),
];
List _wholesalerScreens = const [
  ProfileScreen(),
  WholesalerOrdersScreen(),
  WholesalerProductsScreen(),
];
List _retailerScreens = const [
  ProfileScreen(),
  RetailerProductsScreen(),
  RetailerOrdersScreen(),
];

List _clientScreens = const [
  ProfileScreen(),
  ClientProductsScreen(),
  ClientOrdersScreen(),
];
