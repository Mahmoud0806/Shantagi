List ordersStatus = [
  'new',
  'cancelled',
  'ready',
  'done',
];

List orderItemsStatus = [
  'pending',
  'accepted',
  'cancelled',
];

String setNewStatus(String status, List statuses){
  String newStatus = '';
  for( int i = 0; i <  statuses.length - 1; i ++){
    if(statuses[i] == status){
      newStatus = statuses[i+1];
      break;
    }
  }
  return newStatus;
}