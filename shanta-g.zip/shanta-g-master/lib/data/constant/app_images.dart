class AppImages {
  static const String hold = "assets/icons/global/hold.svg";
  static const String show = "assets/icons/global/show.svg";
  static const String person = "assets/icons/global/person.svg";

  static const String logo = "assets/icons/global/logo.svg";
  static const String trash = "assets/icons/global/trash.svg";

  static const String cartEmpty = "assets/icons/global/cart-empty.svg";
  static const String cartEmptyBackground =
      "assets/icons/global/cart-empty-background.svg";

  //nav Bar
  static const String bag = "assets/icons/nav_bar/bag.svg";
  static const String bagSelected = "assets/icons/nav_bar/bag-selected.svg";
  static const String home = "assets/icons/nav_bar/home.svg";
  static const String homeSelected = "assets/icons/home-selected.svg";
  static const String user = "assets/icons/nav_bar/user.svg";
  static const String userSelected = "assets/icons/nav_bar/user-selected.svg";

  static const String group = "assets/icons/global/group.svg";
  static const String diamond = "assets/icons/global/diamond.svg";
  static const String category = "assets/icons/global/category.svg";
}
