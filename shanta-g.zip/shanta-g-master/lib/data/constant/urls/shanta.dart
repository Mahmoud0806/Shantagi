import '/data/constant/constant.dart';

String _shantaURL = '$baseURL/shanta-trader';

class ShantaURLs {
  static String profile = '$_shantaURL/profile';

  static String allProducts = '$_shantaURL/products';
  static String addProduct = '$_shantaURL/products';
  static String updateProduct = '$_shantaURL/products';
  static String deleteProduct = '$_shantaURL/products';
  static String holdProduct = '$_shantaURL/products';
  static String addImage = '$_shantaURL/products/icons/add';
  static String deleteImage = '$_shantaURL/products/icons/delete';
  static String confirm(id) => '$_shantaURL/orders/$id/answer';

  static String allOrders = '$_shantaURL/orders';
  static String changeStatus = '$_shantaURL/orders';
}
