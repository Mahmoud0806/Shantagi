import '/data/constant/constant.dart';

const String _adminUrl = '$baseURL/admin';

class AdminURLs {
  static String allShanta = '$_adminUrl/shanta-traders';
  static String shanta = '$_adminUrl/shanta-traders';
  static String deleteShanta = '$_adminUrl/shanta-traders';
  static String updateShanta = '$_adminUrl/shanta-traders';
  static String changeShantaType = '$_adminUrl/shanta-traders';
  static String addShanta = '$_adminUrl/shanta-traders';

  static String allWholesalers = '$_adminUrl/wholesalers';
  static String wholesaler = '$_adminUrl/wholesaler';
  static String deleteWholesaler = '$_adminUrl/wholesalers';
  static String updateWholesaler = '$_adminUrl/wholesalers';
  static String addWholesaler = '$_adminUrl/wholesalers';

  static String allRetailers = '$_adminUrl/retailers';
  static String retailer = '$_adminUrl/retailers';
  static String deleteRetailer = '$_adminUrl/retailers';
  static String updateRetailer = '$_adminUrl/retailers';
  static String addRetailer = '$_adminUrl/retailers';
  static String retailerOrders = '$_adminUrl/orders';

  static String allClients = '$_adminUrl/clients';
  static String client = '$_adminUrl/clients';
  static String addClient = '$_adminUrl/clients';
  static String deleteClient = '$_adminUrl/clients';
  static String updateClient = '$_adminUrl/clients';
  static String clientOrders = '$_adminUrl/clients/orders';

  static String allCategories = '$baseURL/categories';
  static String createCategory = '$_adminUrl/categories';
  static String updateCategory = '$_adminUrl/categories';
  static String deleteCategory = '$_adminUrl/categories';

  static String allOrders = '$_adminUrl/orders';
  static String confirm(id) => '$_adminUrl/clients/orders/$id/answer';
  static String changeRetailerOrderStatus = '$_adminUrl/orders';
  static String changeClientOrderStatus = '$_adminUrl/clients/orders';
  static String changeItemStatus = '$_adminUrl/orders/item/change_status';
  static String addUserPermissions = '$_adminUrl/retailers/add-wholesalers';
  static String changeShowWholesaler =
      '$_adminUrl/settings/change_wholesaler_appearance';
  static String setShowWholesaler = '$_adminUrl/settings/wholesaler_appearance';

  static String allProducts = '$_adminUrl/products';
  static String showProduct = '$_adminUrl/products/';
  static String createProduct = '$_adminUrl/products';
  static String updateProduct = '$_adminUrl/products';
  static String deleteProduct = '$_adminUrl/products';
  static String addImage = '$_adminUrl/products/icons/add/';
  static String deleteImage = '$_adminUrl/products/icons/delete/';

  static String toggleVisibility = '$_adminUrl/settings/visibility';
  static String getVisibility = '$_adminUrl/settings/visibility';

  static String retailerAccess = '$_adminUrl/retailers';
  static String  dealerAccess = '$_adminUrl/wholesalers';
  static String allDealers = '$_adminUrl/dealers';

  static String report = '$_adminUrl/report/download';
}
