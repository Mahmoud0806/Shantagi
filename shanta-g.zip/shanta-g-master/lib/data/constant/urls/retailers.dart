import '/data/constant/constant.dart';

const String _retailersURL = '$baseURL/retailer';

class RetailersURLs {
  static String profile = '$_retailersURL/profile';

  static String allDealers = '$_retailersURL/dealers';

  static String allProducts = '$_retailersURL/products';

  static String allOrders = '$_retailersURL/orders/all';
  static String itemStatus(int id) => '$_retailersURL/orders/items/$id/status';
  static String confirmOrder = '$_retailersURL/orders';
}
