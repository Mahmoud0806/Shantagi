import '/data/constant/constant.dart';

const String _wholesalerURL = '$baseURL/wholesalers';

class WholesalersURLs {
  static String profile = '$_wholesalerURL/profile';

  static String allProducts = '$_wholesalerURL/products';

  static String allOrders = '$_wholesalerURL/orders';
  static String confirm(id) => '$_wholesalerURL/orders/$id/answer';
  static String changeOrderStatus =
      '$_wholesalerURL/orders/accept_refuse_order_details/';
}
