import '/data/constant/constant.dart';

const String _clientsURL = '$baseURL/client';

class ClientURLs {
  static String allProducts = '$_clientsURL/products';

  static String confirmOrder = '$_clientsURL/orders';
  static String allOrders = '$_clientsURL/orders';
  static String itemStatus(id) => '$_clientsURL/orders/item/$id/status';


  static String profile = '$_clientsURL/profile';
}
