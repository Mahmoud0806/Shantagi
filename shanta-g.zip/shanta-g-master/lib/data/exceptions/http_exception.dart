import 'package:http/http.dart' as http;
bool checkResponseStatus(http.Response response){
  if(response.statusCode != 200){
    throw Exception('error: ${response.statusCode}');
  }
  return true;
}