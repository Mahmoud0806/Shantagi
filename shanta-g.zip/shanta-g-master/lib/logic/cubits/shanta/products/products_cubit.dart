import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/shanta.dart';
import '/data/repos/products_repo.dart';
import '/models/custom_error.dart';
import '/models/product/product.dart';

part 'products_state.dart';

class ShantaProductsCubit extends Cubit<ShantaProductsState> {
  ShantaProductsCubit() : super(ShantaProductsState.initial());

  final _productsRepo = ProductsRepo();

  setActive(int index) {
    emit(state.copyWith(status: ShantaProductsStatus.loading));
    emit(state.copyWith(
      status: ShantaProductsStatus.success,
      product: state.products[index],
    ));
  }

  Future<void> getAll({String params = '', bool saveOld = false, bool savePage = false }) async {
    emit(state.copyWith(status: ShantaProductsStatus.loading));
    try {
      List<Product> products = [];
      products.addAll(await _productsRepo.getAllProducts(!saveOld
          ? "${ShantaURLs.allProducts}${params.isNotEmpty ? params : ''}"
          : "${ShantaURLs.allProducts}${params.isNotEmpty ? '$params&page=${state.pageNumber}' : '?page=${state.pageNumber}'}"));
      emit(state.copyWith(
        status: ShantaProductsStatus.success,
        products: saveOld ? [...state.products, ...products] : products,
        pageNumber:
            products.isNotEmpty ? state.pageNumber + 1 : state.pageNumber,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ShantaProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  // Future<void> create(Product product) async {
  //   emit(state.copyWith(status: ShantaProductsStatus.loading));
  //   try {
  //     await _productsRepo.create(ShantaURLs.addProduct, product);
  //     List<Product> products = addToLocal(state.products, product);
  //     emit(state.copyWith(
  //         status: ShantaProductsStatus.success, products: products));
  //   } on CustomError catch (e) {
  //     emit(state.copyWith(status: ShantaProductsStatus.error, error: e));
  //   } catch (e) {
  //     emit(state.copyWith(
  //         status: ShantaProductsStatus.error,
  //         error: CustomError(message: e.toString(), code: 0)));
  //   }
  // }

  Future<void> update(int id, Product product) async {
    emit(state.copyWith(status: ShantaProductsStatus.loading));
    try {
      await _productsRepo.update('${ShantaURLs.updateProduct}/$id', product);
      emit(state.copyWith(status: ShantaProductsStatus.success));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ShantaProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  List<Product> addToLocal(List<Product> products, Product product) {
    List<Product> newProducts = [];
    newProducts.addAll(products);
    newProducts.add(product);
    return newProducts;
  }

  Future<void> delete(int id) async {
    emit(state.copyWith(status: ShantaProductsStatus.loading));
    try {
      await _productsRepo.deleteById('${ShantaURLs.deleteProduct}/$id');
      List<Product> products = removeFromLocal(state.products, id);
      emit(state.copyWith(
          status: ShantaProductsStatus.success, products: products));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ShantaProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  List<Product> removeFromLocal(List<Product> products, int id) {
    List<Product> newProducts = [];
    newProducts.addAll(products);
    for (int i = 0; i < newProducts.length; i++) {
      if (newProducts[i].id == id) {
        newProducts.removeAt(i);
        return newProducts;
      }
    }
    return newProducts;
  }

  Future<void> addImage(int id, String image) async {
    emit(state.copyWith(status: ShantaProductsStatus.loading));
    try {
      await _productsRepo.addImage('${ShantaURLs.addImage}/$id', image);
      emit(state.copyWith(status: ShantaProductsStatus.success));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ShantaProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> removeImage(int id, int imageIndex) async {
    emit(state.copyWith(status: ShantaProductsStatus.loading));
    try {
      await _productsRepo.removeImage('${ShantaURLs.deleteImage}/$id');
      emit(state.copyWith(status: ShantaProductsStatus.success));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ShantaProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> changeHold(int id) async {
    emit(state.copyWith(status: ShantaProductsStatus.loading));
    try {
      await _productsRepo.changeHoldStatus(setUrl(id));
      emit(state.copyWith(status: ShantaProductsStatus.success));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ShantaProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  String setUrl(int id) {
    return '${ShantaURLs.holdProduct}/$id/hold';
  }
}
