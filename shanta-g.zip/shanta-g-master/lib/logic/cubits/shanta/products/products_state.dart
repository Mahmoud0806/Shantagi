part of 'products_cubit.dart';

enum ShantaProductsStatus {
  initial,
  loading,
  success,
  error,
}

class ShantaProductsState extends Equatable {
  final ShantaProductsStatus status;
  final List<Product> products;
  final Product product;
  final int pageNumber;
  final CustomError error;

  const ShantaProductsState({
    required this.status,
    required this.products,
    required this.product,
    required this.pageNumber,
    required this.error,
  });

  @override
  List<Object?> get props => [
        status,
        products,
        product,
        pageNumber,
        error,
      ];

  ShantaProductsState copyWith({
    ShantaProductsStatus? status,
    List<Product>? products,
    Product? product,
    int? pageNumber,
    CustomError? error,
  }) {
    return ShantaProductsState(
      status: status ?? this.status,
      products: products ?? this.products,
      product: product ?? this.product,
      pageNumber: pageNumber ?? this.pageNumber,
      error: error ?? this.error,
    );
  }

  factory ShantaProductsState.initial() {
    return ShantaProductsState(
      status: ShantaProductsStatus.initial,
      products: const [],
      product: Product.initial(),
      pageNumber: 1,
      error: CustomError.initial(),
    );
  }

  @override
  String toString() {
    return 'ShantaProductsState(status: $status, products: $products, product: $product, error: $error)';
  }
}
