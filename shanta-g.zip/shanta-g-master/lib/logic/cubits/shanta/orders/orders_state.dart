part of 'orders_cubit.dart';

enum ShantaOrdersStatus {
  initial,
  loading,
  success,
  error,
}

class ShantaOrdersState extends Equatable {
  final ShantaOrdersStatus status;
  final List<Order> orders;
  final Order order;
  final List<TextEditingController> itemsFields;
  final List<int?> itemsAmount;
  final CustomError error;

  const ShantaOrdersState({
    required this.status,
    required this.orders,
    required this.order,
    required this.itemsAmount,
    required this.itemsFields,
    required this.error,
  });

  factory ShantaOrdersState.initial() => ShantaOrdersState(
      status: ShantaOrdersStatus.initial,
      orders: const [],
      order: Order.initial(),
      error: CustomError.initial(),
      itemsAmount: const [null],
      itemsFields: const []);

  ShantaOrdersState copyWith({
    ShantaOrdersStatus? status,
    List<Order>? orders,
    Order? order,
    CustomError? error,
    List<int?>? itemsAmount,
    List<TextEditingController>? itemsFields,
  }) {
    return ShantaOrdersState(
      status: status ?? this.status,
      orders: orders ?? this.orders,
      order: order ?? this.order,
      error: error ?? this.error,
      itemsAmount: itemsAmount ?? this.itemsAmount,
      itemsFields: itemsFields ?? this.itemsFields,
    );
  }

  @override
  List<Object?> get props => [
        status,
        orders,
        order,
        error,
        itemsFields,
        itemsAmount,
      ];

  @override
  String toString() {
    return 'ShantaOrdersState{status: $status, orders: $orders, order: $order, error: $error, itemsAmount: $itemsAmount}';
  }
}
