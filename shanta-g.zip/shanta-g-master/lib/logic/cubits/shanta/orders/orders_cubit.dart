import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

import '/data/constant/urls/shanta.dart';
import '/data/repos/order_repo.dart';
import '/models/custom_error.dart';
import '/models/order/order.dart';

part 'orders_state.dart';

class ShantaOrdersCubit extends Cubit<ShantaOrdersState> {
  ShantaOrdersCubit() : super(ShantaOrdersState.initial());

  var _repo = OrdersRepo();

  void setActive(index) {
    emit(state.copyWith(order: state.orders[index]));
  }

  void fillAmountsFields(int length) {
    List<TextEditingController> fields = [];
    for(int i = 0 ; i < length; i++ ) {
      fields.add(TextEditingController());
    }
    emit(state.copyWith(itemsFields: fields));
  }
  
  Future<void> getAll() async {
    emit(state.copyWith(status: ShantaOrdersStatus.loading));
    try {
      final orders = await _repo.getUserOrders(ShantaURLs.allOrders);
      emit(state.copyWith(status: ShantaOrdersStatus.success, orders: orders));
    } on CustomError catch (e) {
      emit(state.copyWith(error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> changeStatus(int id, List<int> status) async {
    emit(state.copyWith(status: ShantaOrdersStatus.loading));
    try {
      await _repo.changeStatus(
          '${ShantaURLs.changeStatus}/$id/status', status);
      emit(state.copyWith(status: ShantaOrdersStatus.success));
    } on CustomError catch (e) {
      emit(state.copyWith(error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ShantaOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> confirmOrder() async {
    try {
      emit(state.copyWith(status: ShantaOrdersStatus.loading));

      await _repo.confirm(
          ShantaURLs.confirm(state.order.id), setItems());
      emit(state.copyWith(status: ShantaOrdersStatus.success));
    } catch (err) {
      emit(
        state.copyWith(
            status: ShantaOrdersStatus.error,
            error: CustomError(message: err.toString(), code: 0)),
      );
    }
  }

  setItems() {
    List items = [];
    for (int i = 0; i < state.order.orderItems.length; i++) {
      items.add({
        "id": state.order.orderItems[i].id,
        "acceptable_amount": state.itemsFields[i].text,
      });
    }
    return items;
  }
  
}
