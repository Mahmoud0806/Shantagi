part of 'home_cubit.dart';

enum HomeStatus {
  initial,
  loading,
  loaded,
  error,
  selected,
}

class HomeState extends Equatable {
  final HomeStatus status;
  final String userType;
  final List screens;
  final int index;
  final String error;

  const HomeState({
    required this.status,
    required this.userType,
    required this.screens,
    required this.index,
    required this.error,
  });

  factory HomeState.initial() => const HomeState(
        status: HomeStatus.initial,
        userType: '',
        screens: [],
        index: 1,
        error: '',
      );

  HomeState copyWith({
    HomeStatus? status,
    String? userType,
    List? screens,
    int? index,
    String? error,
  }) {
    return HomeState(
      status: status ?? this.status,
      userType: userType ?? this.userType,
      screens: screens ?? this.screens,
      index: index ?? this.index,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'HomeState{status: $status, userType: $userType, screensLength: $index, error: $error}';
  }

  @override
  List<Object> get props => [
        status,
        userType,
        screens,
        index,
        error,
      ];
}
