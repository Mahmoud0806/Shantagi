import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  HomeCubit() : super(HomeState.initial());

  changeIndex(int index) {
    emit(state.copyWith(status: HomeStatus.loading));
    emit(state.copyWith(index: index, status: HomeStatus.selected));
  }
  setScreens(List screens) {
    emit(state.copyWith(status: HomeStatus.loading));
    emit(state.copyWith(screens: screens, status: HomeStatus.selected));
  }
  setUser(String type) {
    emit(state.copyWith(status: HomeStatus.loading));
    emit(state.copyWith(userType: type, status: HomeStatus.selected));
  }

}
