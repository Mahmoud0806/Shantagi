import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/admin/report.dart';

part 'report_state.dart';

class ReportCubit extends Cubit<ReportState> {
  ReportCubit() : super(ReportState.initial());

  final _repo = ReportRepo();

  Future getReportFile() async {
    emit(state.copyWith(status: ReportStatus.loading));
    try {
      File file = await _repo.getReport(AdminURLs.report);

      emit(state.copyWith(status: ReportStatus.loaded, file: file));
    } catch (error) {
      emit(state.copyWith(status: ReportStatus.error));
    }
  }
}
