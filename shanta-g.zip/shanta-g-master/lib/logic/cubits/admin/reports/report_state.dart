part of 'report_cubit.dart';

enum ReportStatus {
  initial,
  loading,
  loaded,
  downloaded,
  downloading,
  error,
}

class ReportState extends Equatable {
  final String url;
  final File file;
  final String path;
  final String error;
  final ReportStatus status;

  const ReportState({
    required this.status,
    required this.url,
    required this.file,
    required this.path,
    required this.error,
  });

  factory ReportState.initial() => ReportState(
        status: ReportStatus.initial,
        url: '',
        file: File(''),
        path: '',
        error: '',
      );

  ReportState copyWith({
    String? url,
    File? file,
    String? path,
    String? error,
    ReportStatus? status,
  }) {
    return ReportState(
      url: url ?? this.url,
      file: file ?? this.file,
      path: path ?? this.path,
      error: error ?? this.error,
      status: status ?? this.status,
    );
  }

  @override
  String toString() {
    return 'ReportState{url: $url, file: $file, path: $path, error: $error, status: $status}';
  }

  @override
  List<Object> get props => [url, file, path, error, status];
}
