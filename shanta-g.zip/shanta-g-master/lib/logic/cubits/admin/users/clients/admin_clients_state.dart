part of 'admin_clients_cubit.dart';

enum ClientsStatus {
  initial,
  loading,
  success,
  updated,
  added,
  error,
}

class AdminClientsState extends Equatable {
  final ClientsStatus status;
  final List<User> clients;
  final User client;
  final String error;

  const AdminClientsState({
    required this.status,
    required this.clients,
    required this.client,
    required this.error,
  });

  factory AdminClientsState.initial() =>
      AdminClientsState(
        status: ClientsStatus.initial,
        clients: const [],
        client: User.initial(),
        error: '',
      );

  AdminClientsState copyWith({
    ClientsStatus? status,
    List<User>? clients,
    User? client,
    String? error,
  }) {
    return AdminClientsState(
      status: status ?? this.status,
      clients: clients ?? this.clients,
      client: client ?? this.client,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'AdminClientsState{status: $status, clients: $clients, client: $client, error: $error}';
  }

  @override
  List<Object> get props => [status, clients, client, error];
}
