import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/admin/users_repo.dart';
import '/models/user.dart';

part 'admin_clients_state.dart';

class AdminClientsCubit extends Cubit<AdminClientsState> {
  AdminClientsCubit() : super(AdminClientsState.initial());

  final _repo = UsersRepo();

  Future<void> getAll() async {
    emit(state.copyWith(status: ClientsStatus.loading));
    try {
      List<User> clients = await _repo.getAll(AdminURLs.allClients, 'clients');
      emit(state.copyWith(status: ClientsStatus.success, clients: clients));
    } catch (err) {
      emit(state.copyWith(status: ClientsStatus.error, error: err.toString()));
    }
  }

  Future<void> getById(int id) async {
    emit(state.copyWith(status: ClientsStatus.loading));
    try {
      await _repo.getById('${AdminURLs.client}/$id');
    } catch (err) {
      emit(state.copyWith(status: ClientsStatus.error, error: err.toString()));
    }
  }

  Future<void> create(User user) async {
    emit(state.copyWith(status: ClientsStatus.loading));
    try {
      await _repo.create(AdminURLs.addClient, user);
    } catch (err) {
      emit(state.copyWith(status: ClientsStatus.error, error: err.toString()));
    }
  }

  Future<void> update(user) async {
    emit(state.copyWith(status: ClientsStatus.loading));
    try {
      await _repo.update('${AdminURLs.updateClient}/${user.id}', user);
    } catch (err) {
      emit(state.copyWith(status: ClientsStatus.error, error: err.toString()));
    }
  }

  Future<void> delete(int id) async {
    emit(state.copyWith(status: ClientsStatus.loading));
    try {
      await _repo.delete('${AdminURLs.deleteClient}/$id');
    } catch (err) {
      emit(state.copyWith(status: ClientsStatus.error, error: err.toString()));
    }
  }
}
