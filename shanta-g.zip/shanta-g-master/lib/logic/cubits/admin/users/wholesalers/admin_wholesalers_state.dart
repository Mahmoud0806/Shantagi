part of 'admin_wholesalers_cubit.dart';

enum WholesalerStatus {
  initial,
  loading,
  success,
  created,
  updated,
  added,
  error,
}

class AdminWholesalersState extends Equatable {
  final WholesalerStatus status;
  final List<User> wholesalers;
  final List<DropdownMenuItem<String>> wholesalersItems;
  final User wholesaler;
  final DropdownMenuItem<String> wholesalerItem;
  final String error;

  const AdminWholesalersState({
    required this.status,
    required this.wholesalers,
    required this.wholesalersItems,
    required this.wholesaler,
    required this.wholesalerItem,
    required this.error,
  });

  factory AdminWholesalersState.initial() => AdminWholesalersState(
        status: WholesalerStatus.initial,
        wholesalers: const [],
        wholesalersItems: const <DropdownMenuItem<String>>[],
        wholesaler: User.initial(),
        wholesalerItem: const DropdownMenuItem<String>(
          child: Text(''),
        ),
        error: '',
      );

  AdminWholesalersState copyWith({
    WholesalerStatus? status,
    List<User>? wholesalers,
    List<DropdownMenuItem<String>>? wholesalersItems,
    DropdownMenuItem<String>? wholesalerItem,
    User? wholesaler,
    String? error,
  }) {
    return AdminWholesalersState(
      status: status ?? this.status,
      wholesalers: wholesalers ?? this.wholesalers,
      wholesalersItems: wholesalersItems ?? this.wholesalersItems,
      wholesaler: wholesaler ?? this.wholesaler,
      wholesalerItem: wholesalerItem ?? this.wholesalerItem,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'AdminWholesalersState{status: $status, wholesalers: $wholesalers, wholesaler: $wholesaler, error: $error}';
  }

  @override
  List<Object> get props => [status, wholesalers, wholesaler, error];
}
