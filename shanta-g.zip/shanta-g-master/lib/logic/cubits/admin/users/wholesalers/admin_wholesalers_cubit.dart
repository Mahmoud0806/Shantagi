import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/admin/users_repo.dart';
import '/models/user.dart';

part 'admin_wholesalers_state.dart';

class AdminWholesalersCubit extends Cubit<AdminWholesalersState> {
  AdminWholesalersCubit() : super(AdminWholesalersState.initial());
  final _repo = UsersRepo();

  selectDealerItem(String? newValue) {
    if (newValue == null) return;
    for (var wholesaler in state.wholesalersItems) {
      if (wholesaler.value == newValue) {
        print('equal: ${wholesaler.value}  $newValue');
        emit(state.copyWith(wholesalerItem: wholesaler, status: WholesalerStatus.updated));
      }
    }
  }

  Future<void> getAll() async {
    emit(state.copyWith(status: WholesalerStatus.loading));
    try {
      List<User> wholesalers =
          await _repo.getAll(AdminURLs.allWholesalers, 'wholesalers');
      List<DropdownMenuItem<String>> usersCats = setUserItems(wholesalers);
      emit(state.copyWith(
          status: WholesalerStatus.success,
          wholesalers: wholesalers,
          wholesalersItems: usersCats));
    } catch (err) {
      emit(state.copyWith(
          status: WholesalerStatus.error, error: err.toString()));
    }
  }

  List<DropdownMenuItem<String>> setUserItems(List<User> users) {
    List<DropdownMenuItem<String>> userItems = [];
    for (User user in users) {
      userItems.add(
        DropdownMenuItem(
          value: user.id.toString(),
          child: Text(user.name),
        ),
      );
    }
    return userItems;
  }

  Future<void> getById(int id) async {
    emit(state.copyWith(status: WholesalerStatus.loading));
    try {
      await _repo.getById('${AdminURLs.wholesaler}/$id');
      emit(state.copyWith(status: WholesalerStatus.success));
    } catch (err) {
      emit(state.copyWith(
          status: WholesalerStatus.error, error: err.toString()));
    }
  }

  Future<void> create(User user) async {
    emit(state.copyWith(status: WholesalerStatus.loading));
    try {
      await _repo.create(AdminURLs.addWholesaler, user);
      emit(state.copyWith(status: WholesalerStatus.created));
    } catch (err) {
      emit(state.copyWith(
          status: WholesalerStatus.error, error: err.toString().replaceAll('Exception:', '')));
    }
  }

  Future<void> update(user) async {
    emit(state.copyWith(status: WholesalerStatus.loading));
    try {
      await _repo.update('${AdminURLs.updateWholesaler}/${user.id}', user);
      emit(state.copyWith(status: WholesalerStatus.success));
    } catch (err) {
      emit(state.copyWith(
          status: WholesalerStatus.error, error: err.toString()));
    }
  }

  Future<void> changeType(id) async {
    emit(state.copyWith(status: WholesalerStatus.loading));
    try {
      await _repo.changeType('${AdminURLs.updateWholesaler}/$id/switch');
      emit(state.copyWith(status: WholesalerStatus.success));
    } catch (err) {
      emit(state.copyWith(
          status: WholesalerStatus.error, error: err.toString()));
    }
  }

  Future<void> delete(int id) async {
    emit(state.copyWith(status: WholesalerStatus.loading));
    try {
      await _repo.delete('${AdminURLs.deleteWholesaler}/$id');
    } catch (err) {
      emit(state.copyWith(
          status: WholesalerStatus.error, error: err.toString()));
    }
  }
}
