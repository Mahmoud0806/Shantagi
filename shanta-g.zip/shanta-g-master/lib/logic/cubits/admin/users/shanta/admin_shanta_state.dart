part of 'admin_shanta_cubit.dart';

enum ShantaStatus {
  initial,
  loading,
  success,
  created,
  updated,
  added,
  error,
}

class AdminShantaState extends Equatable {
  final ShantaStatus status;
  final List<User> shantas;
  final User shanta;
  final String error;

  const AdminShantaState({
    required this.status,
    required this.shantas,
    required this.shanta,
    required this.error,
  });

  factory AdminShantaState.initial() =>
      AdminShantaState(
        status: ShantaStatus.initial,
        shantas: const [],
        shanta: User.initial(),
        error: '',
      );

  AdminShantaState copyWith({
    ShantaStatus? status,
    List<User>? shantas,
    User? shanta,
    String? error,
  }) {
    return AdminShantaState(
      status: status ?? this.status,
      shantas: shantas ?? this.shantas,
      shanta: shanta ?? this.shanta,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'AdminShantaState{status: $status, shantas: $shantas, shanta: $shanta, error: $error}';
  }

  @override
  List<Object> get props => [status, shantas, shanta, error];
}
