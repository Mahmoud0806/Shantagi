import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/admin/users_repo.dart';
import '/models/user.dart';

part 'admin_shanta_state.dart';

class AdminShantaCubit extends Cubit<AdminShantaState> {
  AdminShantaCubit() : super(AdminShantaState.initial());

  final _repo = UsersRepo();

  Future<void> getAll() async {
    emit(state.copyWith(status: ShantaStatus.loading));
    try {
      List<User> shantas =
          await _repo.getAll(AdminURLs.allShanta, 'shanta_traders');
      emit(state.copyWith(status: ShantaStatus.success, shantas: shantas));
    } catch (err) {
      emit(state.copyWith(status: ShantaStatus.error, error: err.toString()));
    }
  }

  Future<void> getById(int id) async {
    emit(state.copyWith(status: ShantaStatus.loading));
    try {
      await _repo.getById('${AdminURLs.client}/$id');
    } catch (err) {
      emit(state.copyWith(status: ShantaStatus.error, error: err.toString().replaceAll('Exception: ', '')));
    }
  }

  Future<void> create(User user) async {
    emit(state.copyWith(status: ShantaStatus.loading));
    try {
      await _repo.create(AdminURLs.addShanta, user);
    emit(state.copyWith(status: ShantaStatus.created));
    } catch (err) {
      emit(state.copyWith(status: ShantaStatus.error, error: err.toString()));
    }
  }

  Future<void> update(user) async {
    emit(state.copyWith(status: ShantaStatus.loading));
    try {
      await _repo.update('${AdminURLs.updateShanta}/${user.id}', user);
    emit(state.copyWith(status: ShantaStatus.updated));
    } catch (err) {
      print('error :: ;: $err');
      emit(state.copyWith(status: ShantaStatus.error, error: err.toString()));
    }
  }
  Future<void> changeType(id) async {
    emit(state.copyWith(status: ShantaStatus.loading));
    try {
      await _repo.changeType('${AdminURLs.changeShantaType}/$id/switch');
      emit(state.copyWith(status: ShantaStatus.updated));
    } catch (err) {
      emit(state.copyWith(
          status: ShantaStatus.error, error: err.toString()));
    }
  }

  Future<void> delete(int id) async {
    emit(state.copyWith(status: ShantaStatus.loading));
    try {
      await _repo.delete('${AdminURLs.deleteShanta}/$id');
    } catch (err) {
      emit(state.copyWith(status: ShantaStatus.error, error: err.toString()));
    }
  }
}
