part of 'admin_retailers_cubit.dart';

enum RetailersStatus {
  initial,
  loading,
  success,
  updated,
  added,
  error,
}

class AdminRetailersState extends Equatable {
  final RetailersStatus status;
  final List<User> retailers;
  final User retailer;
  final String error;

  const AdminRetailersState({
    required this.status,
    required this.retailers,
    required this.retailer,
    required this.error,
  });

  factory AdminRetailersState.initial() =>
      AdminRetailersState(
        status: RetailersStatus.initial,
        retailers: const [],
        retailer: User.initial(),
        error: '',
      );

  AdminRetailersState copyWith({
    RetailersStatus? status,
    List<User>? retailers,
    User? retailer,
    String? error,
  }) {
    return AdminRetailersState(
      status: status ?? this.status,
      retailers: retailers ?? this.retailers,
      retailer: retailer ?? this.retailer,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'AdminRetailersState{status: $status, retailers: $retailers, retailer: $retailer, error: $error}';
  }

  @override
  List<Object> get props => [status, retailers, retailer, error];
}
