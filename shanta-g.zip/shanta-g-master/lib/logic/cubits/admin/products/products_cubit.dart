import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_picker/image_picker.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/products_repo.dart';
import '/models/custom_error.dart';
import '/models/product/product.dart';
import '/models/product/product_image.dart';

part 'products_state.dart';

class ProductsCubit extends Cubit<ProductsState> {
  ProductsCubit() : super(ProductsState.initial());
  var nameController = TextEditingController();
  var descController = TextEditingController();
  var weightController = TextEditingController();
  var karatController = TextEditingController();
  var sizeController = TextEditingController();

  final _repo = ProductsRepo();
  final picker = ImagePicker();
  XFile pickedFile = XFile('');
  String selectedImage = '';

  void clearControllers() {
    emit(state.copyWith(status: ProductsStatus.loading));
    nameController.clear();
    descController.clear();
    weightController.clear();
    sizeController.clear();
    karatController.clear();
    emit(state.copyWith(status: ProductsStatus.loaded, sizes: []));
  }

  void addSize(size) {
    emit(state.copyWith(status: ProductsStatus.loading));
    List<String> sizes = [...state.sizes, size];
    emit(state.copyWith(status: ProductsStatus.loaded, sizes: sizes));
  }

  void removeSize(index) {
    emit(state.copyWith(status: ProductsStatus.loading));
    List<String> sizes = [...state.sizes];
    sizes.removeAt(index);
    emit(state.copyWith(status: ProductsStatus.loaded, sizes: sizes));
  }

  void addKarat(karat) {
    emit(state.copyWith(status: ProductsStatus.loading));
    List<String> karats = [...state.karat, karat];
    emit(state.copyWith(status: ProductsStatus.loaded, karat: karats));
  }

  void removeKarat(index) {
    emit(state.copyWith(status: ProductsStatus.loading));
    List<String> karats = [...state.karat];
    karats.removeAt(index);
    emit(state.copyWith(status: ProductsStatus.loaded, karat: karats));
  }

  Future getImage() async {
    pickedFile = await picker.pickImage(
          source: ImageSource.gallery,
        ) ??
        XFile('');
    if (pickedFile.path != '') {
      selectedImage = pickedFile.path;
      print(selectedImage);
    }
    emit(
      state.copyWith(
        product: state.product.copyWith(
          images: [
            ...state.product.images,
            ProductImage(id: -10000, attachment: selectedImage),
          ],
        ),
      ),
    );
  }

  String setParams(Map<String, String> values) {
    String params = '';
    for (String key in keys) {
      if (values[key] != null) {
        params += '$key=${values[key]}&';
      }
    }
    if (params.isNotEmpty) {
      return '?$params';
    }
    return '';
  }

  List keys = [
    'name',
    'wholesaler',
    'category',
    'hold',
    'karat',
  ];

  Future<void> getAll({String params = '', bool saveOld = false, bool savePage = false }) async {
    emit(state.copyWith(status: ProductsStatus.loading));
    try {
      List<Product> products = [];
      products.addAll(await _repo.getAll(
        !saveOld
            ? "${AdminURLs.allProducts}${params.isNotEmpty ? params : ''}"
            : "${AdminURLs.allProducts}${params.isNotEmpty ? '$params&page=${state.pageNumber}' : '?page=${state.pageNumber}'}",
      ));
      emit(
        state.copyWith(
          status: ProductsStatus.loaded,
          products: saveOld ? [...state.products, ...products] : products,
          pageNumber: !savePage ? 2 :
              products.isNotEmpty ? state.pageNumber + 1 : state.pageNumber,
        ),
      );
    } on CustomError catch (e) {
      emit(state.copyWith(status: ProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> deleteProduct(int id) async {
    emit(state.copyWith(status: ProductsStatus.loading));
    try {
      await _repo.deleteById('${AdminURLs.deleteProduct}/$id');
      emit(state.copyWith(status: ProductsStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> updateProduct(int id, Product product) async {
    emit(state.copyWith(status: ProductsStatus.loading));
    try {
      await _repo.update('${AdminURLs.updateProduct}/$id', product);
      emit(state.copyWith(status: ProductsStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> createProduct(Product product, String path,
      {String? url}) async {
    emit(state.copyWith(status: ProductsStatus.loading));
    try {
      await _repo.createProduct(url ?? AdminURLs.createProduct, product, path);
      emit(state.copyWith(status: ProductsStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> addImage(var image) async {
    emit(state.copyWith(status: ProductsStatus.loading));
    try {
      await _repo.addImage(AdminURLs.addImage, image);
      emit(state.copyWith(status: ProductsStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> removeImage(var image) async {
    emit(state.copyWith(status: ProductsStatus.loading));
    try {
      await _repo.removeImage(AdminURLs.deleteImage);
      emit(state.copyWith(status: ProductsStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }
}
