part of 'products_cubit.dart';

enum ProductsStatus {
  initial,
  loading,
  loaded,
  imageAdded,
  imageRemoved,
  error,
}

class ProductsState extends Equatable {
  final ProductsStatus status;
  final List<Product> products;
  final Product product;
  final int pageNumber;
  final List<String> sizes;
  final List<String> karat;
  final CustomError error;

  const ProductsState({
    required this.status,
    required this.products,
    required this.product,
    required this.pageNumber,
    required this.sizes,
    required this.karat,
    required this.error,
  });

  @override
  List<Object?> get props => [
        status,
        products,
        product,
    pageNumber,
        sizes,
        karat,
        error,
      ];

  ProductsState copyWith({
    ProductsStatus? status,
    List<Product>? products,
    Product? product,
    int? pageNumber,
    List<String>? sizes,
    List<String>? karat,
    CustomError? error,
  }) {
    return ProductsState(
      status: status ?? this.status,
      products: products ?? this.products,
      product: product ?? this.product,
      pageNumber: pageNumber ?? this.pageNumber,
      sizes: sizes ?? this.sizes,
      karat: karat ?? this.karat,
      error: error ?? this.error,
    );
  }

  factory ProductsState.initial() {
    return ProductsState(
      status: ProductsStatus.initial,
      products: const [],
      product: Product.initial(),
      pageNumber: 1,
      sizes: const [],
      karat: const [],
      error: CustomError.initial(),
    );
  }

  @override
  String toString() {
    return 'AdminProductsState{status: $status, products: $products, product: $product, error: $error}';
  }
}
