part of 'visibility_cubit.dart';

enum VisibilityStatus {
  initial,
  loading,
  loadingShanta,
  loadingWholesaler,
  loaded,
  visible,
  changed,
  hidden,
  error,
}

class VisibilityState extends Equatable {
  final VisibilityStatus status;
  final bool wholesalersVisibility;
  final bool shantaVisibility;
  final CustomError error;

  const VisibilityState({
    required this.status,
    required this.wholesalersVisibility,
    required this.shantaVisibility,
    required this.error,
  });

  @override
  List<Object?> get props => [
        status,
        wholesalersVisibility,
        shantaVisibility,
        error,
      ];

  VisibilityState copyWith({
    VisibilityStatus? status,
    bool? wholesalersVisibility,
    bool? shantaVisibility,
    CustomError? error,
  }) {
    return VisibilityState(
      status: status ?? this.status,
      wholesalersVisibility:
          wholesalersVisibility ?? this.wholesalersVisibility,
      shantaVisibility: shantaVisibility ?? this.shantaVisibility,
      error: error ?? this.error,
    );
  }

  static VisibilityState initial() {
    return VisibilityState(
      status: VisibilityStatus.initial,
      wholesalersVisibility: false,
      shantaVisibility: false,
      error: CustomError.initial(),
    );
  }

  @override
  String toString() {
    return 'DealerVisibilityState{status: $status, '
        'wholesalersVisibility: $wholesalersVisibility, '
        'shantaVisibility: $shantaVisibility, error: $error}';
  }
}
