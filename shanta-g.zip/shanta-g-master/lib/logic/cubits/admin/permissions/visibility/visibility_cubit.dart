import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/admin/dealers_visibility.dart';
import '/models/custom_error.dart';

part 'visibility_state.dart';

class VisibilityCubit extends Cubit<VisibilityState> {
  VisibilityCubit() : super(VisibilityState.initial());
  final _repo = DealersVisibilityRepo();

  Future<void> toggleVisibility(bool wholesaler, bool shanta) async {
    emit(state.copyWith(status: VisibilityStatus.loading));
    try {
      var body = await _repo.changeVisibility(
          AdminURLs.toggleVisibility, wholesaler, shanta).then((value) {
            getVisibility();
      });
      print('----- ----- ---- $body');
      emit(state.copyWith(
        status: VisibilityStatus.changed,
        wholesalersVisibility: body['data']['wholesaler'] == 1,
        shantaVisibility: body['data']['shanta'] == 1,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: VisibilityStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: VisibilityStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> getVisibility() async {
    emit(state.copyWith(status: VisibilityStatus.loading));
    try {
      var body = await _repo.getVisibility(AdminURLs.getVisibility);
      print('+++++++++++ c++++++++++$body');
      print('+++++++++++ c++++++++++${body["data"]["shanta"]}');
      print('+++++++++++ c++++++++++${body["data"]["wholesaler"]}');

      emit(state.copyWith(
        status: VisibilityStatus.loaded,
        wholesalersVisibility: body['data']['wholesaler'] == '1',
        shantaVisibility: body['data']['shanta'] == '1',
      ));
      print(state.shantaVisibility);
      print(state.wholesalersVisibility);
    } on CustomError catch (e) {
      emit(state.copyWith(status: VisibilityStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: VisibilityStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }
}
