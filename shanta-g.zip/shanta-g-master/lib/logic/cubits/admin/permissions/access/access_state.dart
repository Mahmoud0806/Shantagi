part of 'access_cubit.dart';

enum DealerAccessStatus {
  initial,
  loading,
  loaded,
  error,
  wholesalersEdited,
  shantasEdited,
  retailersEdited,
}

class DealerAccessState extends Equatable {
  final DealerAccessStatus status;
  final User shanta;
  final User wholesaler;
  final User retailer;
  final List<User> shantas;
  final List<User> wholesalers;
  final List<User> retailers;
  final List<bool> selectedShanta;
  final List<bool> selectedWholesalers;
  final List<bool> selectedRetailers;
  final List<bool> selectedShantaRetailers;
  final CustomError error;

  const DealerAccessState({
    required this.status,
    required this.shantas,
    required this.wholesalers,
    required this.retailers,
    required this.shanta,
    required this.wholesaler,
    required this.retailer,
    required this.selectedShanta,
    required this.selectedWholesalers,
    required this.selectedRetailers,
    required this.selectedShantaRetailers,
    required this.error,
  });

  @override
  List<Object?> get props => [
        status,
        retailers,
        shantas,
        shanta,
        wholesaler,
        retailer,
        wholesalers,
        selectedRetailers,
        selectedShantaRetailers,
        selectedWholesalers,
        selectedShanta,
        error,
      ];

  DealerAccessState copyWith({
    DealerAccessStatus? status,
    List<User>? shantas,
    List<User>? wholesalers,
    List<User>? retailers,
    User? shanta,
    User? wholesaler,
    User? retailer,
    List<bool>? selectedShanta,
    List<bool>? selectedWholesalers,
    List<bool>? selectedRetailers,
    List<bool>? selectedShantaRetailers,
    CustomError? error,
  }) {
    return DealerAccessState(
      status: status ?? this.status,
      shantas: shantas ?? this.shantas,
      wholesalers: wholesalers ?? this.wholesalers,
      retailers: retailers ?? this.retailers,
      shanta: shanta ?? this.shanta,
      wholesaler: wholesaler ?? this.wholesaler,
      retailer: retailer ?? this.retailer,
      selectedShanta: selectedShanta ?? this.selectedShanta,
      selectedWholesalers: selectedWholesalers ?? this.selectedWholesalers,
      selectedRetailers: selectedRetailers ?? this.selectedRetailers,
      selectedShantaRetailers:
          selectedShantaRetailers ?? this.selectedShantaRetailers,
      error: error ?? this.error,
    );
  }

  static DealerAccessState initial() {
    return DealerAccessState(
      status: DealerAccessStatus.initial,
      retailers: const [],
      shantas: const [],
      wholesalers: const [],
      retailer: User.initial(),
      shanta: User.initial(),
      wholesaler: User.initial(),
      selectedRetailers: const [],
      selectedShantaRetailers: const [],
      selectedWholesalers: const [],
      selectedShanta: const [],
      error: CustomError.initial(),
    );
  }

  @override
  String toString() {
    return 'DealerAccessState{status: $status, retailers: $retailers, '
        'shanta: $shantas, wholesalers: $wholesalers, selected: $selectedRetailers, '
        'error: $error}';
  }
}
