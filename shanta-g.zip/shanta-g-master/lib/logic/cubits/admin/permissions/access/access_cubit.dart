import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/admin/dealer_access.dart';
import '/models/custom_error.dart';
import '/models/user.dart';

part 'access_state.dart';

class DealerAccessCubit extends Cubit<DealerAccessState> {
  DealerAccessCubit() : super(DealerAccessState.initial());

  final _repo = DealerAccessRepo();

  Future<void> getDealers() async {
    emit(state.copyWith(
      status: DealerAccessStatus.loading,
    ));
    try {
      var users = await _repo.getDealers(AdminURLs.allDealers);
      emit(
        state.copyWith(
          status: DealerAccessStatus.loaded,
          shantas: users['shanta'] as List<User>,
          wholesalers: users['wholesalers'] as List<User>,
          retailers: users['retailers'] as List<User>,
          selectedWholesalers: users['selectedWholesalers'] as List<bool>,
          selectedShanta: users['selectedShanta'] as List<bool>,
          selectedRetailers: users['selectedRetailers'] as List<bool>,
          selectedShantaRetailers:
              users['selectedShantaRetailers'] as List<bool>,
        ),
      );
    } on CustomError catch (e) {
      emit(state.copyWith(status: DealerAccessStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: DealerAccessStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  void selectShanta(id) {
    int? index;
    for (int i = 0; i < state.retailers.length; i++) {
      if (state.shantas[i].id == int.parse(id)) {
        print('''object::: $i''');
        index = i;
      }
    }
    index != null
        ? emit(
            state.copyWith(
              status: DealerAccessStatus.wholesalersEdited,
              shanta: state.shantas[index],
            ),
          )
        : null;
  }

  void selectWholesaler(id) {
    int? index;
    for (int i = 0; i < state.retailers.length; i++) {
      if (state.wholesalers[i].id == int.parse(id)) {
        print('''object::: $i''');
        index = i;
      }
    }
    index != null
        ? emit(
            state.copyWith(
              status: DealerAccessStatus.wholesalersEdited,
              wholesaler: state.wholesalers[index],
            ),
          )
        : null;
  }

  void selectRetailer(id) {
    int? index;
    for (int i = 0; i < state.retailers.length; i++) {
      if (state.retailers[i].id == int.parse(id)) {
        print('''object::: $i''');
        index = i;
      }
    }
    index != null
        ? emit(
            state.copyWith(
              status: DealerAccessStatus.retailersEdited,
              retailer: state.retailers[index],
            ),
          )
        : null;
  }

  void editRetailerShanta(index) {
    List<bool> shanta = [...state.selectedShanta];
    shanta[index] = !shanta[index];
    emit(
      state.copyWith(
        status: DealerAccessStatus.shantasEdited,
        selectedShanta: shanta,
      ),
    );
  }

  void clearRetailers() {
    state.copyWith(selectedRetailers: [], status: DealerAccessStatus.loaded);
  }

  void editRetailerWholesalers(index) {
    List<bool> wholesalers = [...state.selectedWholesalers];
    wholesalers[index] = !wholesalers[index];
    emit(
      state.copyWith(
        status: DealerAccessStatus.wholesalersEdited,
        selectedWholesalers: wholesalers,
      ),
    );
  }

  void fillRetailers() {
    List<bool> selectedRetailers = [];
    for (var retailer in state.retailers) {
      selectedRetailers.add(false);
    }
    emit(state.copyWith(
      status: DealerAccessStatus.retailersEdited,
      selectedRetailers: selectedRetailers,
      selectedShantaRetailers: selectedRetailers,
    ));
  }

  void editRetailer(index) {
    List<bool> retailers = [...state.selectedRetailers];
    retailers[index] = !retailers[index];
    emit(
      state.copyWith(
        status: DealerAccessStatus.retailersEdited,
        selectedRetailers: retailers,
      ),
    );
  }

  void editShantaRetailers(index) {
    List<bool> retailers = [...state.selectedRetailers];
    retailers[index] = !retailers[index];
    emit(
      state.copyWith(
        status: DealerAccessStatus.retailersEdited,
        selectedRetailers: retailers,
      ),
    );
  }

  Future setRetailerAccess(int id, List<int> ids) async {
    emit(state.copyWith(
      status: DealerAccessStatus.loading,
    ));
    try {
      await _repo.setRetailerAccess(
          '${AdminURLs.retailerAccess}/dealers', id, ids);
      emit(state.copyWith(
        status: DealerAccessStatus.loaded,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: DealerAccessStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: DealerAccessStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> getRetailerAccess(int id) async {
    emit(state.copyWith(status: DealerAccessStatus.loading));
    try {
      deselectAllDealers();
      var users = await _repo
          .getRetailerAccess('${AdminURLs.retailerAccess}/$id/dealers');
      print('start selecting');
      List wholesalers = [...users['wholesalers']!];
      List shanta = [...users['shanta']!];
      print('mid selecting');
      List<bool> selectedWholesalers =
          getSelected(state.wholesalers, wholesalers);
      List<bool> selectedShanta = getSelected(state.shantas, shanta);
      print('end selecting');

      print('start emmit');
      emit(state.copyWith(
        status: DealerAccessStatus.loaded,
        selectedWholesalers: selectedWholesalers,
        selectedShanta: selectedShanta,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: DealerAccessStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: DealerAccessStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  List<bool> getSelected(users, selected) {
    print('---- selected $selected');
    print('-.--.-.-.--.-.-.- users $users');
    List<bool> finalResult = List.filled(users.length, false);
    for (int i = 0; i < selected.length; i++) {
      for (int j = 0; j < users.length; j++) {
        finalResult[j] = selected[i].id == users[j].id ? true : false;
        print(finalResult[j]);
      }
    }
    return finalResult;
  }

  deselectAllDealers() {
    List<bool> newWholesalers = deselectDealers(state.selectedWholesalers);
    List<bool> newShanta = deselectDealers(state.selectedShanta);
    emit(state.copyWith(
      selectedWholesalers: newWholesalers,
      selectedShanta: newShanta,
    ));
  }

  List<bool> deselectDealers(List<bool> dealers) {
    for (int i = 0; i < dealers.length; i++) {
      dealers[i] = false;
    }
    return dealers;
  }

  List<int> setSelectedDealers(List<User> dealers, List<bool> selected) {
    List<int> selectedIds = [];
    for (int i = 0; i < dealers.length; i++) {
      if (selected[i] == true) {
        selectedIds.add(dealers[i].id);
      }
    }
    print('selected IDs: $selectedIds');
    return selectedIds;
  }

  Future<void> setDealerAccess(int id, List<int> ids) async {
    emit(state.copyWith(status: DealerAccessStatus.loading));
    try {
      await _repo.setAccess('${AdminURLs.dealerAccess}/$id', id, ids);
      emit(state.copyWith(status: DealerAccessStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: DealerAccessStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: DealerAccessStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> getDealerAccess(int id) async {
    emit(state.copyWith(
      status: DealerAccessStatus.loading,
    ));
    try {
      deselectDealers(state.selectedRetailers);
      deselectDealers(state.selectedShantaRetailers);
      List<User> retailers =
          await _repo.getAccess('${AdminURLs.dealerAccess}/$id/retailers');
      List<bool> selected = [];
      for (int i = 0; i < state.retailers.length; i++) {
        if (retailers.length > i && retailers[i].id == state.retailers[i].id) {
          selected.add(true);
        } else {
          selected.add(false);
        }
      }
      emit(state.copyWith(
        status: DealerAccessStatus.loaded,
        selectedRetailers: selected,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: DealerAccessStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: DealerAccessStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  void selectAllRetailers(List users) {
    emit(state.copyWith(selectedRetailers: List.filled(users.length, true)));
  }

  void selectAllShantaRetailers(List users) {
    emit(state.copyWith(
        selectedShantaRetailers: List.filled(users.length, true)));
  }

  void selectAllWholesalers(List users) {
    emit(state.copyWith(selectedWholesalers: List.filled(users.length, true)));
  }

  void selectAllShanta(List users) {
    emit(state.copyWith(selectedShanta: List.filled(users.length, true)));
  }
}
