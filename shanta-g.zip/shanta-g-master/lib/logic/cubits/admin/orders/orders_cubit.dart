import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/order_repo.dart';
import '/models/custom_error.dart';
import '/models/order/order.dart';

part 'orders_state.dart';

class AdminOrdersCubit extends Cubit<AdminOrdersState> {
  AdminOrdersCubit() : super(AdminOrdersState.initial());
  final _repo = OrdersRepo();

  void fillAmountsFields(int length) {
    emit(state.copyWith(status: AdminOrdersStatus.loading));
    List<TextEditingController> fields = [];
    for (int i = 0; i < length; i++) {
      fields.add(TextEditingController());
    }
    print(fields.length);
    emit(state.copyWith(status: AdminOrdersStatus.loaded, itemsFields: fields));
  }

  void setActiveOrder(int index) {
    emit(state.copyWith(status: AdminOrdersStatus.loading));

    emit(state.copyWith(
        status: AdminOrdersStatus.loaded, order: state.orders[index]));
  }

  void setRetailerActiveOrder(int index) {
    emit(state.copyWith(status: AdminOrdersStatus.loading));

    emit(state.copyWith(
        status: AdminOrdersStatus.loaded, order: state.retailerOrders[index]));
  }

  Future<void> getAll(String url,
      {bool? isClient, String? params, bool? saveOld}) async {
    emit(state.copyWith(
      status: AdminOrdersStatus.loading,
    ));
    try {
      final orders = isClient == null
          ? await _repo.getAll(url +
              (params == null
                  ? (saveOld != null ? '?page=${state.retailerPageNumber}' : '')
                  : '$params${saveOld != null ? '&page=${state.retailerPageNumber}' : ''}'))
          : await _repo.getUserOrders(url +
              (params == null
                  ? (saveOld != null ? '?page=${state.pageNumber}' : '')
                  : '$params${saveOld != null ? '&page=${state.pageNumber}' : ''}'));
      print(orders.length);
      emit(state.copyWith(
        status: AdminOrdersStatus.loaded,
        pageNumber: isClient != null ? orders.isNotEmpty ? state.pageNumber + 1 : null : null,
        retailerPageNumber: isClient == null ? orders.isNotEmpty ? state.pageNumber + 1 : null : null,

        orders: isClient != null ? (saveOld != null ? [...state.orders, ...orders] :orders) : null,
        retailerOrders: isClient == null ? (saveOld != null ? [...state.retailerOrders, ...orders] :orders) : null,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: AdminOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: AdminOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> changeStatus(int id, String status, {bool? isClient}) async {
    emit(state.copyWith(
      status: AdminOrdersStatus.loading,
    ));
    try {
      await _repo.changeStatus(
          isClient != null && isClient != false
              ? '${AdminURLs.changeClientOrderStatus}/$id/status'
              : '${AdminURLs.changeRetailerOrderStatus}/$id/status',
          status);
      emit(state.copyWith(
        status: AdminOrdersStatus.loaded,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: AdminOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: AdminOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> changeItemStatus(int id, String status) async {
    emit(state.copyWith(
      status: AdminOrdersStatus.loading,
    ));
    try {
      await _repo.changeItemStatus('${AdminURLs.changeItemStatus}/$id', status);
      emit(state.copyWith(
        status: AdminOrdersStatus.loaded,
      ));
    } on CustomError catch (e) {
      emit(state.copyWith(status: AdminOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: AdminOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> confirmOrder() async {
    try {
      emit(state.copyWith(status: AdminOrdersStatus.loading));

      await _repo.confirm(AdminURLs.confirm(state.order.id), setItems());
      emit(state.copyWith(status: AdminOrdersStatus.loaded));
    } catch (err) {
      emit(
        state.copyWith(
            status: AdminOrdersStatus.error,
            error: CustomError(message: err.toString(), code: 0)),
      );
    }
  }

  setItems() {
    List items = [];
    for (int i = 0; i < state.order.orderItems.length; i++) {
      if (state.itemsFields[i].text.isEmpty) {}
      items.add({
        "id": state.order.orderItems[i].id,
        "acceptable_amount": state.itemsFields[i].text,
      });
    }
    return items;
  }

  int selectedItemIndex = -1000;

  Map<String, String> status = {
    'pending': 'قيد الأنتظار',
    'answered': 'تم الرد',
    'cancelled': 'ملغاة',
    'accepted': 'مقبول',
  };
  List<DropdownMenuItem<String>> orderItemStatus = [
    const DropdownMenuItem(value: "pending", child: Text("قيد الأنتظار")),
    const DropdownMenuItem(value: "answered", child: Text("تم الرد")),
    const DropdownMenuItem(value: "cancelled", child: Text("ملغاة")),
    const DropdownMenuItem(value: "accepted", child: Text("مقبول")),
  ];
}
