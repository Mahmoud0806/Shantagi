part of 'orders_cubit.dart';

enum AdminOrdersStatus {
  initial,
  loading,
  loaded,
  error,
}

class AdminOrdersState extends Equatable {
  final AdminOrdersStatus status;
  final List<Order> orders;
  final List<Order> retailerOrders;
  final Order order;
  final int pageNumber;
  final int retailerPageNumber;
  final List<TextEditingController> itemsFields;
  final CustomError error;

  const AdminOrdersState({
    required this.status,
    required this.orders,
    required this.retailerOrders,
    required this.order,
    required this.pageNumber,
    required this.retailerPageNumber,
    required this.itemsFields,
    required this.error,
  });

  AdminOrdersState copyWith({
    AdminOrdersStatus? status,
    List<Order>? orders,
    List<Order>? retailerOrders,
    List<TextEditingController>? itemsFields,
    Order? order,
    int? pageNumber,
    int? retailerPageNumber,
    CustomError? error,
  }) {
    return AdminOrdersState(
      status: status ?? this.status,
      orders: orders ?? this.orders,
      retailerOrders: retailerOrders ?? this.retailerOrders,
      itemsFields: itemsFields ?? this.itemsFields,
      order: order ?? this.order,
      pageNumber: pageNumber ?? this.pageNumber,
      retailerPageNumber: retailerPageNumber ?? this.retailerPageNumber,
      error: error ?? this.error,
    );
  }

  factory AdminOrdersState.initial() {
    return AdminOrdersState(
      status: AdminOrdersStatus.initial,
      orders: const [],
      retailerOrders: const [],
      itemsFields: const [],
      order: Order.initial(),
      pageNumber: 1,
      retailerPageNumber: 1,
      error: CustomError.initial(),
    );
  }

  @override
  String toString() {
    return 'AdminOrdersState{status: $status, orders: $orders, order: $order, error: $error}';
  }

  @override
  List<Object?> get props => [
        status,
        orders,
        retailerOrders,
        order,
        itemsFields,
        pageNumber,
        retailerPageNumber,
        error,
      ];
}
