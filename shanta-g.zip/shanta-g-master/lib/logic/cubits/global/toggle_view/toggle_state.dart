part of 'toggle_cubit.dart';

enum ToggleStatus {
  initial,
  loading,
  loaded,
  error,
}

class ToggleState extends Equatable {
  final bool obSecure;
  final bool isListView;

  const ToggleState({
    required this.obSecure,
    required this.isListView,
  });

  factory ToggleState.initial() => const ToggleState(
        obSecure: true,
        isListView: false,
      );

  @override
  String toString() {
    return 'ToggleState{obSecure: $obSecure, isGridView: $isListView}';
  }

  ToggleState copyWith({
    bool? obSecure,
    bool? isGridView,
  }) {
    return ToggleState(
      obSecure: obSecure ?? this.obSecure,
      isListView: isGridView ?? this.isListView,
    );
  }

  @override
  List<Object> get props => [obSecure, isListView];
}
