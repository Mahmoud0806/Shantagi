import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'toggle_state.dart';

class ToggleCubit extends Cubit<ToggleState> {
  ToggleCubit() : super(ToggleState.initial());
  void toggleView() {
    print(state.isListView);
    emit(state.copyWith(isGridView: !state.isListView));
    print(state.isListView);
  }
  void toggleObSecure() {
    emit(state.copyWith(obSecure: !state.obSecure));
  }

}
