import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '/data/constant/constant.dart';

import '/data/constant/urls/retailers.dart';
import '/data/repos/order_repo.dart';
import '/models/custom_error.dart';
import '/models/order/order.dart';
import '/models/order/order_item.dart';

part 'orders_state.dart';

class RetailerOrdersCubit extends Cubit<RetailerOrdersState> {
  RetailerOrdersCubit() : super(RetailerOrdersState.initial());
  final _ordersRepo = OrdersRepo();

  setActiveOrder(int id) {
    emit(state.copyWith(status: RetailerOrdersStatus.loading));
    for (var order in state.orders) {
      if (order.id == id) {
        emit(state.copyWith(order: order,status: RetailerOrdersStatus.loaded));
        break;
      }
    }
  }

  Future<void> getAll() async {
    emit(state.copyWith(status: RetailerOrdersStatus.loading));
    try {
      final orders = await _ordersRepo.getUserOrders('$baseURL/retailer/orders');
      emit(state.copyWith(status: RetailerOrdersStatus.loaded, orders: orders));
    } on CustomError catch (e) {
      emit(state.copyWith(status: RetailerOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: RetailerOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> changeItemStatus(int itemId, bool status) async {
    emit(state.copyWith(status: RetailerOrdersStatus.loading));
    try {
      print('============ item stat $itemId');
      await _ordersRepo.changeItemStatus(
          RetailersURLs.itemStatus(itemId), _setStatus(status));
      emit(state.copyWith(status: RetailerOrdersStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: RetailerOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: RetailerOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  String _setStatus(bool status) => status ? 'accepted' : 'cancelled';

  Future<void> confirm(var body) async {
    emit(state.copyWith(status: RetailerOrdersStatus.loading));
    try {
      await _ordersRepo.confirm(RetailersURLs.confirmOrder, body);
      emit(state.copyWith(status: RetailerOrdersStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: RetailerOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: RetailerOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }
}
