part of 'orders_cubit.dart';

enum RetailerOrdersStatus {
  initial,
  loading,
  loaded,
  empty,
  changed,
  error,
}

class RetailerOrdersState extends Equatable {
  final RetailerOrdersStatus status;
  final List<Order> orders;
  final Order order;
  final OrderItem orderItem;
  final CustomError error;

  const RetailerOrdersState({
    required this.status,
    required this.orders,
    required this.order,
    required this.orderItem,
    required this.error,
  });

  factory RetailerOrdersState.initial() => RetailerOrdersState(
        status: RetailerOrdersStatus.initial,
        orders: const [],
        order: Order.initial(),
        orderItem: OrderItem.initial(),
        error: const CustomError(message: '', code: 0),
      );

  RetailerOrdersState copyWith({
    RetailerOrdersStatus? status,
    List<Order>? orders,
    Order? order,
    OrderItem? orderItem,
    CustomError? error,
  }) {
    return RetailerOrdersState(
      status: status ?? this.status,
      orders: orders ?? this.orders,
      order: order ?? this.order,
      orderItem: orderItem ?? this.orderItem,
      error: error ?? this.error,
    );
  }

  @override
  List<Object> get props => [status, orders, order, orderItem, error];

  @override
  String toString() {
    return 'RetailerOrdersState{status: $status, orders: $orders, order: $order, orderItem: $orderItem, error: $error}';
  }
}
