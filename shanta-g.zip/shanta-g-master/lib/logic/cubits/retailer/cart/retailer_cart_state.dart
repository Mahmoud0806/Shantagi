part of 'retailer_cart_cubit.dart';


enum CartStatus {
  initial,
  loading,
  loaded,
  error,
}

class RetailerCartState extends Equatable {
  final CartStatus status;
  final List<CartItem> items;
  final CartItem item;
  final String error;

  const RetailerCartState({
    required this.status,
    required this.items,
    required this.item,
    required this.error,
  });

  factory RetailerCartState.initial() => RetailerCartState(
    status: CartStatus.initial,
    items:  const [],
    item: CartItem.initial(),
    error: '',
  );

  RetailerCartState copyWith({
    CartStatus? status,
    List<CartItem>? items,
    CartItem? item,
    String? error,
  }) {
    return RetailerCartState(
      status: status ?? this.status,
      items: items ?? this.items,
      item: item ?? this.item,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'RetailerCartState{status: $status, products: $items, '
        'product: $item, error: $error}';
  }

  @override
  List<Object> get props => [status, items, item, error];
}
