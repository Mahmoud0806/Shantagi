import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/retailers.dart';
import '/data/repos/retailer_dealers_repo.dart';
import '/models/user.dart';

part 'retailer_dealers_state.dart';

class RetailerDealersCubit extends Cubit<RetailerDealersState> {
  RetailerDealersCubit() : super(RetailerDealersState.initial());

  final _repo = RetailerDealersRepo();

  Future<List<User>> getAll() async {
    emit(state.copyWith(status: RetailerDealersStatus.loading));
    try {
      List<User> dealers = await _repo.getAll(RetailersURLs.allDealers);
      emit(state.copyWith(
        status: RetailerDealersStatus.loaded,
        dealers: dealers,
      ));
      return dealers;
    } catch (err) {
      emit(state.copyWith(
          status: RetailerDealersStatus.error, error: err.toString()));
      return [];
    }
  }
}
