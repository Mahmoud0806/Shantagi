part of 'retailer_dealers_cubit.dart';

enum RetailerDealersStatus { initial, loading, loaded, error }

class RetailerDealersState extends Equatable {
  final RetailerDealersStatus status;
  final User dealer;
  final List<User> dealers;
  final String error;

  const RetailerDealersState({
    required this.status,
    required this.dealer,
    required this.dealers,
    required this.error,
  });

  factory RetailerDealersState.initial() => RetailerDealersState(
        status: RetailerDealersStatus.initial,
        dealer: User.initial(),
        dealers: const [],
        error: '',
      );

  RetailerDealersState copyWith({
    RetailerDealersStatus? status,
    User? dealer,
    List<User>? dealers,
    String? error,
  }) {
    return RetailerDealersState(
      status: status ?? this.status,
      dealer: dealer ?? this.dealer,
      dealers: dealers ?? this.dealers,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'RetailerDealersState{status: $status, dealer: $dealer, dealers: $dealers, error: $error}';
  }

  @override
  List<Object> get props => [status, dealer, dealers, error];
}
