import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/retailers.dart';
import '/data/repos/products_repo.dart';
import '/models/custom_error.dart';
import '/models/product/product.dart';

part 'products_state.dart';

class RetailerProductsCubit extends Cubit<RetailerProductsState> {
  RetailerProductsCubit() : super(RetailerProductsState.initial());

  final _repo = ProductsRepo();

  setActiveProduct(int index) {
    emit(state.copyWith(status: RetailerProductsStatus.loading));
    emit(state.copyWith(
        status: RetailerProductsStatus.loaded, product: state.products[index]));
  }

  Future<void> getAll({String params = '', bool saveOld = false, bool savePage = false }) async {
    emit(state.copyWith(status: RetailerProductsStatus.loading));
    try {
      final products = await _repo.getAllProducts(!saveOld
          ? "${RetailersURLs.allProducts}${params.isNotEmpty ? params : ''}"
          : "${RetailersURLs.allProducts}${params.isNotEmpty ? '$params&page=${state.pageNumber}' : '?page=${state.pageNumber}'}");
      if (saveOld) {
        emit(state.copyWith(
            status: RetailerProductsStatus.loaded,
            products: [...state.products, ...products],
            pageNumber:!savePage ? 2 :
                products.isNotEmpty ? state.pageNumber + 1 : state.pageNumber));
        print('newPage = ${state.pageNumber}');
      } else {
        emit(state.copyWith(
            status: RetailerProductsStatus.loaded,
            products: products,
            pageNumber:
                products.isNotEmpty ? state.pageNumber + 1 : state.pageNumber));
      }
    } on CustomError catch (e) {
      emit(state.copyWith(status: RetailerProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: RetailerProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }
}
