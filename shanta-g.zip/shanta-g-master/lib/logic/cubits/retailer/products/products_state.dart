part of 'products_cubit.dart';

enum RetailerProductsStatus {
  initial,
  loading,
  loaded,
  error,
}

class RetailerProductsState extends Equatable {
  final RetailerProductsStatus status;
  final List<Product> products;
  final Product product;
  final int pageNumber;
  final CustomError error;

  const RetailerProductsState({
    required this.status,
    required this.products,
    required this.product,
    required this.pageNumber,
    required this.error,
  });

  factory RetailerProductsState.initial() => RetailerProductsState(
        status: RetailerProductsStatus.initial,
        products: const [],
        product: Product.initial(),
        pageNumber: 1,
        error: CustomError.initial(),
      );

  @override
  List<Object?> get props => [status, products, product, error];

  RetailerProductsState copyWith({
    RetailerProductsStatus? status,
    List<Product>? products,
    int? pageNumber,
    Product? product,
    CustomError? error,
  }) {
    return RetailerProductsState(
      status: status ?? this.status,
      products: products ?? this.products,
      pageNumber: pageNumber ?? this.pageNumber,
      product: product ?? this.product,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'RetailerProductsState{status: $status, products: $products, product: $product, error: $error}';
  }
}
