part of 'switches_cubit.dart';

enum SwitchesStatus {
  initial,
  loading,
  loaded,
  changedShanta,
  changedWholesaler,
  changedHold,
  error,
}

class SwitchesState extends Equatable {
  final SwitchesStatus status;
  final bool obSecure;
  final bool viewShanta;
  final bool viewWholesalers;
  final List<bool> holdProducts;

  const SwitchesState({
    required this.status,
    required this.obSecure,
    required this.viewShanta,
    required this.viewWholesalers,
    required this.holdProducts,
  });

  factory SwitchesState.initial() =>
      const SwitchesState(
        status: SwitchesStatus.initial,
        obSecure: true,
        viewShanta: false,
        viewWholesalers: false,
        holdProducts: [false],
      );

  SwitchesState copyWith({
    SwitchesStatus? status,
    bool? obSecure,
    bool? viewShanta,
    bool? viewWholesalers,
    List<bool>? holdProducts,
  }) {
    return SwitchesState(
      status: status ?? this.status,
      obSecure: obSecure ?? this.obSecure,
      viewShanta: viewShanta ?? this.viewShanta,
      viewWholesalers: viewWholesalers ?? this.viewWholesalers,
      holdProducts: holdProducts ?? this.holdProducts,
    );
  }

  @override
  String toString() {
    return 'SwitchesState{status: $status, obSecure: $obSecure, viewShanta: $viewShanta, viewWholesalers: $viewWholesalers, holdProducts: $holdProducts}';
  }

  @override
  List<Object> get props =>
      [status, obSecure, viewShanta, viewWholesalers, holdProducts,];
}
