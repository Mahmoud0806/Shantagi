import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'switches_state.dart';

class SwitchesCubit extends Cubit<SwitchesState> {
  SwitchesCubit() : super(SwitchesState.initial());


  void changeObSecure() {
    emit(state.copyWith(obSecure: !state.obSecure));
  }

  Future<void> changeShantaView() async{

    emit(state.copyWith(obSecure: !state.obSecure));
  }


}
