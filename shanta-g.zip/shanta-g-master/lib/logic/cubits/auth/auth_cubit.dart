import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/data/constant/constant.dart';

import '/data/constant/end_points.dart';
import '/data/repos/auth_repo.dart';
import '/models/user.dart';

part 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  AuthCubit() : super(AuthState.initial());
  var emailController = TextEditingController();
  var passwordController = TextEditingController();
  final _repo = AuthRepo();

  Future<void> login() async {
    emit(state.copyWith(status: AuthStatus.loading));
    try {
      print('email ${emailController.text}');
      print('pass :${passwordController.text}');
      Map<String, dynamic> body = {
        'email': emailController.text,
        'password': passwordController.text,
      };
      User user = await _repo.login(EndPoints.login, json.encode(body));
      print(user.type);
      userType = user.type;
      emit(state.copyWith(
        type: setType(user.type),
        token: token,
        status: AuthStatus.loaded,
      ));
    } catch (err) {
      emit(state.copyWith(error: err.toString(), status: AuthStatus.error));
    }
  }

  setType(String type) {
    switch (type) {
      case 'admin':
        return UserType.admin;
      case 'shanta':
        return UserType.shanta;
      case 'wholesaler':
        return UserType.wholesaler;
      case 'retailer':
        return UserType.retailer;
      case 'client':
        return UserType.client;
    }
  }

  void logout() async {
    try {
      await _repo.logout(EndPoints.logOut);
    } catch (err) {
      emit(state.copyWith(error: err.toString(), status: AuthStatus.error));
    }
  }
}
