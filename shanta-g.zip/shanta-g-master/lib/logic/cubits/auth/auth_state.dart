part of 'auth_cubit.dart';

enum AuthStatus { initial, loading, loaded, error }

enum UserType {
  admin,
  shanta,
  wholesaler,
  retailer,
  client,
}

class AuthState extends Equatable {
  final AuthStatus status;
  final UserType type;
  final String token;
  final String error;

  const AuthState({
    required this.status,
    required this.type,
    required this.token,
    required this.error,
  });

  factory AuthState.initial() => const AuthState(
        status: AuthStatus.initial,
        type: UserType.client,
        token: '',
        error: '',
      );

  AuthState copyWith({
    AuthStatus? status,
    UserType? type,
    String? token,
    String? error,
  }) {
    return AuthState(
      status: status ?? this.status,
      type: type ?? this.type,
      token: token ?? this.token,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'AuthState{status: $status, type: $type, token: $token, error: $error}';
  }

  @override
  List<Object> get props => [status, type, token, error];
}
