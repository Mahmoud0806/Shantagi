import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

part 'date_time_state.dart';

class DateTimeCubit extends Cubit<DateTimeState> {
  DateTimeCubit() : super(DateTimeState.initial());

  void setDate(DateTime? date) {
    emit(state.copyWith(date: date));
  }

  // void setStartTime(TimeOfDay? startTime) {
  //   emit(state.copyWith(startTime: startTime));
  // }

  // void setEndDate(TimeOfDay? endTime) {
  //   emit(state.copyWith(endTime: endTime));
  // }

  // bool isDateTimeValid() {
  //   if (isInitialDateTime()) {
  //     return false;
  //   }
  //   double startTime = toDouble(state.startTime);
  //   double endTime = toDouble(state.endTime);
  //
  //   if (startTime > endTime) {
  //     emit(
  //       state.copyWith(errorMessage: 'Start Time should be before End Time'),
  //     );
  //     return false;
  //   }
  //   return true;
  // }

  double toDouble(TimeOfDay time) => time.hour + time.minute / 60.0;

  bool isInitialDateTime() {
    return isInitialDate() || isInitialStartTime() || isInitialEndTime();
  }

  bool isInitialDate() {
    if (state.date.day < DateTime.now().day) {
      emit(state.copyWith(errorMessage: 'Please Select Date'));
      return true;
    }
    return false;
  }

  bool isInitialStartTime() {
    double startTime = toDouble(state.startTime);
    double initialStartTime = toDouble(DateTimeState.initial().startTime);
    if (startTime == initialStartTime) {
      emit(state.copyWith(errorMessage: 'Please Select Start Time'));
      return true;
    }
    return false;
  }

  bool isInitialEndTime() {
    double endTime = toDouble(state.endTime);
    double initialEndTime = toDouble(DateTimeState.initial().endTime);
    if (endTime == initialEndTime) {
      emit(state.copyWith(errorMessage: 'Please Select End Time'));
      return true;
    }
    return false;
  }
}
