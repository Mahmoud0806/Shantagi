part of 'date_time_cubit.dart';

class DateTimeState extends Equatable {
  final DateTime date;
  final TimeOfDay startTime;
  final TimeOfDay endTime;
  final String errorMessage;

  const DateTimeState({
    required this.date,
    required this.startTime,
    required this.endTime,
    required this.errorMessage,
  });

  factory DateTimeState.initial() => DateTimeState(
        date: DateTime(2000),
        startTime: TimeOfDay.fromDateTime(DateTime(2000)),
        endTime: TimeOfDay.fromDateTime(DateTime(2000)),
        errorMessage: 'Enter Valid Date and Time'
      );

  DateTimeState copyWith({
    DateTime? date,
    TimeOfDay? startTime,
    TimeOfDay? endTime,
    String? errorMessage,
  }) {
    return DateTimeState(
      date: date ?? this.date,
      startTime: startTime ?? this.startTime,
      endTime: endTime ?? this.endTime,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  @override
  List<Object> get props => [date, startTime, endTime, errorMessage];
}
