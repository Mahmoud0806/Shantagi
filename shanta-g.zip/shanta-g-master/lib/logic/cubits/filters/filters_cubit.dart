import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/models/category.dart';
import '/models/user.dart';

part 'filters_state.dart';

class FiltersCubit extends Cubit<FiltersState> {
  FiltersCubit() : super(FiltersState.initial());

  addFilter(String key, String value) {
    emit(state.copyWith(status: FilterStatus.loading));
    emit(state.copyWith(status: FilterStatus.loaded, filters: {
      ...state.filters,
      key: value,
    }));
  }

  removeFilter(String key) {
    emit(state.copyWith(status: FilterStatus.loading));
    Map<String, String> newFilters = {...state.filters};
    newFilters.remove(key);
    emit(state.copyWith(status: FilterStatus.loaded, filters: newFilters));
  }

  clearFilter(String key) {
    emit(state.copyWith(status: FilterStatus.loading));
    emit(state.copyWith(status: FilterStatus.loaded, filters: {}));
  }

  fillDealers(List sourceDealers) {
    print('start filling dealers');
    List<User> newDealers = [];
    List<bool> selectedDealers = [];
    for (int i = 0; i < sourceDealers.length; i++) {
      newDealers.add(sourceDealers[i]);
      selectedDealers.add(false);
    }
    print('start filling dealers len ::: ${selectedDealers.length}');
    print('start filling dealers len ::: ${newDealers.length}');
    emit(state.copyWith(
      status: FilterStatus.loaded,
      dealers: newDealers,
      selectedDealers: selectedDealers,
    ));
  }

  fillCats(List sourceCats) {
    List<Category> newCats = [];
    List<bool> selectedCats = [];
    for (int i = 0; i < sourceCats.length; i++) {
      newCats.add(sourceCats[i]);
      selectedCats.add(false);
    }
    emit(state.copyWith(
      status: FilterStatus.loaded,
      categories: newCats,
      selectedCategories: selectedCats,
    ));
  }

  fillKarat(List sourceKarat) {
    List<int> newKarat = [];
    List<bool> selectedKarat = [];
    for (int i = 0; i < sourceKarat.length; i++) {
      newKarat.add(sourceKarat[i]);
      selectedKarat.add(false);
    }
    emit(state.copyWith(
      status: FilterStatus.loaded,
      karat: newKarat,
      selectedKarat: selectedKarat,
    ));
  }

  selectCat(List cats, cat) {
    List<bool> newCat = [];
    for (int i = 0; i < state.selectedCategories.length; i++) {
      if (cats[i].id == cat.id) {
        newCat.add(true);
      } else {
        newCat.add(false);
      }
    }
    emit(state.copyWith(
        status: FilterStatus.loaded, selectedCategories: newCat));
  }

  selectKarat(karat) {
    List<bool> newKarat = [];
    for (int i = 0; i < state.selectedKarat.length; i++) {
      print('start karat::: ${state.karat}');
      if ('${state.karat[i]}' == '$karat') {
        print('start karat matched ;;;;; }');
        newKarat.add(true);
      } else {
        newKarat.add(false);
      }
    }
    emit(state.copyWith(status: FilterStatus.loaded, selectedKarat: newKarat));
  }

  selectDealer(List dealers, dealerId, dealerName) {
    print('start match:: ');
    List<bool> newDealers = [];
    for (int i = 0; i < state.selectedDealers.length; i++) {
      if (dealers[i].id == dealerId && dealers[i].name == dealerName) {
        print('found match first half :: $dealerId, $dealerName');
        print(
            'found match second half :: ${dealers[i].id}, ${dealers[i].name}');
        newDealers.add(true);
      } else {
        newDealers.add(false);
      }
    }
    print('testtt length lates ::; ${newDealers.length}');
    emit(state.copyWith(
        status: FilterStatus.loaded, selectedDealers: newDealers));
  }

  String setSelectedParams() {
    String params = '?';
    for (int i = 0; i < state.selectedDealers.length; i++) {
      if (state.selectedDealers[i] == true) {
        params += 'wholesaler=${state.dealers[i].name}';
        break;
      }
    }
    for (int i = 0; i < state.selectedCategories.length; i++) {
      if (state.selectedCategories[i] == true) {
        if (params.length > 1) {
          params += '&';
        }
        params += 'category=${state.categories[i].id}';
        break;
      }
    }
    for (int i = 0; i < state.selectedKarat.length; i++) {
      if (state.selectedKarat[i] == true) {
        if (params.length < 2) {
          params += '&';
        }
        params += '&karat=${state.karat[i]}';
        break;
      }
    }
    return params;
  }

  resetFilters() {
    List<bool> selectedDealers = [];
    List<bool> selectedCategories = [];
    List<bool> selectedKarat = [];
    String params = '?';
    for (int i = 0; i < state.selectedDealers.length; i++) {
      selectedDealers.add(false);
    }
    for (int i = 0; i < state.selectedCategories.length; i++) {
      selectedCategories.add(false);
    }
    for (int i = 0; i < state.selectedKarat.length; i++) {
      selectedKarat.add(false);
    }
    emit(state.copyWith(
      status: FilterStatus.loaded,
      selectedDealers: selectedDealers,
      selectedCategories: selectedCategories,
      selectedKarat: selectedKarat,
    ));
  }
}
