part of 'filters_cubit.dart';

enum FilterStatus {
  initial,
  loading,
  loaded,
  setCat,
  setDealer,
  setName,
  error,
}

class FiltersState extends Equatable {
  final FilterStatus status;
  final List<Category> categories;
  final List<bool> selectedCategories;
  final List<int> karat;
  final List<bool> selectedKarat;
  final List<User> dealers;
  final List<bool> selectedDealers;
  final Map<String, String> filters;
  final List<String> keys;
  final String error;

  const FiltersState({
    required this.status,
    required this.filters,
    required this.categories,
    required this.selectedCategories,
    required this.karat,
    required this.selectedKarat,
    required this.dealers,
    required this.selectedDealers,
    required this.keys,
    required this.error,
  });

  factory FiltersState.initial() => const FiltersState(
        status: FilterStatus.initial,
        filters: {},
        categories: [],
        selectedCategories: [],
        karat: [18, 21, 24],
        selectedKarat: [false, false, false],
        dealers: [],
        selectedDealers: [],
        keys: [],
        error: '',
      );

  FiltersState copyWith({
    FilterStatus? status,
    Map<String, String>? filters,
    List<String>? keys,
    List<Category>? categories,
    List<bool>? selectedCategories,
    List<int>? karat,
    List<bool>? selectedKarat,
    List<User>? dealers,
    List<bool>? selectedDealers,
    String? error,
  }) {
    return FiltersState(
      status: status ?? this.status,
      filters: filters ?? this.filters,
      categories: categories ?? this.categories,
      selectedCategories: selectedCategories ?? this.selectedCategories,
      karat: karat ?? this.karat,
      selectedKarat: selectedKarat ?? this.selectedKarat,
      dealers: dealers ?? this.dealers,
      selectedDealers: selectedDealers ?? this.selectedDealers,
      keys: keys ?? this.keys,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'FiltersState{status: $status, filters: $filters, keys: $keys, error: $error}';
  }

  @override
  List<Object> get props => [
        status,
        categories,
        selectedCategories,
        karat,
        selectedKarat,
        dealers,
        selectedDealers,
        filters,
        keys,
        error,
      ];
}
