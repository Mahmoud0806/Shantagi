import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/urls/clients.dart';
import '/data/repos/products_repo.dart';
import '/models/custom_error.dart';
import '/models/product/product.dart';

part 'products_state.dart';

class ClientProductsCubit extends Cubit<ClientProductsState> {
  ClientProductsCubit() : super(ClientProductsState.initial());
  final _repo = ProductsRepo();

  setActiveProduct(int index) {
    emit(state.copyWith(status: ClientProductsStatus.loading));
    emit(state.copyWith(
        status: ClientProductsStatus.loaded, product: state.products[index]));
  }

  Future<void> getAll({String params = '', bool saveOld = false, bool savePage = false }) async {
    print('params :: :: $params');
    emit(state.copyWith(status: ClientProductsStatus.loading));
    try {
      List<Product> products = await _repo.getAllProducts(!saveOld
          ? "${ClientURLs.allProducts}${params.isNotEmpty ? params : ''}"
          : "${ClientURLs.allProducts}${params.isNotEmpty ? '$params&page=${state.pageNumber}' : '?page=${state.pageNumber}'}");
      emit(
        state.copyWith(
          status: ClientProductsStatus.loaded,
          products: saveOld ? [...state.products, ...products] : products,
          pageNumber: !savePage ? 2 :
              products.isNotEmpty ? state.pageNumber + 1 : state.pageNumber,
        ),
      );
    } on CustomError catch (e) {
      emit(state.copyWith(status: ClientProductsStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ClientProductsStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }
}
