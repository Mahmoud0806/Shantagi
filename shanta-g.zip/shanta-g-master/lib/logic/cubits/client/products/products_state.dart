part of 'products_cubit.dart';

enum ClientProductsStatus {
  initial,
  loading,
  loaded,
  added,
  error,
}

class ClientProductsState extends Equatable {
  final ClientProductsStatus status;
  final List<Product> products;
  final Product product;
  final int pageNumber;
  final CustomError error;

  const ClientProductsState({
    required this.status,
    required this.products,
    required this.product,
    required this.pageNumber,
    required this.error,
  });

  @override
  List<Object?> get props => [
        status,
        products,
        product,
        pageNumber,
        error,
      ];

  ClientProductsState copyWith({
    ClientProductsStatus? status,
    List<Product>? products,
    Product? product,
    int? pageNumber,
    CustomError? error,
  }) {
    return ClientProductsState(
      status: status ?? this.status,
      products: products ?? this.products,
      product: product ?? this.product,
      pageNumber: pageNumber ?? this.pageNumber,
      error: error ?? this.error,
    );
  }

  factory ClientProductsState.initial() {
    return ClientProductsState(
      status: ClientProductsStatus.initial,
      products: const [],
      product: Product.initial(),
      pageNumber: 1,
      error: CustomError.initial(),
    );
  }

  @override
  String toString() {
    return 'ClientProductsState{status: $status, products: $products, product: $product, error: $error}';
  }
}
