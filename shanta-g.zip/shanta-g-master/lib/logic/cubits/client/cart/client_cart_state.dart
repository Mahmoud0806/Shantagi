part of 'client_cart_cubit.dart';

enum CartStatus {
  initial,
  loading,
  loaded,
  error,
}

class ClientCartState extends Equatable {
  final CartStatus status;
  final List<CartItem> items;
  final CartItem item;
  final String error;

  const ClientCartState({
    required this.status,
    required this.items,
    required this.item,
    required this.error,
  });

  factory ClientCartState.initial() => ClientCartState(
        status: CartStatus.initial,
        items:  const [],
        item: CartItem.initial(),
        error: '',
      );

  ClientCartState copyWith({
    CartStatus? status,
    List<CartItem>? items,
    CartItem? item,
    String? error,
  }) {
    return ClientCartState(
      status: status ?? this.status,
      items: items ?? this.items,
      item: item ?? this.item,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'ClientCartState{status: $status, products: $items, '
        'product: $item, error: $error}';
  }

  @override
  List<Object> get props => [status, items, item, error];
}
