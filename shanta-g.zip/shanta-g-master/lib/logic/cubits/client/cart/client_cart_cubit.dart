import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import '/data/constant/urls/clients.dart';
import '/data/repos/order_repo.dart';
import '/models/cart/cart_item.dart';

import '/data/constant/storage/cart_storage.dart';

part 'client_cart_state.dart';

class ClientCartCubit extends Cubit<ClientCartState> {
  ClientCartCubit() : super(ClientCartState.initial());
  List<TextEditingController> sizesControllers = [];
  final _repo = OrdersRepo();

  void fillAmount(int length) {
    for (int i = 0; i < length; i++) {
      sizesControllers.add(TextEditingController());
    }
  }

  Future<void> get(CartItem newItem) async {
    emit(state.copyWith(status: CartStatus.loading));
    try {
      List<CartItem> items = CartStorage.getCart();
      emit(state.copyWith(status: CartStatus.loaded, items: items));
    } catch (err) {
      emit(state.copyWith(status: CartStatus.error));
    }
  }

  Future<void> cartCheckout(List cartItems) async {
    emit(state.copyWith(status: CartStatus.loading));
    try {
      print('start cubit');
      await _repo.confirm(ClientURLs.confirmOrder, cartItems);
      List<CartItem> items = [];
      emit(state.copyWith(status: CartStatus.loaded, items: items));
    } catch (err) {
      emit(state.copyWith(status: CartStatus.error));
    }
  }


  Future<void> addToCart(CartItem cartItem) async {
    print('start func');
    emit(state.copyWith(status: CartStatus.loading));
    try {
      print('start storage');
      await CartStorage.addToCart(cartItem);
      print('start adding');
      List<CartItem> items = [...state.items, cartItem];
      print(cartItem);
      print(items);
      print('start emitting');
      emit(state.copyWith(status: CartStatus.loaded, items: items));
    } catch (err) {
      emit(state.copyWith(status: CartStatus.error));
    }
  }

  Future<void> removeFromCart(int id) async {
    emit(state.copyWith(status: CartStatus.loading));
    try {
      List<CartItem> items = [...state.items];
      items.removeWhere((element) => element.id == id);
      emit(state.copyWith(status: CartStatus.loaded, items: items));
    } catch (err) {
      emit(state.copyWith(status: CartStatus.error));
    }
  }

  Future<void> emptyCart() async {
    emit(state.copyWith(status: CartStatus.loading));
    try {
      List<CartItem> items = [];
      emit(state.copyWith(status: CartStatus.loaded, items: items));
    } catch (err) {
      emit(state.copyWith(status: CartStatus.error));
    }
  }
}
