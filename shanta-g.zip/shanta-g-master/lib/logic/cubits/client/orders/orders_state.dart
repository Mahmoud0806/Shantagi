part of 'orders_cubit.dart';

enum ClientOrdersStatus {
  initial,
  loading,
  loaded,
  confirmed,
  error,
}

class ClientOrdersState extends Equatable {
  final ClientOrdersStatus status;
  final List<Order> orders;
  final Order order;
  final CustomError error;

  const ClientOrdersState({
    required this.status,
    required this.orders,
    required this.order,
    required this.error,
  });

  factory ClientOrdersState.initial() => ClientOrdersState(
        status: ClientOrdersStatus.initial,
        orders: const [],
        order: Order.initial(),
        error: CustomError.initial(),
      );

  @override
  List<Object?> get props => [
        status,
        orders,
        order,
        error,
      ];

  ClientOrdersState copyWith({
    ClientOrdersStatus? status,
    List<Order>? orders,
    Order? order,
    CustomError? error,
  }) {
    return ClientOrdersState(
      status: status ?? this.status,
      orders: orders ?? this.orders,
      order: order ?? this.order,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'ClientOrdersState{status: $status, orders: $orders, order: $order, error: $error}';
  }

  @override
  bool get stringify => true;
}
