import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:shantagi/models/order/order_item.dart';

import '/data/constant/urls/clients.dart';
import '/data/repos/order_repo.dart';
import '/models/custom_error.dart';
import '/models/order/order.dart';

part 'orders_state.dart';

class ClientOrdersCubit extends Cubit<ClientOrdersState> {
  ClientOrdersCubit() : super(ClientOrdersState.initial());

  final _repo = OrdersRepo();

  Future<void> get() async {
    emit(state.copyWith(status: ClientOrdersStatus.loading));
    try {
      final orders = await _repo.getAll(ClientURLs.allOrders);
      emit(state.copyWith(status: ClientOrdersStatus.loaded, orders: orders));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ClientOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ClientOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> confirm(var body) async {
    emit(state.copyWith(status: ClientOrdersStatus.loading));
    try {
      await _repo.confirm(ClientURLs.confirmOrder, body);
      emit(state.copyWith(status: ClientOrdersStatus.confirmed));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ClientOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: ClientOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  setActiveOrder(int index) {
    emit(state.copyWith(status: ClientOrdersStatus.loading));
    emit(
      state.copyWith(
          status: ClientOrdersStatus.loaded, order: state.orders[index]),
    );
  }

  Future<void> changeItemStatus(int itemId, int index, bool status) async {
    emit(state.copyWith(status: ClientOrdersStatus.loading));
    try {
      print('============ item stat $itemId');
      await _repo.changeItemStatus(
          ClientURLs.itemStatus(itemId), _setStatus(status));
      OrderItem item = state.order.orderItems[index].copyWith(
        status: status ? 'accepted': 'cancelled',
      );
      List<OrderItem> newItems = [...state.order.orderItems];
      newItems[index] = item;
      Order newOrder = state.order.copyWith(
        orderItems: newItems
      );
      print(state.order.orderItems[index].status);
      emit(state.copyWith(status: ClientOrdersStatus.loaded, order: newOrder));
    } on CustomError catch (e) {
      emit(state.copyWith(status: ClientOrdersStatus.error, error: e));
    } catch (e) {
      emit(
        state.copyWith(
          status: ClientOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0),
        ),
      );
    }
  }

  String _setStatus(bool status) => status ? 'accepted' : 'cancelled';
}
