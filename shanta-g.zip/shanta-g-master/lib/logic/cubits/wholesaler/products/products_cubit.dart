import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '/data/constant/constant.dart';
import '/data/constant/urls/wholesalers.dart';
import '/data/repos/products_repo.dart';
import '/models/product/product.dart';

part 'products_state.dart';

class WholesalerProductsCubit extends Cubit<WholesalerProductsState> {
  WholesalerProductsCubit() : super(WholesalerProductsState.initial());

  var repo = ProductsRepo();

  Future getAll(
      {String params = '',
      final saveOld = false,
      final savePage = false}) async {
    emit(state.copyWith(status: WholesalerProductsStatus.loading));

    try {
      List<Product> products = [];
      products.addAll(await repo.getAllProducts(
        !saveOld
            ? "${WholesalersURLs.allProducts}${params.isNotEmpty ? params : ''}"
            : "${WholesalersURLs.allProducts}${params.isNotEmpty ? '$params&page=${state.pageNumber}' : '?page=${state.pageNumber}'}",
      ));

      emit(state.copyWith(
        status: WholesalerProductsStatus.loaded,
        products: saveOld ? [...state.products, ...products] : products,
        pageNumber: !savePage
            ? 2
            : products.isNotEmpty
                ? state.pageNumber + 1
                : state.pageNumber,
      ));
    } catch (error) {
      emit(state.copyWith(status: WholesalerProductsStatus.error));
    }
  }

  addToWholesalerList(Product product) {
    emit(state.copyWith(status: WholesalerProductsStatus.loading));
    emit(state.copyWith(
        status: WholesalerProductsStatus.loaded,
        products: [...state.products, product]));
  }

  setActive(int index) {
    emit(state.copyWith(status: WholesalerProductsStatus.loading));
    emit(state.copyWith(
      status: WholesalerProductsStatus.loaded,
      product: state.products[index],
    ));
  }

  Future changeHold(int id) async {
    emit(state.copyWith(status: WholesalerProductsStatus.holdLoading));
    try {
      String url = setUrl(id);
      Product product = await repo.changeHoldStatus(url);
      List<Product> products = [];
      products.addAll(update(id, product));
      emit(state.copyWith(
          status: WholesalerProductsStatus.holdChanged, products: products));
    } catch (error) {
      emit(state.copyWith(status: WholesalerProductsStatus.error));
    }
  }

  List<Product> update(int id, Product product) {
    List<Product> products = [];
    products.addAll(state.products);
    for (int i = 0; i < products.length; i++) {
      if (products[i].id == id) {
        products[i] = product;
        return products;
      }
    }
    return products;
  }

  String setUrl(int id) {
    return '$baseURL/wholesalers/products/$id/hold';
  }
}
