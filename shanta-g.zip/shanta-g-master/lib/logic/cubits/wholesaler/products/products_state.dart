part of 'products_cubit.dart';

enum WholesalerProductsStatus {
  initial,
  loading,
  holdLoading,
  loaded,
  holdChanged,
  error,
}

class WholesalerProductsState extends Equatable {
  final WholesalerProductsStatus status;
  final Product product;
  final List<Product> products;
  final int pageNumber;
  final String error;

  const WholesalerProductsState({
    required this.status,
    required this.product,
    required this.products,
    required this.pageNumber,
    required this.error,
  });

  factory WholesalerProductsState.initial() => WholesalerProductsState(
        status: WholesalerProductsStatus.initial,
        product: Product.initial(),
        products: const [],
        pageNumber: 1,
        error: '',
      );

  WholesalerProductsState copyWith({
    WholesalerProductsStatus? status,
    Product? product,
    List<Product>? products,
    int? pageNumber,
    String? error,
  }) {
    return WholesalerProductsState(
      status: status ?? this.status,
      product: product ?? this.product,
      products: products ?? this.products,
      pageNumber: pageNumber ?? this.pageNumber,
      error: error ?? this.error,
    );
  }

  @override
  List<Object> get props => [status, product, products, pageNumber, error];
}
