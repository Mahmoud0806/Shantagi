part of 'orders_cubit.dart';

enum WholesalerOrdersStatus {
  initial,
  loading,
  loaded,
  isAvailable,
  error,
}

class WholesalerOrdersState extends Equatable {
  final WholesalerOrdersStatus status;
  final List<Order> orders;
  final Order order;
  final List<int> itemsAmounts;
  final List<TextEditingController> itemsFields;
  final CustomError error;

  const WholesalerOrdersState({
    required this.status,
    required this.orders,
    required this.order,
    required this.itemsAmounts,
    required this.itemsFields,
    required this.error,
  });

  factory WholesalerOrdersState.initial() => WholesalerOrdersState(
        status: WholesalerOrdersStatus.initial,
        orders: const [],
        order: Order.initial(),
        itemsAmounts: const [],
        itemsFields: const [],
        error: CustomError.initial(),
      );

  WholesalerOrdersState copyWith({
    WholesalerOrdersStatus? status,
    List<Order>? orders,
    Order? order,
    List<int>? itemsAmounts,
    List<TextEditingController>? itemsFields,
    CustomError? error,
  }) {
    return WholesalerOrdersState(
      status: status ?? this.status,
      orders: orders ?? this.orders,
      order: order ?? this.order,
      itemsAmounts: itemsAmounts ?? this.itemsAmounts,
      itemsFields: itemsFields ?? this.itemsFields,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'OrdersState{status: $status, error: $error}';
  }

  @override
  List<Object?> get props =>
      [status, orders, order, itemsAmounts, itemsFields, error];
}
