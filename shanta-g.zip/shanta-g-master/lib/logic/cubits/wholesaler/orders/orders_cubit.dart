import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';

import '/data/constant/urls/wholesalers.dart';
import '/data/repos/order_repo.dart';
import '/models/custom_error.dart';
import '/models/order/order.dart';

part 'orders_state.dart';

class WholesalerOrdersCubit extends Cubit<WholesalerOrdersState> {
  WholesalerOrdersCubit() : super(WholesalerOrdersState.initial());

  final _ordersRepo = OrdersRepo();

  void setActive(index) {
    emit(state.copyWith(order: state.orders[index]));
    fillAmountsFields(state.orders[index].orderItems.length);
  }

  void fillAmountsFields(int length) {
    List<TextEditingController> fields = [];
    for(int i = 0 ; i < length; i++ ) {
      fields.add(TextEditingController());
    }
    emit(state.copyWith(itemsFields: fields));
  }

  void getAmountsFromFields(index) {
    // emit(state.copyWith(order: state.orders[index]));
  }

  Future<void> getAll() async {
    emit(state.copyWith(status: WholesalerOrdersStatus.loading));
    try {
      final orders = await _ordersRepo.getUserOrders(WholesalersURLs.allOrders);
      emit(state.copyWith(
          status: WholesalerOrdersStatus.loaded, orders: orders));
    } on CustomError catch (e) {
      emit(state.copyWith(status: WholesalerOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: WholesalerOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> changeStatus(Order order, List<int> status) async {
    emit(state.copyWith(status: WholesalerOrdersStatus.loading));
    try {
      await _ordersRepo.changeStatus(WholesalersURLs.changeOrderStatus, status);
      emit(state.copyWith(status: WholesalerOrdersStatus.loaded));
    } on CustomError catch (e) {
      emit(state.copyWith(status: WholesalerOrdersStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: WholesalerOrdersStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> confirmOrder() async {
    try {
      emit(state.copyWith(status: WholesalerOrdersStatus.loading));

      await _ordersRepo.confirm(
          WholesalersURLs.confirm(state.order.id), setItems());
      emit(state.copyWith(status: WholesalerOrdersStatus.loaded));
    } catch (err) {
      emit(
        state.copyWith(
            status: WholesalerOrdersStatus.error,
            error: CustomError(message: err.toString(), code: 0)),
      );
    }
  }

  setItems() {
    List items = [];
    for (int i = 0; i < state.order.orderItems.length; i++) {
      items.add({
        "id": state.order.orderItems[i].id,
        "acceptable_amount": state.itemsFields[i].text,
      });
    }
    return items;
  }
}
