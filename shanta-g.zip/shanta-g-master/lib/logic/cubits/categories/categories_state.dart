part of 'categories_cubit.dart';

enum CategoriesStatus {
  initial,
  loading,
  loaded,
  edited,
  deleted,
  created,
  error,
}

class CategoriesState extends Equatable {
  final CategoriesStatus status;
  final List<Category> categories;
  final List<DropdownMenuItem<String>> categoriesItems;
  final DropdownMenuItem<String> catItem;
  final Category category;
  final CustomError error;

  const CategoriesState({
    required this.status,
    required this.categories,
    required this.categoriesItems,
    required this.category,
    required this.catItem,
    required this.error,
  });

  @override
  List<Object?> get props => [
        status,
        categories,
        categoriesItems,
        category,
        catItem,
        error,
      ];

  CategoriesState copyWith({
    CategoriesStatus? status,
    List<Category>? categories,
    List<DropdownMenuItem<String>>? categoriesItems,
    Category? category,
    DropdownMenuItem<String>? catItem,
    CustomError? error,
  }) {
    return CategoriesState(
      status: status ?? this.status,
      categories: categories ?? this.categories,
      categoriesItems: categoriesItems ?? this.categoriesItems,
      category: category ?? this.category,
      catItem: catItem ?? this.catItem,
      error: error ?? this.error,
    );
  }

  factory CategoriesState.initial() {
    return CategoriesState(
      status: CategoriesStatus.initial,
      categories: const [],
      categoriesItems: const [],
      catItem: const DropdownMenuItem<String>(child: Text(''),),
      category: Category.initial(),
      error: CustomError.initial(),
    );
  }

  @override
  String toString() {
    return 'CategoriesState{status: $status, categories: $categories, category: $category, error: $error}';
  }
}
