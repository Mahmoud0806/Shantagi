import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '/data/constant/urls/admin.dart';
import '/data/repos/categories_repo.dart';
import '/models/category.dart';
import '/models/custom_error.dart';

part 'categories_state.dart';

class CategoriesCubit extends Cubit<CategoriesState> {
  CategoriesCubit() : super(CategoriesState.initial());

  final controller = TextEditingController();
  final _repo = CategoriesRepo();

  void setNewCats(cats) async {
    emit(state.copyWith(status: CategoriesStatus.loading, categories: []));
    try {
      emit(state.copyWith(status: CategoriesStatus.loaded, categories: cats));
    } catch (e) {
      emit(state.copyWith(
          status: CategoriesStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  selectCatItem(String? newValue) {
    if(newValue == null) return ;
    for(var cat in state.categoriesItems){
      if(cat.value == newValue){
        emit(state.copyWith(catItem: cat));
      }
    }
  }
  Future<void> getAll({String? url}) async {
    emit(state.copyWith(status: CategoriesStatus.loading));
    try {
      final categories = await _repo.getAll(url ?? AdminURLs.allCategories);
      List<DropdownMenuItem<String>> catItems = setCatItems(categories);
      print(categories.length);
      emit(state.copyWith(
          status: CategoriesStatus.loaded,
          categories: categories,
          categoriesItems: catItems));
    } on CustomError catch (e) {
      emit(state.copyWith(status: CategoriesStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: CategoriesStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  List<DropdownMenuItem<String>> setCatItems(List<Category> cats) {
    List<DropdownMenuItem<String>> catItems = [];
    for (Category cat in cats) {
      catItems.add(
        DropdownMenuItem(
          value: cat.id.toString(),
          child: Text(cat.name),
        ),
      );
    }
    return catItems;
  }

  Future<void> create(String name) async {
    print('cat name ::: $name');
    emit(state.copyWith(status: CategoriesStatus.loading));
    try {
      await _repo.create(AdminURLs.createCategory, name);
      emit(state.copyWith(status: CategoriesStatus.created));
    } on CustomError catch (e) {
      emit(state.copyWith(status: CategoriesStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: CategoriesStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> update(int id, String name) async {
    emit(state.copyWith(status: CategoriesStatus.loading));
    try {
      print(name);
      print('${AdminURLs.updateCategory}/$id');
      await _repo.update('${AdminURLs.updateCategory}/$id', name);
      emit(state.copyWith(status: CategoriesStatus.edited));
      // await getAll();
    } on CustomError catch (e) {
      emit(state.copyWith(status: CategoriesStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: CategoriesStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }

  Future<void> delete(int id) async {
    emit(state.copyWith(status: CategoriesStatus.loading));
    try {
      await _repo.delete('${AdminURLs.deleteCategory}/$id');
      emit(state.copyWith(status: CategoriesStatus.deleted));
    } on CustomError catch (e) {
      emit(state.copyWith(status: CategoriesStatus.error, error: e));
    } catch (e) {
      emit(state.copyWith(
          status: CategoriesStatus.error,
          error: CustomError(message: e.toString(), code: 0)));
    }
  }
}
