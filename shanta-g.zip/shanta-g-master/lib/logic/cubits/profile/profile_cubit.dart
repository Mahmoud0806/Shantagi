import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '/data/repos/profile_repo.dart';
import '/models/profile.dart';

part 'profile_state.dart';

class ProfileCubit extends Cubit<ProfileState> {
  ProfileCubit() : super(ProfileState.initial());

  var profileRepo = ProfileRepo();

  Future get() async {
    emit(state.copyWith(status: ProfileStatus.loading));
    try {
      Profile profile = await profileRepo.getProfile();
      emit(state.copyWith(status: ProfileStatus.success, profile: profile));
    } catch (error) {
      emit(state.copyWith(status: ProfileStatus.error));
    }
  }
}
// Future<bool> haveLocalData() async {
//   String name = await SharedPreferencesService.loadName();
//   String address = await SharedPreferencesService.loadAddress();
//   String phone = await SharedPreferencesService.loadPhone();
//
//   if(name == '' || address == '' || phone == ''){
//     return false;
//   }
//   var profile = Profile.initial();
//   profile = profile.copyWith(
//     name: name,
//     address: address,
//     phone: phone,
//   );
//   emit(state.copyWith( profile: profile));
//   return true;
// }
