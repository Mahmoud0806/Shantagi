part of 'profile_cubit.dart';

enum ProfileStatus {
  initial,
  loading,
  success,
  error,
}

class ProfileState extends Equatable {
  final ProfileStatus status;
  final Profile profile;
  final String error;

  const ProfileState({
    required this.status,
    required this.profile,
    required this.error,
  });

  factory ProfileState.initial() => ProfileState(
        status: ProfileStatus.initial,
        profile: Profile.initial(),
        error: '',
      );

  ProfileState copyWith({
    ProfileStatus? status,
    Profile? profile,
    String? error,
  }) {
    return ProfileState(
      status: status ?? this.status,
      profile: profile ?? this.profile,
      error: error ?? this.error,
    );
  }

  @override
  String toString() {
    return 'SubAdminProfileState{status: $status, error: $error}';
  }

  @override
  List<Object> get props => [status, profile, error];
}
