import 'package:equatable/equatable.dart';

class Category extends Equatable{
  final int id;
  final String name;

  const Category({
    required this.id,
    required this.name,
  });

  factory Category.initial() =>
      const Category(
        id: -1000,
        name: '',
      );

  Category copyWith({
    int? id,
    String? name,
  }) {
    return Category(
      id: id ?? this.id,
      name: name ?? this.name,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
    };
  }

  static fromListOfMaps(List maps) {
    if(maps.isEmpty){
      return[];
    }

    List<Category> categories = [];
    for(var map in maps){
        categories.add(Category.fromMap(map));
    }
    return categories;
  }

  factory Category.fromMap(Map<String, dynamic> map) {
    return Category(
      id: map['id'] as int,
      name: map['name'] as String,
    );
  }


  @override
  String toString() {
    return 'Category{id: $id, name: $name}';
  }

  @override
  List<Object> get props => [id, name];
}
