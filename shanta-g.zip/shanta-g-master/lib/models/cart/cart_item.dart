import 'package:equatable/equatable.dart';

import '/models/product/product.dart';

class CartItem extends Equatable {
  final int id;
  final String name;
  final String sizes;
  final String amounts;
  final String imageLink;
  final String itemNotes;

  const CartItem({
    required this.id,
    required this.name,
    required this.sizes,
    required this.amounts,
    required this.imageLink,
    required this.itemNotes,
  });

  factory CartItem.initial() => const CartItem(
        id: -1000,
        name: '',
        sizes: '',
        amounts: '',
        imageLink: '',
        itemNotes: '',
      );

  CartItem copyWith({
    int? id,
    String? name,
    String? sizes,
    String? amounts,
    String? imageLink,
    String? itemNotes,
  }) {
    return CartItem(
      id: id ?? this.id,
      name: name ?? this.name,
      sizes: sizes ?? this.sizes,
      amounts: amounts ?? this.amounts,
      imageLink: imageLink ?? this.imageLink,
      itemNotes: itemNotes ?? this.itemNotes,
    );
  }

  static toListOfMaps(List<CartItem> items) {
    List mapsList = [];
    for (CartItem item in items) {
      mapsList.add(item.toMap());
    }
    return mapsList;
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'size': sizes,
      'quantity': amounts,
      'imageLink': imageLink,
      'notes': itemNotes,
    };
  }

  factory CartItem.fromMap(Map<String, dynamic> map) {
    return CartItem(
      id: map['id'] ?? -1000,
      name: map['name'] ?? '',
      imageLink: map['imageLink'] ?? '',
      sizes: map['sizes'] ?? [],
      amounts: map['amounts'] ?? [],
      itemNotes: map['notes'] ?? '',
    );
  }

  factory CartItem.fromProduct(
      Product product, String amount, String size, String notes) {
    print('------ === =----- ${product.toString()}');
    print('------ === =----- ${product.images.first.attachment.toString()}');
    return CartItem(
      id: product.id,
      name: product.name,
      sizes: size,
      amounts: amount,
      itemNotes: notes,
      imageLink:
          product.images.isNotEmpty ? product.images.first.attachment : '',
    );
  }

  @override
  String toString() {
    return 'CartItem{id: $id, name: $name, sizes: $sizes, amounts: $amounts, imageLink: $imageLink, itemNotes: $itemNotes}';
  }

  @override
  List<Object> get props => [
        id,
        name,
        sizes,
        amounts,
        imageLink,
        itemNotes,
      ];
}
