import 'package:equatable/equatable.dart';

import '/models/cart/cart_item.dart';

class Cart extends Equatable {
  final List<CartItem> items;

  const Cart({required this.items});

  factory Cart.initial() => const Cart(
        items: [],
      );

  Map<String, dynamic> toMap() {
    return {
      'items': items,
    };
  }

  factory Cart.fromMap(Map<String, dynamic> map) {
    return Cart(
      items: map['items'] as List<CartItem>,
    );
  }

  Cart copyWith({
    List<CartItem>? items,
  }) {
    return Cart(
      items: items ?? this.items,
    );
  }

  @override
  String toString() {
    return 'Cart{items: $items}';
  }

  @override
  List<Object> get props => [items];
}
