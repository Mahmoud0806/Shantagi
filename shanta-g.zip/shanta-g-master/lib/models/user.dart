import 'package:equatable/equatable.dart';

class User extends Equatable {
  final int id;
  final String name;
  final String email;
  final String address;
  final String phone;
  final String whatsapp;
  final String type;
  final String fcmToken;
  final String password;
  final String verificationDate;
  final String expireDate;

  const User({
    required this.id,
    required this.name,
    required this.email,
    required this.address,
    required this.phone,
    required this.whatsapp,
    required this.type,
    required this.password,
    required this.fcmToken,
    required this.verificationDate,
    required this.expireDate,
  });

  factory User.initial() => const User(
        id: -1000,
        name: 'name',
        email: 'email',
        address: 'address',
        phone: '0990090809',
        whatsapp: '0668909779',
        type: 'type',
        password: 'pass',
        fcmToken: 'fToken',
        verificationDate: 'vDate',
        expireDate: 'expDate',
      );

  @override
  List<Object> get props => [
        id,
        name,
        email,
        address,
        phone,
        whatsapp,
        type,
        password,
        fcmToken,
        verificationDate,
        expireDate,
      ];

  User copyWith({
    int? id,
    String? name,
    String? email,
    String? address,
    String? phone,
    String? whatsapp,
    String? type,
    String? password,
    String? fcmToken,
    String? verificationDate,
    String? expireDate,
  }) {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      address: address ?? this.address,
      phone: phone ?? this.phone,
      whatsapp: whatsapp ?? this.whatsapp,
      type: type ?? this.type,
      password: password ?? this.password,
      fcmToken: fcmToken ?? this.fcmToken,
      verificationDate: verificationDate ?? this.verificationDate,
      expireDate: expireDate ?? this.expireDate,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'email': email,
      'address': address,
      'phone': phone,
      'password': password == '' ? '' : password,
      'account_date': expireDate,
    };
  }

  static fromMapsList(List maps) {
    if (maps.isEmpty) {
      print('empty');
      return [];
    }
    List<User> shanta = [];
    for (var map in maps) {
      shanta.add(User.fromMap(map));
    }
    return shanta;
  }

  static List<User> fromAccessMapsList(List maps) {
      print('start list maps');
    if (maps.isEmpty) {
      print('empty');
      return [];
    }
    List<User> shanta = [];
    for (var map in maps) {
      print('start first ma[p :: $map');
      shanta.add(User.fromAccessMap(map));
      print('shant len :: ::: ${shanta.length}');
    }
    return shanta;
  }


  factory User.fromAccessMap(Map<String, dynamic> map) => User(
      id: map['id'] ?? -1000,
      name: map['name'] ?? '',
      email: '',
      address: '',
      phone: '',
      whatsapp: '',
      type: '',
      password: '',
      fcmToken: '',
      verificationDate: '',
      expireDate: '',
    );

  factory User.fromMap(Map<String, dynamic> map) => User(
      id: map['id'] ?? -1000,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      address: map['address'] ?? '',
      phone: map['phone'] ?? '',
      whatsapp: map['whatsapp_number'] ?? '',
      type: map['type'] ?? '',
      password: '',
      fcmToken: map['fcm_token'] ?? '',
      verificationDate: map['email_verified_at'] ?? '',
      expireDate: map['account_date'] ?? '',
    );
}
