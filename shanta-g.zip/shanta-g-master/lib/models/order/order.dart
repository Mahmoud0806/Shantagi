import '../user.dart';
import 'order_item.dart';

class Order {
  final int id;
  final String number;
  final int retailerId;
  final String status;
  final String createdAt;
  final List<OrderItem> orderItems;
  final User user;

  Order({
    required this.id,
    required this.number,
    required this.retailerId,
    required this.status,
    required this.createdAt,
    required this.orderItems,
    required this.user,
  });

  factory Order.initial() => Order(
        id: -1000,
        number: '',
        retailerId: -1000,
        status: '',
        createdAt: '',
        orderItems: [],
        user: User.initial(),
      );

  Order copyWith({
    int? id,
    String? number,
    int? retailerId,
    String? status,
    String? createdAt,
    List<OrderItem>? orderItems,
    User? user,
  }) {
    return Order(
      id: id ?? this.id,
      number: number ?? this.number,
      retailerId: retailerId ?? this.retailerId,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      orderItems: orderItems ?? this.orderItems,
      user: user ?? this.user,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'order_number': number,
      'retailer_id': retailerId,
      'status': status,
      'created_at': createdAt,
      'order_items': orderItems,
      'sub_admin': user,
    };
  }

  static fromListOfMaps(List maps) {
    print(maps.length);
    List<Order> orders = [];
    for (var map in maps) {
      print(map['created_at'] == null);
      orders.add(Order.fromMap(map));
    }
    print(orders);
    return orders;
  }

  factory Order.fromMap(Map<String, dynamic> map) {
    return Order(
      id: map['id'] ?? -1000,
      number: map['order_number'] ?? '',
      retailerId: map['retailer_id1'] ?? -1000,
      status: map['status'] ?? '',
      createdAt: "${map['created_at']}",
      orderItems: OrderItem.fromListOfMaps(map['order_items'] ?? []),
      user: User.fromMap(map['client'] ?? map['retailer'] ?? {}),
    );
  }

  @override
  String toString() {
    return 'Order{id: $id, number: $number, retailerId: $retailerId, status: $status, createdAt: $createdAt, orderItems: $orderItems, user: $user}';
  }
}
