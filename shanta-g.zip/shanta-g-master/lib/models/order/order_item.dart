import '../product/product.dart';

class OrderItem {
  final int id;
  final int orderId;
  final int productId;
  final int requiredAmount;
  final int acceptableAmount;
  final String size;
  final String status;
  final String notes;
  final Product product;

  OrderItem({
    required this.id,
    required this.orderId,
    required this.productId,
    required this.requiredAmount,
    required this.acceptableAmount,
    required this.size,
    required this.status,
    required this.notes,
    required this.product,
  });

  factory OrderItem.initial() => OrderItem(
        id: -1000,
        orderId: -1000,
        productId: -1000,
        requiredAmount: -1000,
        acceptableAmount: -1000,
        size: '2',
        status: 'pending',
        notes: 'no notes',
        product: Product.initial(),
      );

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'order_id': orderId,
      'product_id': productId,
      'required_amount': requiredAmount,
      'acceptable_amount': acceptableAmount,
      'size': size,
      'status': status,
      'notes': notes,
      'product': product,
    };
  }


  static fromListOfMaps(List maps) {
    List<OrderItem> orderItems = [];
    if (maps.isEmpty) {
      return orderItems;
    }
    for (var map in maps) {
      orderItems.add(OrderItem.fromMap(map));
    }
    return orderItems;
  }

  factory OrderItem.fromMap(Map<String, dynamic> map) {

    // return OrderItem.initial();
    return OrderItem(
      id: int.tryParse("${map['id']}") ?? -1000,
      orderId: int.tryParse("${map['order_id']}") ?? -1000,
      productId: int.tryParse("${map['product_id']}") ?? -1000,
      requiredAmount: int.tryParse("${map['required_amount']}") ??
          int.tryParse("${map['quantity']}") ??
          -1000,
      acceptableAmount: int.tryParse("${map['acceptable_amount']}") ?? -1000,
      size: "${map['size']}" ?? '',
      status: map['status'] ?? '',
      notes: map['notes'] ?? '',
      product: map['product'] == null
          ? Product.initial()
          : Product.fromMap(map['product']),
    );
  }

  @override
  String toString() {
    return 'OrderItem{id: $id, orderId: $orderId, productId: $productId, requiredAmount: $requiredAmount, acceptableAmount: $acceptableAmount, size: $size, status: $status, notes: $notes, product: $product}';
  }

  OrderItem copyWith({
    int? id,
    int? orderId,
    int? productId,
    int? requiredAmount,
    int? acceptableAmount,
    String? size,
    String? status,
    String? notes,
    Product? product,

  }) {
    return OrderItem(
      id: id ?? this.id,
      orderId: orderId ?? this.orderId,
      productId: productId ?? this.productId,
      requiredAmount: requiredAmount ?? this.requiredAmount,
      acceptableAmount: acceptableAmount ?? this.acceptableAmount,
      size: size ?? this.size,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      product: product ?? this.product,
    );
  }
}
