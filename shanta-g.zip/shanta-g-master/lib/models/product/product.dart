
import '/models/product/product_image.dart';
import '../user.dart';


class Product {
  final int id;
  final String name;
  final String description;
  final String karat;
  final double weight;
  final List<String> sizes;
  final String notes;
  final bool hold;
  final String category;
  final User user;
  final List<ProductImage> images;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.karat,
    required this.weight,
    required this.sizes,
    required this.hold,
    required this.notes,
    required this.category,
    required this.user,
    required this.images,
  });

  factory Product.initial() => Product(
    id: -1000,
    name: '',
    description: '',
    karat: '',
    weight: -1000,
    sizes: const [],
    hold: false,
    notes: '',
    category: '',
    user: User.initial(),
    images: const [],
  );

  Product copyWith({
    int? id,
    String? name,
    String? description,
    String? karat,
    double? weight,
    List<String>? sizes,
    bool? hold,
    String? notes,
    String? category,
    User? user,
    List<ProductImage>? images,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      karat: karat ?? this.karat,
      weight: weight ?? this.weight,
      sizes: sizes ?? this.sizes,
      hold: hold ?? this.hold,
      category: category ?? this.category,
      notes: notes ?? this.notes,
      user: user ?? this.user,
      images: images ?? this.images,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'karat': karat,
      'weight': weight,
      'size': sizes,
      'hold': hold,
      'notes': notes,
      'category': category,
      'user': user,
      'icons': images,
    };
  }

  static  fromListOfMaps(List maps) {
    print('start mapppping :: :: ${maps.length}');
    List<Product> products = [];
    for (var map in maps) {
      print('mm map: - $map');
      products.add(Product.fromMap(map));
    }

    return products;
  }

  factory Product.fromMap(Map<String, dynamic> map) {

    List<String> sizes = [];
    if (map['size'] != null) {
      for (String size in map['size']) {
        sizes.add(size);
      }
    }

    return Product(
      id: map['id'] ?? -1000,
      name: map['name'] ?? '',
      description: map['description'] ?? '',
      karat: map['karat'] ?? '',
      weight: double.tryParse("${map['weight']}") ?? -1000.0,
      sizes: sizes,
      notes: map['notes'] ?? '',
      hold: map['hold'] ?? false,
      category: map['category'] ?? '',
      user: User.fromMap(map['user'] ?? {}),
      images: ProductImage.fromListOfMaps(map['images']),
    );
  }
}
