class ProductImage {
  final int id;
  final String attachment;

  const ProductImage({
    required this.id,
    required this.attachment,
  });

  factory ProductImage.initial() => const ProductImage(
    id: -1000,
    attachment: '',
  );

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'attachment': attachment,
    };
  }

  static fromListOfMaps(List? maps) {
    if(maps == null || maps.isEmpty){
      return <ProductImage>[];
    }
    List<ProductImage> images = [];
    for(var map in maps) {
      images.add(ProductImage.fromMap(map));
    }
    return images;
  }

  factory ProductImage.fromMap(Map<String, dynamic> map) {
    return ProductImage(
      id: map['id'] ?? -1000,
      attachment: map['attachment'] ?? '',
    );
  }

  ProductImage copyWith({
    int? id,
    String? attachment,
  }) {
    return ProductImage(
      id: id ?? this.id,
      attachment: attachment ?? this.attachment,
    );
  }
}
