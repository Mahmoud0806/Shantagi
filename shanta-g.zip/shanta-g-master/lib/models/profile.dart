class Profile {
  final int id;
  final String name;
  final String email;
  final String type;
  final String phone;
  final String address;
  final String whatsappUrl;

  Profile({
    required this.id,
    required this.name,
    required this.email,
    required this.type,
    required this.phone,
    required this.address,
    required this.whatsappUrl,
  });

  factory Profile.initial() => Profile(
    id: -1000,
    name: '',
    email: '',
    type: '',
    phone: '',
    address: '',
    whatsappUrl: '',
  );

  Profile copyWith({
    int? id,
    String? name,
    String? email,
    String? type,
    String? phone,
    String? address,
    String? whatsappUrl,
  }) {
    return Profile(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      type: type ?? this.type,
      phone: phone ?? this.phone,
      address: address ?? this.address,
      whatsappUrl: whatsappUrl ?? this.whatsappUrl,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'email': email,
      'type': type,
      'phone': phone,
      'address': address,
      'whatsapp_url': whatsappUrl,
    };
  }

  factory Profile.fromMap(Map<String, dynamic> map) {
    return Profile(
      id: map['id'] ?? -1000,
      name: map['name'] ?? '',
      email: map['email'] ?? '',
      type: map['type'] ?? '',
      phone: map['phone'] ?? '',
      address: map['address'] ?? '',
      whatsappUrl: map['whatsapp_url'] ?? '',
    );
  }
}
