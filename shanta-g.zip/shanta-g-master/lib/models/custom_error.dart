import 'package:equatable/equatable.dart';

class CustomError extends Equatable{
  final String message;
  final int code;

  const CustomError({
    required this.message,
    required this.code,
  });

  factory CustomError.initial() => const CustomError(
        message: '',
        code: 0,
      );



  @override
  String toString() {
    return 'CustomError{message: $message, code: $code}';
  }

  CustomError copyWith({
    String? message,
    int? code,
  }) {
    return CustomError(
      message: message ?? this.message,
      code: code ?? this.code,
    );
  }

  @override
  List<Object?> get props => [message, code];
}
