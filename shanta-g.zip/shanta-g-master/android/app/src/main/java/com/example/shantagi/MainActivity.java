package com.example.shantagi;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
